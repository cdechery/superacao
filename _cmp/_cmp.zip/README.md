doacoes
=======

A project for a website to act as a hub for donations
