<h3>Comprar <?php echo $data['titulo']?></h3>
<h2><?php echo $data['texto_curto']?></h2>
<h1>R$ <?php echo str_replace( ".", ",", $data['valor'])?></h1>
<?php echo $data['pagseguro_form']?>