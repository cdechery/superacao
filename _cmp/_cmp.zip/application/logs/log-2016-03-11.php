<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-03-11 08:39:38 --> Config Class Initialized
DEBUG - 2016-03-11 08:39:38 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:39:38 --> Utf8 Class Initialized
DEBUG - 2016-03-11 08:39:38 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 08:39:38 --> URI Class Initialized
DEBUG - 2016-03-11 08:39:38 --> Router Class Initialized
DEBUG - 2016-03-11 08:39:38 --> Output Class Initialized
DEBUG - 2016-03-11 08:39:38 --> Security Class Initialized
DEBUG - 2016-03-11 08:39:38 --> Input Class Initialized
DEBUG - 2016-03-11 08:39:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 08:39:38 --> Language Class Initialized
DEBUG - 2016-03-11 08:39:38 --> Loader Class Initialized
DEBUG - 2016-03-11 08:39:38 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 08:39:38 --> Helper loaded: url_helper
DEBUG - 2016-03-11 08:39:38 --> Helper loaded: image_helper
DEBUG - 2016-03-11 08:39:38 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 08:39:38 --> Database Driver Class Initialized
DEBUG - 2016-03-11 08:39:39 --> Session Class Initialized
DEBUG - 2016-03-11 08:39:39 --> Helper loaded: string_helper
DEBUG - 2016-03-11 08:39:39 --> A session cookie was not found.
DEBUG - 2016-03-11 08:39:39 --> Session routines successfully run
DEBUG - 2016-03-11 08:39:39 --> Controller Class Initialized
DEBUG - 2016-03-11 08:39:39 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 08:39:39 --> Model Class Initialized
DEBUG - 2016-03-11 08:39:39 --> Model Class Initialized
DEBUG - 2016-03-11 08:39:48 --> Config Class Initialized
DEBUG - 2016-03-11 08:39:48 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:39:48 --> Utf8 Class Initialized
DEBUG - 2016-03-11 08:39:48 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 08:39:48 --> URI Class Initialized
DEBUG - 2016-03-11 08:39:48 --> Router Class Initialized
DEBUG - 2016-03-11 08:39:48 --> Output Class Initialized
DEBUG - 2016-03-11 08:39:48 --> Security Class Initialized
DEBUG - 2016-03-11 08:39:48 --> Input Class Initialized
DEBUG - 2016-03-11 08:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 08:39:48 --> Language Class Initialized
DEBUG - 2016-03-11 08:39:48 --> Loader Class Initialized
DEBUG - 2016-03-11 08:39:48 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 08:39:48 --> Helper loaded: url_helper
DEBUG - 2016-03-11 08:39:48 --> Helper loaded: image_helper
DEBUG - 2016-03-11 08:39:48 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 08:39:48 --> Database Driver Class Initialized
DEBUG - 2016-03-11 08:39:49 --> Session Class Initialized
DEBUG - 2016-03-11 08:39:49 --> Helper loaded: string_helper
DEBUG - 2016-03-11 08:39:49 --> A session cookie was not found.
DEBUG - 2016-03-11 08:39:49 --> Session routines successfully run
DEBUG - 2016-03-11 08:39:49 --> Controller Class Initialized
DEBUG - 2016-03-11 08:39:49 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 08:39:49 --> Model Class Initialized
DEBUG - 2016-03-11 08:39:49 --> Model Class Initialized
DEBUG - 2016-03-11 08:39:49 --> File loaded: application/views/campanhas_listar.php
DEBUG - 2016-03-11 08:39:49 --> Final output sent to browser
DEBUG - 2016-03-11 08:39:49 --> Total execution time: 1.2071
DEBUG - 2016-03-11 08:39:49 --> Config Class Initialized
DEBUG - 2016-03-11 08:39:49 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:39:49 --> Utf8 Class Initialized
DEBUG - 2016-03-11 08:39:49 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 08:39:49 --> URI Class Initialized
DEBUG - 2016-03-11 08:39:49 --> Router Class Initialized
DEBUG - 2016-03-11 08:39:49 --> Output Class Initialized
DEBUG - 2016-03-11 08:39:49 --> Security Class Initialized
DEBUG - 2016-03-11 08:39:50 --> Input Class Initialized
DEBUG - 2016-03-11 08:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 08:39:50 --> Language Class Initialized
DEBUG - 2016-03-11 08:39:50 --> Loader Class Initialized
DEBUG - 2016-03-11 08:39:50 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 08:39:50 --> Helper loaded: url_helper
DEBUG - 2016-03-11 08:39:50 --> Helper loaded: image_helper
DEBUG - 2016-03-11 08:39:50 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 08:39:50 --> Database Driver Class Initialized
DEBUG - 2016-03-11 08:39:51 --> Session Class Initialized
DEBUG - 2016-03-11 08:39:51 --> Helper loaded: string_helper
DEBUG - 2016-03-11 08:39:51 --> A session cookie was not found.
DEBUG - 2016-03-11 08:39:51 --> Session routines successfully run
DEBUG - 2016-03-11 08:39:51 --> Controller Class Initialized
DEBUG - 2016-03-11 08:39:51 --> Final output sent to browser
DEBUG - 2016-03-11 08:39:51 --> Total execution time: 1.1571
DEBUG - 2016-03-11 08:40:08 --> Config Class Initialized
DEBUG - 2016-03-11 08:40:08 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:40:09 --> Utf8 Class Initialized
DEBUG - 2016-03-11 08:40:09 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 08:40:09 --> URI Class Initialized
DEBUG - 2016-03-11 08:40:09 --> Router Class Initialized
DEBUG - 2016-03-11 08:40:09 --> Output Class Initialized
DEBUG - 2016-03-11 08:40:09 --> Security Class Initialized
DEBUG - 2016-03-11 08:40:09 --> Input Class Initialized
DEBUG - 2016-03-11 08:40:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 08:40:09 --> Language Class Initialized
DEBUG - 2016-03-11 08:40:09 --> Loader Class Initialized
DEBUG - 2016-03-11 08:40:09 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 08:40:09 --> Helper loaded: url_helper
DEBUG - 2016-03-11 08:40:09 --> Helper loaded: image_helper
DEBUG - 2016-03-11 08:40:09 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 08:40:09 --> Database Driver Class Initialized
DEBUG - 2016-03-11 08:40:10 --> Session Class Initialized
DEBUG - 2016-03-11 08:40:10 --> Helper loaded: string_helper
DEBUG - 2016-03-11 08:40:10 --> A session cookie was not found.
DEBUG - 2016-03-11 08:40:10 --> Session routines successfully run
DEBUG - 2016-03-11 08:40:10 --> Controller Class Initialized
DEBUG - 2016-03-11 08:40:10 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 08:40:10 --> Model Class Initialized
DEBUG - 2016-03-11 08:40:10 --> Model Class Initialized
DEBUG - 2016-03-11 08:40:10 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 08:40:10 --> Final output sent to browser
DEBUG - 2016-03-11 08:40:10 --> Total execution time: 1.1481
DEBUG - 2016-03-11 08:40:10 --> Config Class Initialized
DEBUG - 2016-03-11 08:40:10 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:40:10 --> Utf8 Class Initialized
DEBUG - 2016-03-11 08:40:10 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 08:40:10 --> URI Class Initialized
DEBUG - 2016-03-11 08:40:10 --> Router Class Initialized
DEBUG - 2016-03-11 08:40:10 --> Output Class Initialized
DEBUG - 2016-03-11 08:40:10 --> Security Class Initialized
DEBUG - 2016-03-11 08:40:10 --> Input Class Initialized
DEBUG - 2016-03-11 08:40:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 08:40:10 --> Language Class Initialized
DEBUG - 2016-03-11 08:40:10 --> Loader Class Initialized
DEBUG - 2016-03-11 08:40:10 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 08:40:10 --> Helper loaded: url_helper
DEBUG - 2016-03-11 08:40:10 --> Helper loaded: image_helper
DEBUG - 2016-03-11 08:40:10 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 08:40:11 --> Database Driver Class Initialized
DEBUG - 2016-03-11 08:40:12 --> Session Class Initialized
DEBUG - 2016-03-11 08:40:12 --> Helper loaded: string_helper
DEBUG - 2016-03-11 08:40:12 --> Session routines successfully run
DEBUG - 2016-03-11 08:40:12 --> Controller Class Initialized
DEBUG - 2016-03-11 08:40:12 --> Final output sent to browser
DEBUG - 2016-03-11 08:40:12 --> Total execution time: 1.1461
DEBUG - 2016-03-11 08:42:31 --> Config Class Initialized
DEBUG - 2016-03-11 08:42:31 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:42:31 --> Utf8 Class Initialized
DEBUG - 2016-03-11 08:42:31 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 08:42:31 --> URI Class Initialized
DEBUG - 2016-03-11 08:42:31 --> Router Class Initialized
DEBUG - 2016-03-11 08:42:31 --> Output Class Initialized
DEBUG - 2016-03-11 08:42:31 --> Security Class Initialized
DEBUG - 2016-03-11 08:42:31 --> Input Class Initialized
DEBUG - 2016-03-11 08:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 08:42:32 --> Language Class Initialized
DEBUG - 2016-03-11 08:42:32 --> Loader Class Initialized
DEBUG - 2016-03-11 08:42:32 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 08:42:32 --> Helper loaded: url_helper
DEBUG - 2016-03-11 08:42:32 --> Helper loaded: image_helper
DEBUG - 2016-03-11 08:42:32 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 08:42:32 --> Database Driver Class Initialized
DEBUG - 2016-03-11 08:42:33 --> Session Class Initialized
DEBUG - 2016-03-11 08:42:33 --> Helper loaded: string_helper
DEBUG - 2016-03-11 08:42:33 --> A session cookie was not found.
DEBUG - 2016-03-11 08:42:33 --> Session routines successfully run
DEBUG - 2016-03-11 08:42:33 --> Controller Class Initialized
DEBUG - 2016-03-11 08:42:33 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 08:42:33 --> Model Class Initialized
DEBUG - 2016-03-11 08:42:33 --> Model Class Initialized
DEBUG - 2016-03-11 08:42:33 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 08:42:33 --> Final output sent to browser
DEBUG - 2016-03-11 08:42:33 --> Total execution time: 1.1741
DEBUG - 2016-03-11 08:42:55 --> Config Class Initialized
DEBUG - 2016-03-11 08:42:55 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:42:55 --> Utf8 Class Initialized
DEBUG - 2016-03-11 08:42:55 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 08:42:55 --> URI Class Initialized
DEBUG - 2016-03-11 08:42:55 --> Router Class Initialized
DEBUG - 2016-03-11 08:42:55 --> Output Class Initialized
DEBUG - 2016-03-11 08:42:55 --> Security Class Initialized
DEBUG - 2016-03-11 08:42:55 --> Input Class Initialized
DEBUG - 2016-03-11 08:42:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 08:42:55 --> Language Class Initialized
DEBUG - 2016-03-11 08:42:55 --> Loader Class Initialized
DEBUG - 2016-03-11 08:42:55 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 08:42:55 --> Helper loaded: url_helper
DEBUG - 2016-03-11 08:42:55 --> Helper loaded: image_helper
DEBUG - 2016-03-11 08:42:55 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 08:42:55 --> Database Driver Class Initialized
DEBUG - 2016-03-11 08:42:56 --> Session Class Initialized
DEBUG - 2016-03-11 08:42:56 --> Helper loaded: string_helper
DEBUG - 2016-03-11 08:42:56 --> A session cookie was not found.
DEBUG - 2016-03-11 08:42:56 --> Session routines successfully run
DEBUG - 2016-03-11 08:42:56 --> Controller Class Initialized
DEBUG - 2016-03-11 08:42:56 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 08:42:56 --> Model Class Initialized
DEBUG - 2016-03-11 08:42:56 --> Model Class Initialized
DEBUG - 2016-03-11 08:42:56 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 08:42:56 --> Final output sent to browser
DEBUG - 2016-03-11 08:42:56 --> Total execution time: 1.1761
DEBUG - 2016-03-11 08:46:21 --> Config Class Initialized
DEBUG - 2016-03-11 08:46:21 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:46:21 --> Utf8 Class Initialized
DEBUG - 2016-03-11 08:46:21 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 08:46:21 --> URI Class Initialized
DEBUG - 2016-03-11 08:46:21 --> Router Class Initialized
DEBUG - 2016-03-11 08:46:21 --> Output Class Initialized
DEBUG - 2016-03-11 08:46:21 --> Security Class Initialized
DEBUG - 2016-03-11 08:46:21 --> Input Class Initialized
DEBUG - 2016-03-11 08:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 08:46:21 --> Language Class Initialized
DEBUG - 2016-03-11 08:46:21 --> Loader Class Initialized
DEBUG - 2016-03-11 08:46:21 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 08:46:21 --> Helper loaded: url_helper
DEBUG - 2016-03-11 08:46:21 --> Helper loaded: image_helper
DEBUG - 2016-03-11 08:46:21 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 08:46:21 --> Database Driver Class Initialized
DEBUG - 2016-03-11 08:46:22 --> Session Class Initialized
DEBUG - 2016-03-11 08:46:22 --> Helper loaded: string_helper
DEBUG - 2016-03-11 08:46:22 --> A session cookie was not found.
DEBUG - 2016-03-11 08:46:22 --> Session routines successfully run
DEBUG - 2016-03-11 08:46:22 --> Controller Class Initialized
DEBUG - 2016-03-11 08:46:22 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 08:46:22 --> Model Class Initialized
DEBUG - 2016-03-11 08:46:22 --> Model Class Initialized
DEBUG - 2016-03-11 08:46:22 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 08:46:22 --> Final output sent to browser
DEBUG - 2016-03-11 08:46:22 --> Total execution time: 1.1261
DEBUG - 2016-03-11 08:47:36 --> Config Class Initialized
DEBUG - 2016-03-11 08:47:36 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:47:36 --> Utf8 Class Initialized
DEBUG - 2016-03-11 08:47:36 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 08:47:36 --> URI Class Initialized
DEBUG - 2016-03-11 08:47:36 --> Router Class Initialized
DEBUG - 2016-03-11 08:47:36 --> Output Class Initialized
DEBUG - 2016-03-11 08:47:36 --> Security Class Initialized
DEBUG - 2016-03-11 08:47:36 --> Input Class Initialized
DEBUG - 2016-03-11 08:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 08:47:36 --> Language Class Initialized
DEBUG - 2016-03-11 08:47:36 --> Loader Class Initialized
DEBUG - 2016-03-11 08:47:36 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 08:47:36 --> Helper loaded: url_helper
DEBUG - 2016-03-11 08:47:36 --> Helper loaded: image_helper
DEBUG - 2016-03-11 08:47:36 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 08:47:36 --> Database Driver Class Initialized
DEBUG - 2016-03-11 08:47:37 --> Session Class Initialized
DEBUG - 2016-03-11 08:47:37 --> Helper loaded: string_helper
DEBUG - 2016-03-11 08:47:37 --> A session cookie was not found.
DEBUG - 2016-03-11 08:47:37 --> Session routines successfully run
DEBUG - 2016-03-11 08:47:37 --> Controller Class Initialized
DEBUG - 2016-03-11 08:47:37 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 08:47:37 --> Model Class Initialized
DEBUG - 2016-03-11 08:47:37 --> Model Class Initialized
DEBUG - 2016-03-11 08:47:37 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 08:47:37 --> Final output sent to browser
DEBUG - 2016-03-11 08:47:37 --> Total execution time: 1.1741
DEBUG - 2016-03-11 08:47:53 --> Config Class Initialized
DEBUG - 2016-03-11 08:47:53 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:47:53 --> Utf8 Class Initialized
DEBUG - 2016-03-11 08:47:53 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 08:47:53 --> URI Class Initialized
DEBUG - 2016-03-11 08:47:53 --> Router Class Initialized
DEBUG - 2016-03-11 08:47:53 --> Output Class Initialized
DEBUG - 2016-03-11 08:47:53 --> Security Class Initialized
DEBUG - 2016-03-11 08:47:53 --> Input Class Initialized
DEBUG - 2016-03-11 08:47:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 08:47:53 --> Language Class Initialized
DEBUG - 2016-03-11 08:47:53 --> Loader Class Initialized
DEBUG - 2016-03-11 08:47:53 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 08:47:53 --> Helper loaded: url_helper
DEBUG - 2016-03-11 08:47:53 --> Helper loaded: image_helper
DEBUG - 2016-03-11 08:47:53 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 08:47:53 --> Database Driver Class Initialized
DEBUG - 2016-03-11 08:47:54 --> Session Class Initialized
DEBUG - 2016-03-11 08:47:54 --> Helper loaded: string_helper
DEBUG - 2016-03-11 08:47:54 --> A session cookie was not found.
DEBUG - 2016-03-11 08:47:54 --> Session routines successfully run
DEBUG - 2016-03-11 08:47:54 --> Controller Class Initialized
DEBUG - 2016-03-11 08:47:54 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 08:47:55 --> Model Class Initialized
DEBUG - 2016-03-11 08:47:55 --> Model Class Initialized
DEBUG - 2016-03-11 08:47:55 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 08:47:55 --> Final output sent to browser
DEBUG - 2016-03-11 08:47:55 --> Total execution time: 1.0981
DEBUG - 2016-03-11 08:49:33 --> Config Class Initialized
DEBUG - 2016-03-11 08:49:33 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:49:33 --> Utf8 Class Initialized
DEBUG - 2016-03-11 08:49:33 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 08:49:33 --> URI Class Initialized
DEBUG - 2016-03-11 08:49:33 --> Router Class Initialized
DEBUG - 2016-03-11 08:49:33 --> Output Class Initialized
DEBUG - 2016-03-11 08:49:33 --> Security Class Initialized
DEBUG - 2016-03-11 08:49:33 --> Input Class Initialized
DEBUG - 2016-03-11 08:49:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 08:49:33 --> Language Class Initialized
DEBUG - 2016-03-11 08:49:33 --> Loader Class Initialized
DEBUG - 2016-03-11 08:49:33 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 08:49:33 --> Helper loaded: url_helper
DEBUG - 2016-03-11 08:49:33 --> Helper loaded: image_helper
DEBUG - 2016-03-11 08:49:33 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 08:49:33 --> Database Driver Class Initialized
DEBUG - 2016-03-11 08:49:34 --> Session Class Initialized
DEBUG - 2016-03-11 08:49:34 --> Helper loaded: string_helper
DEBUG - 2016-03-11 08:49:34 --> A session cookie was not found.
DEBUG - 2016-03-11 08:49:34 --> Session routines successfully run
DEBUG - 2016-03-11 08:49:34 --> Controller Class Initialized
DEBUG - 2016-03-11 08:49:34 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 08:49:34 --> Model Class Initialized
DEBUG - 2016-03-11 08:49:34 --> Model Class Initialized
DEBUG - 2016-03-11 08:49:34 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 08:49:34 --> Final output sent to browser
DEBUG - 2016-03-11 08:49:34 --> Total execution time: 1.1451
DEBUG - 2016-03-11 08:52:38 --> Config Class Initialized
DEBUG - 2016-03-11 08:52:38 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:52:38 --> Utf8 Class Initialized
DEBUG - 2016-03-11 08:52:38 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 08:52:38 --> URI Class Initialized
DEBUG - 2016-03-11 08:52:38 --> Router Class Initialized
DEBUG - 2016-03-11 08:52:38 --> Output Class Initialized
DEBUG - 2016-03-11 08:52:38 --> Security Class Initialized
DEBUG - 2016-03-11 08:52:38 --> Input Class Initialized
DEBUG - 2016-03-11 08:52:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 08:52:38 --> Language Class Initialized
DEBUG - 2016-03-11 08:52:38 --> Loader Class Initialized
DEBUG - 2016-03-11 08:52:38 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 08:52:38 --> Helper loaded: url_helper
DEBUG - 2016-03-11 08:52:38 --> Helper loaded: image_helper
DEBUG - 2016-03-11 08:52:38 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 08:52:38 --> Database Driver Class Initialized
DEBUG - 2016-03-11 08:52:39 --> Session Class Initialized
DEBUG - 2016-03-11 08:52:39 --> Helper loaded: string_helper
DEBUG - 2016-03-11 08:52:39 --> A session cookie was not found.
DEBUG - 2016-03-11 08:52:39 --> Session routines successfully run
DEBUG - 2016-03-11 08:52:39 --> Controller Class Initialized
DEBUG - 2016-03-11 08:52:39 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 08:52:39 --> Model Class Initialized
DEBUG - 2016-03-11 08:52:39 --> Model Class Initialized
DEBUG - 2016-03-11 08:52:39 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 08:52:39 --> Final output sent to browser
DEBUG - 2016-03-11 08:52:39 --> Total execution time: 1.1651
DEBUG - 2016-03-11 08:57:04 --> Config Class Initialized
DEBUG - 2016-03-11 08:57:04 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:57:04 --> Utf8 Class Initialized
DEBUG - 2016-03-11 08:57:04 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 08:57:04 --> URI Class Initialized
DEBUG - 2016-03-11 08:57:04 --> Router Class Initialized
DEBUG - 2016-03-11 08:57:04 --> Output Class Initialized
DEBUG - 2016-03-11 08:57:04 --> Security Class Initialized
DEBUG - 2016-03-11 08:57:04 --> Input Class Initialized
DEBUG - 2016-03-11 08:57:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 08:57:04 --> Language Class Initialized
DEBUG - 2016-03-11 08:57:04 --> Loader Class Initialized
DEBUG - 2016-03-11 08:57:04 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 08:57:04 --> Helper loaded: url_helper
DEBUG - 2016-03-11 08:57:04 --> Helper loaded: image_helper
DEBUG - 2016-03-11 08:57:04 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 08:57:04 --> Database Driver Class Initialized
DEBUG - 2016-03-11 08:57:05 --> Session Class Initialized
DEBUG - 2016-03-11 08:57:05 --> Helper loaded: string_helper
DEBUG - 2016-03-11 08:57:05 --> A session cookie was not found.
DEBUG - 2016-03-11 08:57:05 --> Session routines successfully run
DEBUG - 2016-03-11 08:57:05 --> Controller Class Initialized
DEBUG - 2016-03-11 08:57:05 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 08:57:05 --> Model Class Initialized
DEBUG - 2016-03-11 08:57:05 --> Model Class Initialized
DEBUG - 2016-03-11 08:57:05 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 08:57:05 --> Final output sent to browser
DEBUG - 2016-03-11 08:57:05 --> Total execution time: 1.1380
DEBUG - 2016-03-11 08:57:06 --> Config Class Initialized
DEBUG - 2016-03-11 08:57:06 --> Hooks Class Initialized
DEBUG - 2016-03-11 08:57:06 --> Utf8 Class Initialized
DEBUG - 2016-03-11 08:57:06 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 08:57:06 --> URI Class Initialized
DEBUG - 2016-03-11 08:57:06 --> Router Class Initialized
DEBUG - 2016-03-11 08:57:06 --> Output Class Initialized
DEBUG - 2016-03-11 08:57:06 --> Security Class Initialized
DEBUG - 2016-03-11 08:57:06 --> Input Class Initialized
DEBUG - 2016-03-11 08:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 08:57:06 --> Language Class Initialized
DEBUG - 2016-03-11 08:57:06 --> Loader Class Initialized
DEBUG - 2016-03-11 08:57:06 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 08:57:06 --> Helper loaded: url_helper
DEBUG - 2016-03-11 08:57:06 --> Helper loaded: image_helper
DEBUG - 2016-03-11 08:57:06 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 08:57:06 --> Database Driver Class Initialized
DEBUG - 2016-03-11 08:57:07 --> Session Class Initialized
DEBUG - 2016-03-11 08:57:07 --> Helper loaded: string_helper
DEBUG - 2016-03-11 08:57:07 --> Session routines successfully run
DEBUG - 2016-03-11 08:57:07 --> Controller Class Initialized
DEBUG - 2016-03-11 08:57:07 --> Final output sent to browser
DEBUG - 2016-03-11 08:57:07 --> Total execution time: 1.2970
DEBUG - 2016-03-11 09:21:56 --> Config Class Initialized
DEBUG - 2016-03-11 09:21:56 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:21:56 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:21:56 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:21:56 --> URI Class Initialized
DEBUG - 2016-03-11 09:21:56 --> Router Class Initialized
DEBUG - 2016-03-11 09:21:56 --> Output Class Initialized
DEBUG - 2016-03-11 09:21:57 --> Security Class Initialized
DEBUG - 2016-03-11 09:21:57 --> Input Class Initialized
DEBUG - 2016-03-11 09:21:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:21:57 --> Language Class Initialized
DEBUG - 2016-03-11 09:21:57 --> Loader Class Initialized
DEBUG - 2016-03-11 09:21:57 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:21:57 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:21:57 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:21:57 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:21:57 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:21:58 --> Session Class Initialized
DEBUG - 2016-03-11 09:21:58 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:21:58 --> A session cookie was not found.
DEBUG - 2016-03-11 09:21:58 --> Session routines successfully run
DEBUG - 2016-03-11 09:21:58 --> Controller Class Initialized
DEBUG - 2016-03-11 09:21:58 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 09:21:58 --> Model Class Initialized
DEBUG - 2016-03-11 09:21:58 --> Model Class Initialized
DEBUG - 2016-03-11 09:21:58 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 09:21:58 --> Final output sent to browser
DEBUG - 2016-03-11 09:21:58 --> Total execution time: 1.1470
DEBUG - 2016-03-11 09:21:59 --> Config Class Initialized
DEBUG - 2016-03-11 09:21:59 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:21:59 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:21:59 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:21:59 --> URI Class Initialized
DEBUG - 2016-03-11 09:21:59 --> Router Class Initialized
DEBUG - 2016-03-11 09:21:59 --> Output Class Initialized
DEBUG - 2016-03-11 09:21:59 --> Security Class Initialized
DEBUG - 2016-03-11 09:21:59 --> Input Class Initialized
DEBUG - 2016-03-11 09:21:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:21:59 --> Language Class Initialized
DEBUG - 2016-03-11 09:21:59 --> Loader Class Initialized
DEBUG - 2016-03-11 09:21:59 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:21:59 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:21:59 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:21:59 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:21:59 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:22:00 --> Session Class Initialized
DEBUG - 2016-03-11 09:22:00 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:22:00 --> Session routines successfully run
DEBUG - 2016-03-11 09:22:00 --> Controller Class Initialized
DEBUG - 2016-03-11 09:22:00 --> Final output sent to browser
DEBUG - 2016-03-11 09:22:00 --> Total execution time: 1.1320
DEBUG - 2016-03-11 09:22:23 --> Config Class Initialized
DEBUG - 2016-03-11 09:22:23 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:22:23 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:22:23 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:22:23 --> URI Class Initialized
DEBUG - 2016-03-11 09:22:23 --> Router Class Initialized
DEBUG - 2016-03-11 09:22:23 --> Output Class Initialized
DEBUG - 2016-03-11 09:22:23 --> Security Class Initialized
DEBUG - 2016-03-11 09:22:23 --> Input Class Initialized
DEBUG - 2016-03-11 09:22:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:22:23 --> Language Class Initialized
DEBUG - 2016-03-11 09:22:23 --> Loader Class Initialized
DEBUG - 2016-03-11 09:22:23 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:22:23 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:22:23 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:22:23 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:22:23 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:22:24 --> Session Class Initialized
DEBUG - 2016-03-11 09:22:24 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:22:24 --> A session cookie was not found.
DEBUG - 2016-03-11 09:22:24 --> Session routines successfully run
DEBUG - 2016-03-11 09:22:24 --> Controller Class Initialized
DEBUG - 2016-03-11 09:22:24 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 09:22:24 --> Model Class Initialized
DEBUG - 2016-03-11 09:22:24 --> Model Class Initialized
DEBUG - 2016-03-11 09:22:24 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 09:22:24 --> Final output sent to browser
DEBUG - 2016-03-11 09:22:24 --> Total execution time: 1.1500
DEBUG - 2016-03-11 09:22:25 --> Config Class Initialized
DEBUG - 2016-03-11 09:22:25 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:22:25 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:22:25 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:22:25 --> URI Class Initialized
DEBUG - 2016-03-11 09:22:25 --> Router Class Initialized
DEBUG - 2016-03-11 09:22:25 --> Output Class Initialized
DEBUG - 2016-03-11 09:22:25 --> Security Class Initialized
DEBUG - 2016-03-11 09:22:25 --> Input Class Initialized
DEBUG - 2016-03-11 09:22:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:22:25 --> Language Class Initialized
DEBUG - 2016-03-11 09:22:25 --> Loader Class Initialized
DEBUG - 2016-03-11 09:22:25 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:22:25 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:22:25 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:22:25 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:22:25 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:22:26 --> Session Class Initialized
DEBUG - 2016-03-11 09:22:26 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:22:26 --> Session routines successfully run
DEBUG - 2016-03-11 09:22:26 --> Controller Class Initialized
DEBUG - 2016-03-11 09:22:26 --> Final output sent to browser
DEBUG - 2016-03-11 09:22:26 --> Total execution time: 1.1730
DEBUG - 2016-03-11 09:23:33 --> Config Class Initialized
DEBUG - 2016-03-11 09:23:33 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:23:33 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:23:33 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:23:33 --> URI Class Initialized
DEBUG - 2016-03-11 09:23:33 --> Router Class Initialized
DEBUG - 2016-03-11 09:23:33 --> Output Class Initialized
DEBUG - 2016-03-11 09:23:33 --> Security Class Initialized
DEBUG - 2016-03-11 09:23:33 --> Input Class Initialized
DEBUG - 2016-03-11 09:23:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:23:33 --> Language Class Initialized
DEBUG - 2016-03-11 09:23:33 --> Loader Class Initialized
DEBUG - 2016-03-11 09:23:33 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:23:33 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:23:33 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:23:33 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:23:33 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:23:34 --> Session Class Initialized
DEBUG - 2016-03-11 09:23:34 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:23:34 --> A session cookie was not found.
DEBUG - 2016-03-11 09:23:34 --> Session routines successfully run
DEBUG - 2016-03-11 09:23:34 --> Controller Class Initialized
DEBUG - 2016-03-11 09:23:34 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 09:23:34 --> Model Class Initialized
DEBUG - 2016-03-11 09:23:34 --> Model Class Initialized
DEBUG - 2016-03-11 09:23:34 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 09:23:34 --> Final output sent to browser
DEBUG - 2016-03-11 09:23:34 --> Total execution time: 1.1591
DEBUG - 2016-03-11 09:23:35 --> Config Class Initialized
DEBUG - 2016-03-11 09:23:35 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:23:35 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:23:35 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:23:35 --> URI Class Initialized
DEBUG - 2016-03-11 09:23:35 --> Router Class Initialized
DEBUG - 2016-03-11 09:23:35 --> Output Class Initialized
DEBUG - 2016-03-11 09:23:35 --> Security Class Initialized
DEBUG - 2016-03-11 09:23:35 --> Input Class Initialized
DEBUG - 2016-03-11 09:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:23:35 --> Language Class Initialized
DEBUG - 2016-03-11 09:23:35 --> Loader Class Initialized
DEBUG - 2016-03-11 09:23:35 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:23:35 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:23:35 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:23:35 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:23:35 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:23:36 --> Session Class Initialized
DEBUG - 2016-03-11 09:23:36 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:23:36 --> Session routines successfully run
DEBUG - 2016-03-11 09:23:36 --> Controller Class Initialized
DEBUG - 2016-03-11 09:23:36 --> Final output sent to browser
DEBUG - 2016-03-11 09:23:36 --> Total execution time: 1.2171
DEBUG - 2016-03-11 09:30:28 --> Config Class Initialized
DEBUG - 2016-03-11 09:30:28 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:30:28 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:30:28 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:30:28 --> URI Class Initialized
DEBUG - 2016-03-11 09:30:28 --> Router Class Initialized
DEBUG - 2016-03-11 09:30:28 --> Output Class Initialized
DEBUG - 2016-03-11 09:30:28 --> Security Class Initialized
DEBUG - 2016-03-11 09:30:28 --> Input Class Initialized
DEBUG - 2016-03-11 09:30:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:30:28 --> Language Class Initialized
DEBUG - 2016-03-11 09:30:28 --> Loader Class Initialized
DEBUG - 2016-03-11 09:30:28 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:30:28 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:30:28 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:30:28 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:30:28 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:30:29 --> Session Class Initialized
DEBUG - 2016-03-11 09:30:29 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:30:29 --> A session cookie was not found.
DEBUG - 2016-03-11 09:30:29 --> Session routines successfully run
DEBUG - 2016-03-11 09:30:29 --> Controller Class Initialized
DEBUG - 2016-03-11 09:30:29 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 09:30:29 --> Model Class Initialized
DEBUG - 2016-03-11 09:30:29 --> Model Class Initialized
DEBUG - 2016-03-11 09:30:29 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 09:30:29 --> Final output sent to browser
DEBUG - 2016-03-11 09:30:29 --> Total execution time: 1.1341
DEBUG - 2016-03-11 09:30:30 --> Config Class Initialized
DEBUG - 2016-03-11 09:30:30 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:30:30 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:30:30 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:30:30 --> URI Class Initialized
DEBUG - 2016-03-11 09:30:30 --> Router Class Initialized
DEBUG - 2016-03-11 09:30:30 --> Output Class Initialized
DEBUG - 2016-03-11 09:30:30 --> Security Class Initialized
DEBUG - 2016-03-11 09:30:30 --> Input Class Initialized
DEBUG - 2016-03-11 09:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:30:30 --> Language Class Initialized
DEBUG - 2016-03-11 09:30:30 --> Loader Class Initialized
DEBUG - 2016-03-11 09:30:30 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:30:30 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:30:30 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:30:30 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:30:30 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:30:31 --> Session Class Initialized
DEBUG - 2016-03-11 09:30:31 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:30:31 --> Session routines successfully run
DEBUG - 2016-03-11 09:30:31 --> Controller Class Initialized
DEBUG - 2016-03-11 09:30:31 --> Final output sent to browser
DEBUG - 2016-03-11 09:30:31 --> Total execution time: 1.1381
DEBUG - 2016-03-11 09:33:59 --> Config Class Initialized
DEBUG - 2016-03-11 09:33:59 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:33:59 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:33:59 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:33:59 --> URI Class Initialized
DEBUG - 2016-03-11 09:33:59 --> Router Class Initialized
DEBUG - 2016-03-11 09:33:59 --> Output Class Initialized
DEBUG - 2016-03-11 09:33:59 --> Security Class Initialized
DEBUG - 2016-03-11 09:33:59 --> Input Class Initialized
DEBUG - 2016-03-11 09:33:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:33:59 --> Language Class Initialized
DEBUG - 2016-03-11 09:33:59 --> Loader Class Initialized
DEBUG - 2016-03-11 09:33:59 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:33:59 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:33:59 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:33:59 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:33:59 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:34:00 --> Session Class Initialized
DEBUG - 2016-03-11 09:34:00 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:34:00 --> A session cookie was not found.
DEBUG - 2016-03-11 09:34:00 --> Session routines successfully run
DEBUG - 2016-03-11 09:34:00 --> Controller Class Initialized
DEBUG - 2016-03-11 09:34:00 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 09:34:00 --> Model Class Initialized
DEBUG - 2016-03-11 09:34:00 --> Model Class Initialized
DEBUG - 2016-03-11 09:34:00 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 09:34:00 --> Final output sent to browser
DEBUG - 2016-03-11 09:34:00 --> Total execution time: 1.1421
DEBUG - 2016-03-11 09:34:01 --> Config Class Initialized
DEBUG - 2016-03-11 09:34:01 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:34:01 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:34:01 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:34:01 --> URI Class Initialized
DEBUG - 2016-03-11 09:34:01 --> Router Class Initialized
DEBUG - 2016-03-11 09:34:01 --> Output Class Initialized
DEBUG - 2016-03-11 09:34:01 --> Security Class Initialized
DEBUG - 2016-03-11 09:34:01 --> Input Class Initialized
DEBUG - 2016-03-11 09:34:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:34:01 --> Language Class Initialized
DEBUG - 2016-03-11 09:34:01 --> Loader Class Initialized
DEBUG - 2016-03-11 09:34:01 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:34:01 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:34:01 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:34:01 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:34:01 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:34:02 --> Session Class Initialized
DEBUG - 2016-03-11 09:34:02 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:34:02 --> Session routines successfully run
DEBUG - 2016-03-11 09:34:02 --> Controller Class Initialized
DEBUG - 2016-03-11 09:34:02 --> Final output sent to browser
DEBUG - 2016-03-11 09:34:02 --> Total execution time: 1.1131
DEBUG - 2016-03-11 09:37:36 --> Config Class Initialized
DEBUG - 2016-03-11 09:37:36 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:37:36 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:37:36 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:37:36 --> URI Class Initialized
DEBUG - 2016-03-11 09:37:36 --> Router Class Initialized
DEBUG - 2016-03-11 09:37:36 --> Output Class Initialized
DEBUG - 2016-03-11 09:37:36 --> Security Class Initialized
DEBUG - 2016-03-11 09:37:36 --> Input Class Initialized
DEBUG - 2016-03-11 09:37:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:37:36 --> Language Class Initialized
DEBUG - 2016-03-11 09:37:36 --> Loader Class Initialized
DEBUG - 2016-03-11 09:37:36 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:37:36 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:37:36 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:37:36 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:37:36 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:37:37 --> Session Class Initialized
DEBUG - 2016-03-11 09:37:37 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:37:37 --> A session cookie was not found.
DEBUG - 2016-03-11 09:37:37 --> Session routines successfully run
DEBUG - 2016-03-11 09:37:37 --> Controller Class Initialized
DEBUG - 2016-03-11 09:37:37 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 09:37:37 --> Model Class Initialized
DEBUG - 2016-03-11 09:37:37 --> Model Class Initialized
DEBUG - 2016-03-11 09:37:37 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 09:37:37 --> Final output sent to browser
DEBUG - 2016-03-11 09:37:37 --> Total execution time: 1.1331
DEBUG - 2016-03-11 09:37:38 --> Config Class Initialized
DEBUG - 2016-03-11 09:37:38 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:37:38 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:37:38 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:37:38 --> URI Class Initialized
DEBUG - 2016-03-11 09:37:38 --> Router Class Initialized
DEBUG - 2016-03-11 09:37:38 --> Output Class Initialized
DEBUG - 2016-03-11 09:37:38 --> Security Class Initialized
DEBUG - 2016-03-11 09:37:38 --> Input Class Initialized
DEBUG - 2016-03-11 09:37:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:37:38 --> Language Class Initialized
DEBUG - 2016-03-11 09:37:38 --> Loader Class Initialized
DEBUG - 2016-03-11 09:37:38 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:37:38 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:37:38 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:37:38 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:37:38 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:37:39 --> Session Class Initialized
DEBUG - 2016-03-11 09:37:39 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:37:39 --> Session routines successfully run
DEBUG - 2016-03-11 09:37:39 --> Controller Class Initialized
DEBUG - 2016-03-11 09:37:39 --> Final output sent to browser
DEBUG - 2016-03-11 09:37:39 --> Total execution time: 1.1501
DEBUG - 2016-03-11 09:38:29 --> Config Class Initialized
DEBUG - 2016-03-11 09:38:29 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:38:29 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:38:29 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:38:29 --> URI Class Initialized
DEBUG - 2016-03-11 09:38:29 --> Router Class Initialized
DEBUG - 2016-03-11 09:38:29 --> Output Class Initialized
DEBUG - 2016-03-11 09:38:29 --> Security Class Initialized
DEBUG - 2016-03-11 09:38:29 --> Input Class Initialized
DEBUG - 2016-03-11 09:38:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:38:29 --> Language Class Initialized
DEBUG - 2016-03-11 09:38:29 --> Loader Class Initialized
DEBUG - 2016-03-11 09:38:29 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:38:29 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:38:29 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:38:29 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:38:29 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:38:30 --> Session Class Initialized
DEBUG - 2016-03-11 09:38:30 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:38:30 --> A session cookie was not found.
DEBUG - 2016-03-11 09:38:30 --> Session routines successfully run
DEBUG - 2016-03-11 09:38:30 --> Controller Class Initialized
DEBUG - 2016-03-11 09:38:30 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 09:38:30 --> Model Class Initialized
DEBUG - 2016-03-11 09:38:30 --> Model Class Initialized
DEBUG - 2016-03-11 09:38:30 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 09:38:30 --> Final output sent to browser
DEBUG - 2016-03-11 09:38:30 --> Total execution time: 1.1331
DEBUG - 2016-03-11 09:38:31 --> Config Class Initialized
DEBUG - 2016-03-11 09:38:31 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:38:31 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:38:31 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:38:31 --> URI Class Initialized
DEBUG - 2016-03-11 09:38:31 --> Router Class Initialized
DEBUG - 2016-03-11 09:38:31 --> Output Class Initialized
DEBUG - 2016-03-11 09:38:31 --> Security Class Initialized
DEBUG - 2016-03-11 09:38:31 --> Input Class Initialized
DEBUG - 2016-03-11 09:38:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:38:31 --> Language Class Initialized
DEBUG - 2016-03-11 09:38:31 --> Loader Class Initialized
DEBUG - 2016-03-11 09:38:31 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:38:31 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:38:31 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:38:31 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:38:31 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:38:32 --> Session Class Initialized
DEBUG - 2016-03-11 09:38:32 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:38:32 --> Session routines successfully run
DEBUG - 2016-03-11 09:38:32 --> Controller Class Initialized
DEBUG - 2016-03-11 09:38:32 --> Final output sent to browser
DEBUG - 2016-03-11 09:38:32 --> Total execution time: 1.1971
DEBUG - 2016-03-11 09:38:41 --> Config Class Initialized
DEBUG - 2016-03-11 09:38:41 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:38:41 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:38:41 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:38:41 --> URI Class Initialized
DEBUG - 2016-03-11 09:38:41 --> Router Class Initialized
DEBUG - 2016-03-11 09:38:41 --> Output Class Initialized
DEBUG - 2016-03-11 09:38:41 --> Security Class Initialized
DEBUG - 2016-03-11 09:38:41 --> Input Class Initialized
DEBUG - 2016-03-11 09:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:38:41 --> Language Class Initialized
DEBUG - 2016-03-11 09:38:41 --> Loader Class Initialized
DEBUG - 2016-03-11 09:38:41 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:38:41 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:38:41 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:38:41 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:38:41 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:38:42 --> Session Class Initialized
DEBUG - 2016-03-11 09:38:42 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:38:42 --> A session cookie was not found.
DEBUG - 2016-03-11 09:38:42 --> Session routines successfully run
DEBUG - 2016-03-11 09:38:42 --> Controller Class Initialized
DEBUG - 2016-03-11 09:38:42 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 09:38:42 --> Model Class Initialized
DEBUG - 2016-03-11 09:38:42 --> Model Class Initialized
DEBUG - 2016-03-11 09:38:42 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 09:38:42 --> Final output sent to browser
DEBUG - 2016-03-11 09:38:42 --> Total execution time: 1.1451
DEBUG - 2016-03-11 09:53:02 --> Config Class Initialized
DEBUG - 2016-03-11 09:53:02 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:53:02 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:53:02 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:53:02 --> URI Class Initialized
DEBUG - 2016-03-11 09:53:02 --> Router Class Initialized
DEBUG - 2016-03-11 09:53:02 --> Output Class Initialized
DEBUG - 2016-03-11 09:53:02 --> Security Class Initialized
DEBUG - 2016-03-11 09:53:02 --> Input Class Initialized
DEBUG - 2016-03-11 09:53:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:53:02 --> Language Class Initialized
DEBUG - 2016-03-11 09:53:02 --> Loader Class Initialized
DEBUG - 2016-03-11 09:53:02 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:53:02 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:53:02 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:53:02 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:53:02 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:53:03 --> Session Class Initialized
DEBUG - 2016-03-11 09:53:03 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:53:03 --> A session cookie was not found.
DEBUG - 2016-03-11 09:53:03 --> Session routines successfully run
DEBUG - 2016-03-11 09:53:03 --> Controller Class Initialized
DEBUG - 2016-03-11 09:53:03 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 09:53:03 --> Model Class Initialized
DEBUG - 2016-03-11 09:53:03 --> Model Class Initialized
DEBUG - 2016-03-11 09:53:03 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 09:53:03 --> Final output sent to browser
DEBUG - 2016-03-11 09:53:03 --> Total execution time: 1.1381
DEBUG - 2016-03-11 09:53:04 --> Config Class Initialized
DEBUG - 2016-03-11 09:53:04 --> Hooks Class Initialized
DEBUG - 2016-03-11 09:53:04 --> Utf8 Class Initialized
DEBUG - 2016-03-11 09:53:04 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 09:53:04 --> URI Class Initialized
DEBUG - 2016-03-11 09:53:04 --> Router Class Initialized
DEBUG - 2016-03-11 09:53:04 --> Output Class Initialized
DEBUG - 2016-03-11 09:53:04 --> Security Class Initialized
DEBUG - 2016-03-11 09:53:04 --> Input Class Initialized
DEBUG - 2016-03-11 09:53:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 09:53:04 --> Language Class Initialized
DEBUG - 2016-03-11 09:53:04 --> Loader Class Initialized
DEBUG - 2016-03-11 09:53:04 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 09:53:04 --> Helper loaded: url_helper
DEBUG - 2016-03-11 09:53:04 --> Helper loaded: image_helper
DEBUG - 2016-03-11 09:53:04 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 09:53:04 --> Database Driver Class Initialized
DEBUG - 2016-03-11 09:53:05 --> Session Class Initialized
DEBUG - 2016-03-11 09:53:05 --> Helper loaded: string_helper
DEBUG - 2016-03-11 09:53:05 --> Session routines successfully run
DEBUG - 2016-03-11 09:53:05 --> Controller Class Initialized
DEBUG - 2016-03-11 09:53:05 --> Final output sent to browser
DEBUG - 2016-03-11 09:53:05 --> Total execution time: 1.1121
DEBUG - 2016-03-11 10:47:20 --> Config Class Initialized
DEBUG - 2016-03-11 10:47:20 --> Hooks Class Initialized
DEBUG - 2016-03-11 10:47:20 --> Utf8 Class Initialized
DEBUG - 2016-03-11 10:47:20 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 10:47:20 --> URI Class Initialized
DEBUG - 2016-03-11 10:47:20 --> Router Class Initialized
DEBUG - 2016-03-11 10:47:20 --> Output Class Initialized
DEBUG - 2016-03-11 10:47:20 --> Security Class Initialized
DEBUG - 2016-03-11 10:47:20 --> Input Class Initialized
DEBUG - 2016-03-11 10:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 10:47:20 --> Language Class Initialized
DEBUG - 2016-03-11 10:47:20 --> Loader Class Initialized
DEBUG - 2016-03-11 10:47:20 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 10:47:20 --> Helper loaded: url_helper
DEBUG - 2016-03-11 10:47:20 --> Helper loaded: image_helper
DEBUG - 2016-03-11 10:47:20 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 10:47:20 --> Database Driver Class Initialized
DEBUG - 2016-03-11 10:47:21 --> Session Class Initialized
DEBUG - 2016-03-11 10:47:21 --> Helper loaded: string_helper
DEBUG - 2016-03-11 10:47:21 --> A session cookie was not found.
DEBUG - 2016-03-11 10:47:21 --> Session routines successfully run
DEBUG - 2016-03-11 10:47:21 --> Controller Class Initialized
DEBUG - 2016-03-11 10:47:21 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 10:47:21 --> Model Class Initialized
DEBUG - 2016-03-11 10:47:21 --> Model Class Initialized
DEBUG - 2016-03-11 10:47:21 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 10:47:21 --> Final output sent to browser
DEBUG - 2016-03-11 10:47:21 --> Total execution time: 1.1641
DEBUG - 2016-03-11 10:56:15 --> Config Class Initialized
DEBUG - 2016-03-11 10:56:15 --> Hooks Class Initialized
DEBUG - 2016-03-11 10:56:15 --> Utf8 Class Initialized
DEBUG - 2016-03-11 10:56:15 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 10:56:15 --> URI Class Initialized
DEBUG - 2016-03-11 10:56:15 --> Router Class Initialized
DEBUG - 2016-03-11 10:56:15 --> Output Class Initialized
DEBUG - 2016-03-11 10:56:15 --> Security Class Initialized
DEBUG - 2016-03-11 10:56:15 --> Input Class Initialized
DEBUG - 2016-03-11 10:56:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 10:56:15 --> Language Class Initialized
DEBUG - 2016-03-11 10:56:15 --> Loader Class Initialized
DEBUG - 2016-03-11 10:56:15 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 10:56:15 --> Helper loaded: url_helper
DEBUG - 2016-03-11 10:56:15 --> Helper loaded: image_helper
DEBUG - 2016-03-11 10:56:15 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 10:56:15 --> Database Driver Class Initialized
DEBUG - 2016-03-11 10:56:16 --> Session Class Initialized
DEBUG - 2016-03-11 10:56:16 --> Helper loaded: string_helper
DEBUG - 2016-03-11 10:56:16 --> A session cookie was not found.
DEBUG - 2016-03-11 10:56:16 --> Session routines successfully run
DEBUG - 2016-03-11 10:56:16 --> Controller Class Initialized
DEBUG - 2016-03-11 10:56:16 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 10:56:16 --> Model Class Initialized
DEBUG - 2016-03-11 10:56:16 --> Model Class Initialized
DEBUG - 2016-03-11 10:56:16 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 10:56:16 --> Final output sent to browser
DEBUG - 2016-03-11 10:56:16 --> Total execution time: 1.1501
DEBUG - 2016-03-11 10:56:17 --> Config Class Initialized
DEBUG - 2016-03-11 10:56:17 --> Hooks Class Initialized
DEBUG - 2016-03-11 10:56:17 --> Utf8 Class Initialized
DEBUG - 2016-03-11 10:56:17 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 10:56:17 --> URI Class Initialized
DEBUG - 2016-03-11 10:56:17 --> Router Class Initialized
DEBUG - 2016-03-11 10:56:17 --> Output Class Initialized
DEBUG - 2016-03-11 10:56:17 --> Security Class Initialized
DEBUG - 2016-03-11 10:56:17 --> Input Class Initialized
DEBUG - 2016-03-11 10:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 10:56:17 --> Language Class Initialized
DEBUG - 2016-03-11 10:56:17 --> Loader Class Initialized
DEBUG - 2016-03-11 10:56:17 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 10:56:17 --> Helper loaded: url_helper
DEBUG - 2016-03-11 10:56:17 --> Helper loaded: image_helper
DEBUG - 2016-03-11 10:56:17 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 10:56:17 --> Database Driver Class Initialized
DEBUG - 2016-03-11 10:56:18 --> Session Class Initialized
DEBUG - 2016-03-11 10:56:18 --> Helper loaded: string_helper
DEBUG - 2016-03-11 10:56:18 --> Session routines successfully run
DEBUG - 2016-03-11 10:56:18 --> Controller Class Initialized
DEBUG - 2016-03-11 10:56:18 --> Final output sent to browser
DEBUG - 2016-03-11 10:56:18 --> Total execution time: 1.2091
DEBUG - 2016-03-11 11:04:11 --> Config Class Initialized
DEBUG - 2016-03-11 11:04:11 --> Hooks Class Initialized
DEBUG - 2016-03-11 11:04:11 --> Utf8 Class Initialized
DEBUG - 2016-03-11 11:04:11 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 11:04:11 --> URI Class Initialized
DEBUG - 2016-03-11 11:04:11 --> Router Class Initialized
DEBUG - 2016-03-11 11:04:11 --> Output Class Initialized
DEBUG - 2016-03-11 11:04:11 --> Security Class Initialized
DEBUG - 2016-03-11 11:04:11 --> Input Class Initialized
DEBUG - 2016-03-11 11:04:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 11:04:11 --> Language Class Initialized
DEBUG - 2016-03-11 11:04:12 --> Loader Class Initialized
DEBUG - 2016-03-11 11:04:12 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 11:04:12 --> Helper loaded: url_helper
DEBUG - 2016-03-11 11:04:12 --> Helper loaded: image_helper
DEBUG - 2016-03-11 11:04:12 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 11:04:12 --> Database Driver Class Initialized
DEBUG - 2016-03-11 11:04:13 --> Session Class Initialized
DEBUG - 2016-03-11 11:04:13 --> Helper loaded: string_helper
DEBUG - 2016-03-11 11:04:13 --> A session cookie was not found.
DEBUG - 2016-03-11 11:04:13 --> Session routines successfully run
DEBUG - 2016-03-11 11:04:13 --> Controller Class Initialized
DEBUG - 2016-03-11 11:04:13 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 11:04:13 --> Model Class Initialized
DEBUG - 2016-03-11 11:04:13 --> Model Class Initialized
DEBUG - 2016-03-11 11:04:13 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 11:04:13 --> Final output sent to browser
DEBUG - 2016-03-11 11:04:13 --> Total execution time: 1.1311
DEBUG - 2016-03-11 11:04:13 --> Config Class Initialized
DEBUG - 2016-03-11 11:04:13 --> Hooks Class Initialized
DEBUG - 2016-03-11 11:04:13 --> Utf8 Class Initialized
DEBUG - 2016-03-11 11:04:13 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 11:04:13 --> URI Class Initialized
DEBUG - 2016-03-11 11:04:13 --> Router Class Initialized
DEBUG - 2016-03-11 11:04:13 --> Output Class Initialized
DEBUG - 2016-03-11 11:04:13 --> Security Class Initialized
DEBUG - 2016-03-11 11:04:13 --> Input Class Initialized
DEBUG - 2016-03-11 11:04:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 11:04:13 --> Language Class Initialized
DEBUG - 2016-03-11 11:04:13 --> Loader Class Initialized
DEBUG - 2016-03-11 11:04:13 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 11:04:13 --> Helper loaded: url_helper
DEBUG - 2016-03-11 11:04:13 --> Helper loaded: image_helper
DEBUG - 2016-03-11 11:04:13 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 11:04:13 --> Database Driver Class Initialized
DEBUG - 2016-03-11 11:04:14 --> Session Class Initialized
DEBUG - 2016-03-11 11:04:14 --> Helper loaded: string_helper
DEBUG - 2016-03-11 11:04:14 --> Session routines successfully run
DEBUG - 2016-03-11 11:04:14 --> Controller Class Initialized
DEBUG - 2016-03-11 11:04:14 --> Final output sent to browser
DEBUG - 2016-03-11 11:04:14 --> Total execution time: 1.1541
DEBUG - 2016-03-11 11:05:04 --> Config Class Initialized
DEBUG - 2016-03-11 11:05:04 --> Hooks Class Initialized
DEBUG - 2016-03-11 11:05:04 --> Utf8 Class Initialized
DEBUG - 2016-03-11 11:05:04 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 11:05:04 --> URI Class Initialized
DEBUG - 2016-03-11 11:05:04 --> Router Class Initialized
DEBUG - 2016-03-11 11:05:04 --> Output Class Initialized
DEBUG - 2016-03-11 11:05:04 --> Security Class Initialized
DEBUG - 2016-03-11 11:05:04 --> Input Class Initialized
DEBUG - 2016-03-11 11:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 11:05:04 --> Language Class Initialized
DEBUG - 2016-03-11 11:05:04 --> Loader Class Initialized
DEBUG - 2016-03-11 11:05:04 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 11:05:04 --> Helper loaded: url_helper
DEBUG - 2016-03-11 11:05:04 --> Helper loaded: image_helper
DEBUG - 2016-03-11 11:05:04 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 11:05:04 --> Database Driver Class Initialized
DEBUG - 2016-03-11 11:05:05 --> Session Class Initialized
DEBUG - 2016-03-11 11:05:05 --> Helper loaded: string_helper
DEBUG - 2016-03-11 11:05:05 --> A session cookie was not found.
DEBUG - 2016-03-11 11:05:05 --> Session routines successfully run
DEBUG - 2016-03-11 11:05:05 --> Controller Class Initialized
DEBUG - 2016-03-11 11:05:05 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 11:05:05 --> Model Class Initialized
DEBUG - 2016-03-11 11:05:05 --> Model Class Initialized
DEBUG - 2016-03-11 11:05:05 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 11:05:05 --> Final output sent to browser
DEBUG - 2016-03-11 11:05:05 --> Total execution time: 1.1521
DEBUG - 2016-03-11 11:05:06 --> Config Class Initialized
DEBUG - 2016-03-11 11:05:06 --> Hooks Class Initialized
DEBUG - 2016-03-11 11:05:06 --> Utf8 Class Initialized
DEBUG - 2016-03-11 11:05:06 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 11:05:06 --> URI Class Initialized
DEBUG - 2016-03-11 11:05:06 --> Router Class Initialized
DEBUG - 2016-03-11 11:05:06 --> Output Class Initialized
DEBUG - 2016-03-11 11:05:06 --> Security Class Initialized
DEBUG - 2016-03-11 11:05:06 --> Input Class Initialized
DEBUG - 2016-03-11 11:05:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 11:05:06 --> Language Class Initialized
DEBUG - 2016-03-11 11:05:06 --> Loader Class Initialized
DEBUG - 2016-03-11 11:05:06 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 11:05:06 --> Helper loaded: url_helper
DEBUG - 2016-03-11 11:05:06 --> Helper loaded: image_helper
DEBUG - 2016-03-11 11:05:06 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 11:05:06 --> Database Driver Class Initialized
DEBUG - 2016-03-11 11:05:07 --> Session Class Initialized
DEBUG - 2016-03-11 11:05:07 --> Helper loaded: string_helper
DEBUG - 2016-03-11 11:05:07 --> Session routines successfully run
DEBUG - 2016-03-11 11:05:07 --> Controller Class Initialized
DEBUG - 2016-03-11 11:05:07 --> Final output sent to browser
DEBUG - 2016-03-11 11:05:07 --> Total execution time: 1.2131
DEBUG - 2016-03-11 11:07:09 --> Config Class Initialized
DEBUG - 2016-03-11 11:07:09 --> Hooks Class Initialized
DEBUG - 2016-03-11 11:07:09 --> Utf8 Class Initialized
DEBUG - 2016-03-11 11:07:09 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 11:07:09 --> URI Class Initialized
DEBUG - 2016-03-11 11:07:09 --> Router Class Initialized
DEBUG - 2016-03-11 11:07:09 --> Output Class Initialized
DEBUG - 2016-03-11 11:07:09 --> Security Class Initialized
DEBUG - 2016-03-11 11:07:09 --> Input Class Initialized
DEBUG - 2016-03-11 11:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 11:07:09 --> Language Class Initialized
DEBUG - 2016-03-11 11:07:09 --> Loader Class Initialized
DEBUG - 2016-03-11 11:07:09 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 11:07:09 --> Helper loaded: url_helper
DEBUG - 2016-03-11 11:07:09 --> Helper loaded: image_helper
DEBUG - 2016-03-11 11:07:09 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 11:07:09 --> Database Driver Class Initialized
DEBUG - 2016-03-11 11:07:10 --> Session Class Initialized
DEBUG - 2016-03-11 11:07:10 --> Helper loaded: string_helper
DEBUG - 2016-03-11 11:07:10 --> A session cookie was not found.
DEBUG - 2016-03-11 11:07:10 --> Session routines successfully run
DEBUG - 2016-03-11 11:07:10 --> Controller Class Initialized
DEBUG - 2016-03-11 11:07:10 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 11:07:10 --> Model Class Initialized
DEBUG - 2016-03-11 11:07:10 --> Model Class Initialized
DEBUG - 2016-03-11 11:07:10 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 11:07:10 --> Final output sent to browser
DEBUG - 2016-03-11 11:07:10 --> Total execution time: 1.1591
DEBUG - 2016-03-11 11:07:11 --> Config Class Initialized
DEBUG - 2016-03-11 11:07:11 --> Hooks Class Initialized
DEBUG - 2016-03-11 11:07:11 --> Utf8 Class Initialized
DEBUG - 2016-03-11 11:07:11 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 11:07:11 --> URI Class Initialized
DEBUG - 2016-03-11 11:07:11 --> Router Class Initialized
DEBUG - 2016-03-11 11:07:11 --> Output Class Initialized
DEBUG - 2016-03-11 11:07:11 --> Security Class Initialized
DEBUG - 2016-03-11 11:07:11 --> Input Class Initialized
DEBUG - 2016-03-11 11:07:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 11:07:11 --> Language Class Initialized
DEBUG - 2016-03-11 11:07:11 --> Loader Class Initialized
DEBUG - 2016-03-11 11:07:11 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 11:07:11 --> Helper loaded: url_helper
DEBUG - 2016-03-11 11:07:11 --> Helper loaded: image_helper
DEBUG - 2016-03-11 11:07:11 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 11:07:11 --> Database Driver Class Initialized
DEBUG - 2016-03-11 11:07:12 --> Session Class Initialized
DEBUG - 2016-03-11 11:07:12 --> Helper loaded: string_helper
DEBUG - 2016-03-11 11:07:12 --> Session routines successfully run
DEBUG - 2016-03-11 11:07:12 --> Controller Class Initialized
DEBUG - 2016-03-11 11:07:12 --> Final output sent to browser
DEBUG - 2016-03-11 11:07:12 --> Total execution time: 1.2171
DEBUG - 2016-03-11 11:07:31 --> Config Class Initialized
DEBUG - 2016-03-11 11:07:31 --> Hooks Class Initialized
DEBUG - 2016-03-11 11:07:31 --> Utf8 Class Initialized
DEBUG - 2016-03-11 11:07:31 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 11:07:31 --> URI Class Initialized
DEBUG - 2016-03-11 11:07:31 --> Router Class Initialized
DEBUG - 2016-03-11 11:07:31 --> Output Class Initialized
DEBUG - 2016-03-11 11:07:31 --> Security Class Initialized
DEBUG - 2016-03-11 11:07:31 --> Input Class Initialized
DEBUG - 2016-03-11 11:07:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 11:07:31 --> Language Class Initialized
DEBUG - 2016-03-11 11:07:31 --> Loader Class Initialized
DEBUG - 2016-03-11 11:07:31 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 11:07:31 --> Helper loaded: url_helper
DEBUG - 2016-03-11 11:07:31 --> Helper loaded: image_helper
DEBUG - 2016-03-11 11:07:31 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 11:07:31 --> Database Driver Class Initialized
DEBUG - 2016-03-11 11:07:32 --> Session Class Initialized
DEBUG - 2016-03-11 11:07:32 --> Helper loaded: string_helper
DEBUG - 2016-03-11 11:07:32 --> A session cookie was not found.
DEBUG - 2016-03-11 11:07:32 --> Session routines successfully run
DEBUG - 2016-03-11 11:07:32 --> Controller Class Initialized
DEBUG - 2016-03-11 11:07:32 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 11:07:32 --> Model Class Initialized
DEBUG - 2016-03-11 11:07:32 --> Model Class Initialized
DEBUG - 2016-03-11 11:07:32 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 11:07:32 --> Final output sent to browser
DEBUG - 2016-03-11 11:07:32 --> Total execution time: 1.1431
DEBUG - 2016-03-11 11:07:33 --> Config Class Initialized
DEBUG - 2016-03-11 11:07:33 --> Hooks Class Initialized
DEBUG - 2016-03-11 11:07:33 --> Utf8 Class Initialized
DEBUG - 2016-03-11 11:07:33 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 11:07:33 --> URI Class Initialized
DEBUG - 2016-03-11 11:07:33 --> Router Class Initialized
DEBUG - 2016-03-11 11:07:33 --> Output Class Initialized
DEBUG - 2016-03-11 11:07:33 --> Security Class Initialized
DEBUG - 2016-03-11 11:07:33 --> Input Class Initialized
DEBUG - 2016-03-11 11:07:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 11:07:33 --> Language Class Initialized
DEBUG - 2016-03-11 11:07:33 --> Loader Class Initialized
DEBUG - 2016-03-11 11:07:33 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 11:07:33 --> Helper loaded: url_helper
DEBUG - 2016-03-11 11:07:33 --> Helper loaded: image_helper
DEBUG - 2016-03-11 11:07:33 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 11:07:33 --> Database Driver Class Initialized
DEBUG - 2016-03-11 11:07:34 --> Session Class Initialized
DEBUG - 2016-03-11 11:07:34 --> Helper loaded: string_helper
DEBUG - 2016-03-11 11:07:34 --> Session routines successfully run
DEBUG - 2016-03-11 11:07:34 --> Controller Class Initialized
DEBUG - 2016-03-11 11:07:34 --> Final output sent to browser
DEBUG - 2016-03-11 11:07:34 --> Total execution time: 1.1531
DEBUG - 2016-03-11 11:07:47 --> Config Class Initialized
DEBUG - 2016-03-11 11:07:47 --> Hooks Class Initialized
DEBUG - 2016-03-11 11:07:47 --> Utf8 Class Initialized
DEBUG - 2016-03-11 11:07:47 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 11:07:47 --> URI Class Initialized
DEBUG - 2016-03-11 11:07:47 --> Router Class Initialized
DEBUG - 2016-03-11 11:07:47 --> Output Class Initialized
DEBUG - 2016-03-11 11:07:47 --> Security Class Initialized
DEBUG - 2016-03-11 11:07:47 --> Input Class Initialized
DEBUG - 2016-03-11 11:07:47 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 11:07:47 --> Language Class Initialized
DEBUG - 2016-03-11 11:07:47 --> Loader Class Initialized
DEBUG - 2016-03-11 11:07:47 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 11:07:47 --> Helper loaded: url_helper
DEBUG - 2016-03-11 11:07:47 --> Helper loaded: image_helper
DEBUG - 2016-03-11 11:07:47 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 11:07:47 --> Database Driver Class Initialized
DEBUG - 2016-03-11 11:07:48 --> Session Class Initialized
DEBUG - 2016-03-11 11:07:48 --> Helper loaded: string_helper
DEBUG - 2016-03-11 11:07:48 --> A session cookie was not found.
DEBUG - 2016-03-11 11:07:48 --> Session routines successfully run
DEBUG - 2016-03-11 11:07:48 --> Controller Class Initialized
DEBUG - 2016-03-11 11:07:48 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 11:07:48 --> Model Class Initialized
DEBUG - 2016-03-11 11:07:48 --> Model Class Initialized
DEBUG - 2016-03-11 11:07:48 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 11:07:48 --> Final output sent to browser
DEBUG - 2016-03-11 11:07:48 --> Total execution time: 1.1761
DEBUG - 2016-03-11 11:07:49 --> Config Class Initialized
DEBUG - 2016-03-11 11:07:49 --> Hooks Class Initialized
DEBUG - 2016-03-11 11:07:49 --> Utf8 Class Initialized
DEBUG - 2016-03-11 11:07:49 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 11:07:49 --> URI Class Initialized
DEBUG - 2016-03-11 11:07:49 --> Router Class Initialized
DEBUG - 2016-03-11 11:07:49 --> Output Class Initialized
DEBUG - 2016-03-11 11:07:49 --> Security Class Initialized
DEBUG - 2016-03-11 11:07:49 --> Input Class Initialized
DEBUG - 2016-03-11 11:07:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 11:07:49 --> Language Class Initialized
DEBUG - 2016-03-11 11:07:49 --> Loader Class Initialized
DEBUG - 2016-03-11 11:07:49 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 11:07:49 --> Helper loaded: url_helper
DEBUG - 2016-03-11 11:07:49 --> Helper loaded: image_helper
DEBUG - 2016-03-11 11:07:49 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 11:07:49 --> Database Driver Class Initialized
DEBUG - 2016-03-11 11:07:50 --> Session Class Initialized
DEBUG - 2016-03-11 11:07:50 --> Helper loaded: string_helper
DEBUG - 2016-03-11 11:07:50 --> Session routines successfully run
DEBUG - 2016-03-11 11:07:50 --> Controller Class Initialized
DEBUG - 2016-03-11 11:07:50 --> Final output sent to browser
DEBUG - 2016-03-11 11:07:50 --> Total execution time: 1.1521
DEBUG - 2016-03-11 11:09:14 --> Config Class Initialized
DEBUG - 2016-03-11 11:09:14 --> Hooks Class Initialized
DEBUG - 2016-03-11 11:09:14 --> Utf8 Class Initialized
DEBUG - 2016-03-11 11:09:14 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 11:09:14 --> URI Class Initialized
DEBUG - 2016-03-11 11:09:14 --> Router Class Initialized
DEBUG - 2016-03-11 11:09:14 --> Output Class Initialized
DEBUG - 2016-03-11 11:09:14 --> Security Class Initialized
DEBUG - 2016-03-11 11:09:14 --> Input Class Initialized
DEBUG - 2016-03-11 11:09:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 11:09:14 --> Language Class Initialized
DEBUG - 2016-03-11 11:09:14 --> Loader Class Initialized
DEBUG - 2016-03-11 11:09:14 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 11:09:14 --> Helper loaded: url_helper
DEBUG - 2016-03-11 11:09:14 --> Helper loaded: image_helper
DEBUG - 2016-03-11 11:09:14 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 11:09:14 --> Database Driver Class Initialized
DEBUG - 2016-03-11 11:09:15 --> Session Class Initialized
DEBUG - 2016-03-11 11:09:15 --> Helper loaded: string_helper
DEBUG - 2016-03-11 11:09:15 --> A session cookie was not found.
DEBUG - 2016-03-11 11:09:15 --> Session routines successfully run
DEBUG - 2016-03-11 11:09:15 --> Controller Class Initialized
DEBUG - 2016-03-11 11:09:15 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 11:09:15 --> Model Class Initialized
DEBUG - 2016-03-11 11:09:15 --> Model Class Initialized
DEBUG - 2016-03-11 11:09:15 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 11:09:15 --> Final output sent to browser
DEBUG - 2016-03-11 11:09:15 --> Total execution time: 1.1391
DEBUG - 2016-03-11 11:09:16 --> Config Class Initialized
DEBUG - 2016-03-11 11:09:16 --> Hooks Class Initialized
DEBUG - 2016-03-11 11:09:16 --> Utf8 Class Initialized
DEBUG - 2016-03-11 11:09:16 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 11:09:16 --> URI Class Initialized
DEBUG - 2016-03-11 11:09:16 --> Router Class Initialized
DEBUG - 2016-03-11 11:09:16 --> Output Class Initialized
DEBUG - 2016-03-11 11:09:16 --> Security Class Initialized
DEBUG - 2016-03-11 11:09:16 --> Input Class Initialized
DEBUG - 2016-03-11 11:09:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 11:09:16 --> Language Class Initialized
DEBUG - 2016-03-11 11:09:16 --> Loader Class Initialized
DEBUG - 2016-03-11 11:09:16 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 11:09:16 --> Helper loaded: url_helper
DEBUG - 2016-03-11 11:09:16 --> Helper loaded: image_helper
DEBUG - 2016-03-11 11:09:16 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 11:09:16 --> Database Driver Class Initialized
DEBUG - 2016-03-11 11:09:17 --> Session Class Initialized
DEBUG - 2016-03-11 11:09:17 --> Helper loaded: string_helper
DEBUG - 2016-03-11 11:09:17 --> Session routines successfully run
DEBUG - 2016-03-11 11:09:17 --> Controller Class Initialized
DEBUG - 2016-03-11 11:09:17 --> Final output sent to browser
DEBUG - 2016-03-11 11:09:17 --> Total execution time: 1.1651
DEBUG - 2016-03-11 11:09:32 --> Config Class Initialized
DEBUG - 2016-03-11 11:09:32 --> Hooks Class Initialized
DEBUG - 2016-03-11 11:09:32 --> Utf8 Class Initialized
DEBUG - 2016-03-11 11:09:32 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 11:09:32 --> URI Class Initialized
DEBUG - 2016-03-11 11:09:32 --> Router Class Initialized
DEBUG - 2016-03-11 11:09:32 --> Output Class Initialized
DEBUG - 2016-03-11 11:09:32 --> Security Class Initialized
DEBUG - 2016-03-11 11:09:32 --> Input Class Initialized
DEBUG - 2016-03-11 11:09:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 11:09:32 --> Language Class Initialized
DEBUG - 2016-03-11 11:09:32 --> Loader Class Initialized
DEBUG - 2016-03-11 11:09:32 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 11:09:32 --> Helper loaded: url_helper
DEBUG - 2016-03-11 11:09:32 --> Helper loaded: image_helper
DEBUG - 2016-03-11 11:09:32 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 11:09:32 --> Database Driver Class Initialized
DEBUG - 2016-03-11 11:09:33 --> Session Class Initialized
DEBUG - 2016-03-11 11:09:33 --> Helper loaded: string_helper
DEBUG - 2016-03-11 11:09:33 --> A session cookie was not found.
DEBUG - 2016-03-11 11:09:33 --> Session routines successfully run
DEBUG - 2016-03-11 11:09:33 --> Controller Class Initialized
DEBUG - 2016-03-11 11:09:33 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 11:09:33 --> Model Class Initialized
DEBUG - 2016-03-11 11:09:33 --> Model Class Initialized
DEBUG - 2016-03-11 11:09:33 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 11:09:33 --> Final output sent to browser
DEBUG - 2016-03-11 11:09:33 --> Total execution time: 1.1891
DEBUG - 2016-03-11 11:14:33 --> Config Class Initialized
DEBUG - 2016-03-11 11:14:33 --> Hooks Class Initialized
DEBUG - 2016-03-11 11:14:33 --> Utf8 Class Initialized
DEBUG - 2016-03-11 11:14:33 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 11:14:33 --> URI Class Initialized
DEBUG - 2016-03-11 11:14:33 --> Router Class Initialized
DEBUG - 2016-03-11 11:14:33 --> Output Class Initialized
DEBUG - 2016-03-11 11:14:33 --> Security Class Initialized
DEBUG - 2016-03-11 11:14:33 --> Input Class Initialized
DEBUG - 2016-03-11 11:14:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 11:14:33 --> Language Class Initialized
DEBUG - 2016-03-11 11:14:33 --> Loader Class Initialized
DEBUG - 2016-03-11 11:14:33 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 11:14:33 --> Helper loaded: url_helper
DEBUG - 2016-03-11 11:14:33 --> Helper loaded: image_helper
DEBUG - 2016-03-11 11:14:33 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 11:14:33 --> Database Driver Class Initialized
DEBUG - 2016-03-11 11:14:34 --> Session Class Initialized
DEBUG - 2016-03-11 11:14:34 --> Helper loaded: string_helper
DEBUG - 2016-03-11 11:14:34 --> A session cookie was not found.
DEBUG - 2016-03-11 11:14:34 --> Session routines successfully run
DEBUG - 2016-03-11 11:14:34 --> Controller Class Initialized
DEBUG - 2016-03-11 11:14:34 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 11:14:34 --> Model Class Initialized
DEBUG - 2016-03-11 11:14:34 --> Model Class Initialized
DEBUG - 2016-03-11 11:14:34 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 11:14:34 --> Final output sent to browser
DEBUG - 2016-03-11 11:14:34 --> Total execution time: 1.1481
DEBUG - 2016-03-11 11:16:23 --> Config Class Initialized
DEBUG - 2016-03-11 11:16:23 --> Hooks Class Initialized
DEBUG - 2016-03-11 11:16:23 --> Utf8 Class Initialized
DEBUG - 2016-03-11 11:16:23 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 11:16:23 --> URI Class Initialized
DEBUG - 2016-03-11 11:16:23 --> Router Class Initialized
DEBUG - 2016-03-11 11:16:23 --> Output Class Initialized
DEBUG - 2016-03-11 11:16:23 --> Security Class Initialized
DEBUG - 2016-03-11 11:16:23 --> Input Class Initialized
DEBUG - 2016-03-11 11:16:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 11:16:23 --> Language Class Initialized
DEBUG - 2016-03-11 11:16:23 --> Loader Class Initialized
DEBUG - 2016-03-11 11:16:23 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 11:16:23 --> Helper loaded: url_helper
DEBUG - 2016-03-11 11:16:23 --> Helper loaded: image_helper
DEBUG - 2016-03-11 11:16:23 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 11:16:23 --> Database Driver Class Initialized
DEBUG - 2016-03-11 11:16:24 --> Session Class Initialized
DEBUG - 2016-03-11 11:16:24 --> Helper loaded: string_helper
DEBUG - 2016-03-11 11:16:24 --> A session cookie was not found.
DEBUG - 2016-03-11 11:16:24 --> Session routines successfully run
DEBUG - 2016-03-11 11:16:24 --> Controller Class Initialized
DEBUG - 2016-03-11 11:16:24 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 11:16:24 --> Model Class Initialized
DEBUG - 2016-03-11 11:16:24 --> Model Class Initialized
DEBUG - 2016-03-11 11:16:24 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 11:16:24 --> Final output sent to browser
DEBUG - 2016-03-11 11:16:24 --> Total execution time: 1.1391
DEBUG - 2016-03-11 11:16:25 --> Config Class Initialized
DEBUG - 2016-03-11 11:16:25 --> Hooks Class Initialized
DEBUG - 2016-03-11 11:16:25 --> Utf8 Class Initialized
DEBUG - 2016-03-11 11:16:25 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 11:16:25 --> URI Class Initialized
DEBUG - 2016-03-11 11:16:25 --> Router Class Initialized
DEBUG - 2016-03-11 11:16:25 --> Output Class Initialized
DEBUG - 2016-03-11 11:16:25 --> Security Class Initialized
DEBUG - 2016-03-11 11:16:25 --> Input Class Initialized
DEBUG - 2016-03-11 11:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 11:16:25 --> Language Class Initialized
DEBUG - 2016-03-11 11:16:25 --> Loader Class Initialized
DEBUG - 2016-03-11 11:16:25 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 11:16:25 --> Helper loaded: url_helper
DEBUG - 2016-03-11 11:16:25 --> Helper loaded: image_helper
DEBUG - 2016-03-11 11:16:25 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 11:16:25 --> Database Driver Class Initialized
DEBUG - 2016-03-11 11:16:26 --> Session Class Initialized
DEBUG - 2016-03-11 11:16:26 --> Helper loaded: string_helper
DEBUG - 2016-03-11 11:16:26 --> Session routines successfully run
DEBUG - 2016-03-11 11:16:26 --> Controller Class Initialized
DEBUG - 2016-03-11 11:16:26 --> Final output sent to browser
DEBUG - 2016-03-11 11:16:26 --> Total execution time: 1.1861
DEBUG - 2016-03-11 15:17:27 --> Config Class Initialized
DEBUG - 2016-03-11 15:17:27 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:17:27 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:17:27 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:17:27 --> URI Class Initialized
DEBUG - 2016-03-11 15:17:27 --> Router Class Initialized
DEBUG - 2016-03-11 15:17:27 --> Output Class Initialized
DEBUG - 2016-03-11 15:17:27 --> Security Class Initialized
DEBUG - 2016-03-11 15:17:27 --> Input Class Initialized
DEBUG - 2016-03-11 15:17:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:17:27 --> Language Class Initialized
DEBUG - 2016-03-11 15:17:54 --> Config Class Initialized
DEBUG - 2016-03-11 15:17:54 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:17:54 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:17:54 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:17:54 --> URI Class Initialized
DEBUG - 2016-03-11 15:17:54 --> Router Class Initialized
DEBUG - 2016-03-11 15:17:54 --> Output Class Initialized
DEBUG - 2016-03-11 15:17:54 --> Security Class Initialized
DEBUG - 2016-03-11 15:17:54 --> Input Class Initialized
DEBUG - 2016-03-11 15:17:54 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:17:54 --> Language Class Initialized
DEBUG - 2016-03-11 15:17:54 --> Loader Class Initialized
DEBUG - 2016-03-11 15:17:54 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:17:54 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:17:55 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:17:55 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:17:55 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:17:56 --> Session Class Initialized
DEBUG - 2016-03-11 15:17:56 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:17:56 --> A session cookie was not found.
DEBUG - 2016-03-11 15:17:56 --> Session routines successfully run
DEBUG - 2016-03-11 15:17:56 --> Controller Class Initialized
DEBUG - 2016-03-11 15:17:56 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:17:56 --> Model Class Initialized
DEBUG - 2016-03-11 15:17:56 --> Model Class Initialized
ERROR - 2016-03-11 15:17:56 --> Severity: Notice  --> Undefined property: Campanha::$dist D:\xampp\htdocs\superacao\_cmp\application\controllers\campanha.php 15
DEBUG - 2016-03-11 15:17:56 --> File loaded: application/views/campanhas_listar.php
DEBUG - 2016-03-11 15:17:56 --> Final output sent to browser
DEBUG - 2016-03-11 15:17:56 --> Total execution time: 1.4471
DEBUG - 2016-03-11 15:17:57 --> Config Class Initialized
DEBUG - 2016-03-11 15:17:57 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:17:57 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:17:57 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:17:57 --> URI Class Initialized
DEBUG - 2016-03-11 15:17:57 --> Router Class Initialized
DEBUG - 2016-03-11 15:17:57 --> Output Class Initialized
DEBUG - 2016-03-11 15:17:57 --> Security Class Initialized
DEBUG - 2016-03-11 15:17:57 --> Input Class Initialized
DEBUG - 2016-03-11 15:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:17:57 --> Language Class Initialized
DEBUG - 2016-03-11 15:17:57 --> Loader Class Initialized
DEBUG - 2016-03-11 15:17:57 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:17:57 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:17:57 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:17:57 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:17:57 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:17:58 --> Session Class Initialized
DEBUG - 2016-03-11 15:17:58 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:17:58 --> A session cookie was not found.
DEBUG - 2016-03-11 15:17:58 --> Session routines successfully run
DEBUG - 2016-03-11 15:17:58 --> Controller Class Initialized
DEBUG - 2016-03-11 15:17:58 --> Final output sent to browser
DEBUG - 2016-03-11 15:17:58 --> Total execution time: 1.1561
DEBUG - 2016-03-11 15:18:13 --> Config Class Initialized
DEBUG - 2016-03-11 15:18:13 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:18:13 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:18:13 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:18:13 --> URI Class Initialized
DEBUG - 2016-03-11 15:18:13 --> Router Class Initialized
DEBUG - 2016-03-11 15:18:13 --> Output Class Initialized
DEBUG - 2016-03-11 15:18:13 --> Security Class Initialized
DEBUG - 2016-03-11 15:18:13 --> Input Class Initialized
DEBUG - 2016-03-11 15:18:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:18:13 --> Language Class Initialized
DEBUG - 2016-03-11 15:18:13 --> Loader Class Initialized
DEBUG - 2016-03-11 15:18:13 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:18:13 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:18:13 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:18:13 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:18:13 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:18:14 --> Session Class Initialized
DEBUG - 2016-03-11 15:18:14 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:18:14 --> A session cookie was not found.
DEBUG - 2016-03-11 15:18:14 --> Session routines successfully run
DEBUG - 2016-03-11 15:18:14 --> Controller Class Initialized
DEBUG - 2016-03-11 15:18:14 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:18:14 --> Model Class Initialized
DEBUG - 2016-03-11 15:18:14 --> Model Class Initialized
DEBUG - 2016-03-11 15:18:14 --> File loaded: application/views/campanhas_listar.php
DEBUG - 2016-03-11 15:18:14 --> Final output sent to browser
DEBUG - 2016-03-11 15:18:14 --> Total execution time: 1.1551
DEBUG - 2016-03-11 15:18:15 --> Config Class Initialized
DEBUG - 2016-03-11 15:18:15 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:18:15 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:18:15 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:18:15 --> URI Class Initialized
DEBUG - 2016-03-11 15:18:15 --> Router Class Initialized
DEBUG - 2016-03-11 15:18:15 --> Output Class Initialized
DEBUG - 2016-03-11 15:18:15 --> Security Class Initialized
DEBUG - 2016-03-11 15:18:15 --> Input Class Initialized
DEBUG - 2016-03-11 15:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:18:15 --> Language Class Initialized
DEBUG - 2016-03-11 15:18:15 --> Loader Class Initialized
DEBUG - 2016-03-11 15:18:15 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:18:15 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:18:15 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:18:15 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:18:15 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:18:16 --> Session Class Initialized
DEBUG - 2016-03-11 15:18:16 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:18:16 --> Session routines successfully run
DEBUG - 2016-03-11 15:18:16 --> Controller Class Initialized
DEBUG - 2016-03-11 15:18:16 --> Final output sent to browser
DEBUG - 2016-03-11 15:18:16 --> Total execution time: 1.1311
DEBUG - 2016-03-11 15:18:26 --> Config Class Initialized
DEBUG - 2016-03-11 15:18:26 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:18:26 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:18:26 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:18:26 --> URI Class Initialized
DEBUG - 2016-03-11 15:18:26 --> Router Class Initialized
DEBUG - 2016-03-11 15:18:26 --> Output Class Initialized
DEBUG - 2016-03-11 15:18:26 --> Security Class Initialized
DEBUG - 2016-03-11 15:18:26 --> Input Class Initialized
DEBUG - 2016-03-11 15:18:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:18:26 --> Language Class Initialized
DEBUG - 2016-03-11 15:18:26 --> Loader Class Initialized
DEBUG - 2016-03-11 15:18:26 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:18:26 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:18:26 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:18:26 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:18:26 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:18:27 --> Session Class Initialized
DEBUG - 2016-03-11 15:18:27 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:18:27 --> Session routines successfully run
DEBUG - 2016-03-11 15:18:27 --> Controller Class Initialized
DEBUG - 2016-03-11 15:18:27 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:18:27 --> Model Class Initialized
DEBUG - 2016-03-11 15:18:27 --> Model Class Initialized
DEBUG - 2016-03-11 15:18:27 --> Final output sent to browser
DEBUG - 2016-03-11 15:18:27 --> Total execution time: 1.2470
DEBUG - 2016-03-11 15:18:33 --> Config Class Initialized
DEBUG - 2016-03-11 15:18:33 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:18:33 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:18:33 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:18:33 --> URI Class Initialized
DEBUG - 2016-03-11 15:18:33 --> Router Class Initialized
DEBUG - 2016-03-11 15:18:33 --> Output Class Initialized
DEBUG - 2016-03-11 15:18:33 --> Security Class Initialized
DEBUG - 2016-03-11 15:18:33 --> Input Class Initialized
DEBUG - 2016-03-11 15:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:18:33 --> Language Class Initialized
DEBUG - 2016-03-11 15:18:33 --> Loader Class Initialized
DEBUG - 2016-03-11 15:18:33 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:18:33 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:18:33 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:18:33 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:18:33 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:18:34 --> Session Class Initialized
DEBUG - 2016-03-11 15:18:34 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:18:34 --> Session routines successfully run
DEBUG - 2016-03-11 15:18:34 --> Controller Class Initialized
DEBUG - 2016-03-11 15:18:34 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:18:34 --> Model Class Initialized
DEBUG - 2016-03-11 15:18:34 --> Model Class Initialized
DEBUG - 2016-03-11 15:18:34 --> Final output sent to browser
DEBUG - 2016-03-11 15:18:34 --> Total execution time: 1.2330
DEBUG - 2016-03-11 15:19:07 --> Config Class Initialized
DEBUG - 2016-03-11 15:19:07 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:19:07 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:19:07 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:19:07 --> URI Class Initialized
DEBUG - 2016-03-11 15:19:07 --> Router Class Initialized
DEBUG - 2016-03-11 15:19:07 --> Output Class Initialized
DEBUG - 2016-03-11 15:19:07 --> Security Class Initialized
DEBUG - 2016-03-11 15:19:07 --> Input Class Initialized
DEBUG - 2016-03-11 15:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:19:07 --> Language Class Initialized
DEBUG - 2016-03-11 15:19:07 --> Loader Class Initialized
DEBUG - 2016-03-11 15:19:07 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:19:07 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:19:07 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:19:07 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:19:07 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:19:09 --> Session Class Initialized
DEBUG - 2016-03-11 15:19:09 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:19:09 --> A session cookie was not found.
DEBUG - 2016-03-11 15:19:09 --> Session routines successfully run
DEBUG - 2016-03-11 15:19:09 --> Controller Class Initialized
DEBUG - 2016-03-11 15:19:09 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:19:09 --> Model Class Initialized
DEBUG - 2016-03-11 15:19:09 --> Model Class Initialized
DEBUG - 2016-03-11 15:19:09 --> File loaded: application/views/campanhas_listar.php
DEBUG - 2016-03-11 15:19:09 --> Final output sent to browser
DEBUG - 2016-03-11 15:19:09 --> Total execution time: 1.1571
DEBUG - 2016-03-11 15:19:09 --> Config Class Initialized
DEBUG - 2016-03-11 15:19:09 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:19:09 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:19:09 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:19:09 --> URI Class Initialized
DEBUG - 2016-03-11 15:19:09 --> Router Class Initialized
DEBUG - 2016-03-11 15:19:09 --> Output Class Initialized
DEBUG - 2016-03-11 15:19:09 --> Security Class Initialized
DEBUG - 2016-03-11 15:19:09 --> Input Class Initialized
DEBUG - 2016-03-11 15:19:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:19:09 --> Language Class Initialized
DEBUG - 2016-03-11 15:19:09 --> Loader Class Initialized
DEBUG - 2016-03-11 15:19:09 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:19:09 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:19:09 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:19:09 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:19:09 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:19:10 --> Session Class Initialized
DEBUG - 2016-03-11 15:19:10 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:19:10 --> Session routines successfully run
DEBUG - 2016-03-11 15:19:10 --> Controller Class Initialized
DEBUG - 2016-03-11 15:19:10 --> Final output sent to browser
DEBUG - 2016-03-11 15:19:10 --> Total execution time: 1.1461
DEBUG - 2016-03-11 15:19:14 --> Config Class Initialized
DEBUG - 2016-03-11 15:19:14 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:19:14 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:19:14 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:19:14 --> URI Class Initialized
DEBUG - 2016-03-11 15:19:14 --> Router Class Initialized
DEBUG - 2016-03-11 15:19:14 --> Output Class Initialized
DEBUG - 2016-03-11 15:19:14 --> Security Class Initialized
DEBUG - 2016-03-11 15:19:14 --> Input Class Initialized
DEBUG - 2016-03-11 15:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:19:14 --> Language Class Initialized
DEBUG - 2016-03-11 15:19:14 --> Loader Class Initialized
DEBUG - 2016-03-11 15:19:14 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:19:14 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:19:14 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:19:14 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:19:14 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:19:15 --> Session Class Initialized
DEBUG - 2016-03-11 15:19:15 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:19:15 --> Session routines successfully run
DEBUG - 2016-03-11 15:19:15 --> Controller Class Initialized
DEBUG - 2016-03-11 15:19:15 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:19:15 --> Model Class Initialized
DEBUG - 2016-03-11 15:19:15 --> Model Class Initialized
DEBUG - 2016-03-11 15:19:16 --> Final output sent to browser
DEBUG - 2016-03-11 15:19:16 --> Total execution time: 1.2771
DEBUG - 2016-03-11 15:19:58 --> Config Class Initialized
DEBUG - 2016-03-11 15:19:58 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:19:58 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:19:58 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:19:58 --> URI Class Initialized
DEBUG - 2016-03-11 15:19:58 --> Router Class Initialized
DEBUG - 2016-03-11 15:19:58 --> Output Class Initialized
DEBUG - 2016-03-11 15:19:58 --> Security Class Initialized
DEBUG - 2016-03-11 15:19:58 --> Input Class Initialized
DEBUG - 2016-03-11 15:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:19:58 --> Language Class Initialized
DEBUG - 2016-03-11 15:19:58 --> Loader Class Initialized
DEBUG - 2016-03-11 15:19:58 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:19:58 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:19:58 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:19:58 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:19:58 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:19:59 --> Session Class Initialized
DEBUG - 2016-03-11 15:19:59 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:19:59 --> A session cookie was not found.
DEBUG - 2016-03-11 15:19:59 --> Session routines successfully run
DEBUG - 2016-03-11 15:19:59 --> Controller Class Initialized
DEBUG - 2016-03-11 15:19:59 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:19:59 --> Model Class Initialized
DEBUG - 2016-03-11 15:19:59 --> Model Class Initialized
DEBUG - 2016-03-11 15:19:59 --> File loaded: application/views/campanhas_listar.php
DEBUG - 2016-03-11 15:19:59 --> Final output sent to browser
DEBUG - 2016-03-11 15:19:59 --> Total execution time: 1.1471
DEBUG - 2016-03-11 15:20:00 --> Config Class Initialized
DEBUG - 2016-03-11 15:20:00 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:20:00 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:20:00 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:20:00 --> URI Class Initialized
DEBUG - 2016-03-11 15:20:00 --> Router Class Initialized
DEBUG - 2016-03-11 15:20:00 --> Output Class Initialized
DEBUG - 2016-03-11 15:20:00 --> Security Class Initialized
DEBUG - 2016-03-11 15:20:00 --> Input Class Initialized
DEBUG - 2016-03-11 15:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:20:00 --> Language Class Initialized
DEBUG - 2016-03-11 15:20:00 --> Loader Class Initialized
DEBUG - 2016-03-11 15:20:00 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:20:00 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:20:00 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:20:00 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:20:00 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:20:01 --> Session Class Initialized
DEBUG - 2016-03-11 15:20:01 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:20:01 --> Session routines successfully run
DEBUG - 2016-03-11 15:20:01 --> Controller Class Initialized
DEBUG - 2016-03-11 15:20:01 --> Final output sent to browser
DEBUG - 2016-03-11 15:20:01 --> Total execution time: 1.2241
DEBUG - 2016-03-11 15:20:04 --> Config Class Initialized
DEBUG - 2016-03-11 15:20:04 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:20:04 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:20:04 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:20:04 --> URI Class Initialized
DEBUG - 2016-03-11 15:20:04 --> Router Class Initialized
DEBUG - 2016-03-11 15:20:04 --> Output Class Initialized
DEBUG - 2016-03-11 15:20:04 --> Security Class Initialized
DEBUG - 2016-03-11 15:20:04 --> Input Class Initialized
DEBUG - 2016-03-11 15:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:20:04 --> Language Class Initialized
DEBUG - 2016-03-11 15:20:04 --> Loader Class Initialized
DEBUG - 2016-03-11 15:20:04 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:20:04 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:20:04 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:20:04 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:20:04 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:20:05 --> Session Class Initialized
DEBUG - 2016-03-11 15:20:05 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:20:05 --> Session routines successfully run
DEBUG - 2016-03-11 15:20:05 --> Controller Class Initialized
DEBUG - 2016-03-11 15:20:05 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:20:05 --> Model Class Initialized
DEBUG - 2016-03-11 15:20:05 --> Model Class Initialized
DEBUG - 2016-03-11 15:20:05 --> Final output sent to browser
DEBUG - 2016-03-11 15:20:05 --> Total execution time: 1.1431
DEBUG - 2016-03-11 15:20:10 --> Config Class Initialized
DEBUG - 2016-03-11 15:20:10 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:20:10 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:20:10 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:20:10 --> URI Class Initialized
DEBUG - 2016-03-11 15:20:10 --> Router Class Initialized
DEBUG - 2016-03-11 15:20:10 --> Output Class Initialized
DEBUG - 2016-03-11 15:20:10 --> Security Class Initialized
DEBUG - 2016-03-11 15:20:10 --> Input Class Initialized
DEBUG - 2016-03-11 15:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:20:10 --> Language Class Initialized
DEBUG - 2016-03-11 15:20:10 --> Loader Class Initialized
DEBUG - 2016-03-11 15:20:10 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:20:10 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:20:10 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:20:10 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:20:10 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:20:11 --> Session Class Initialized
DEBUG - 2016-03-11 15:20:11 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:20:11 --> Session routines successfully run
DEBUG - 2016-03-11 15:20:11 --> Controller Class Initialized
DEBUG - 2016-03-11 15:20:11 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:20:11 --> Model Class Initialized
DEBUG - 2016-03-11 15:20:11 --> Model Class Initialized
DEBUG - 2016-03-11 15:20:11 --> Final output sent to browser
DEBUG - 2016-03-11 15:20:11 --> Total execution time: 1.1826
DEBUG - 2016-03-11 15:20:14 --> Config Class Initialized
DEBUG - 2016-03-11 15:20:14 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:20:14 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:20:14 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:20:14 --> URI Class Initialized
DEBUG - 2016-03-11 15:20:14 --> Router Class Initialized
DEBUG - 2016-03-11 15:20:14 --> Output Class Initialized
DEBUG - 2016-03-11 15:20:14 --> Security Class Initialized
DEBUG - 2016-03-11 15:20:14 --> Input Class Initialized
DEBUG - 2016-03-11 15:20:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:20:14 --> Language Class Initialized
DEBUG - 2016-03-11 15:20:14 --> Loader Class Initialized
DEBUG - 2016-03-11 15:20:14 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:20:14 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:20:14 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:20:14 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:20:14 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:20:15 --> Session Class Initialized
DEBUG - 2016-03-11 15:20:15 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:20:15 --> Session routines successfully run
DEBUG - 2016-03-11 15:20:15 --> Controller Class Initialized
DEBUG - 2016-03-11 15:20:15 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:20:15 --> Model Class Initialized
DEBUG - 2016-03-11 15:20:15 --> Model Class Initialized
DEBUG - 2016-03-11 15:20:15 --> Final output sent to browser
DEBUG - 2016-03-11 15:20:15 --> Total execution time: 1.2266
DEBUG - 2016-03-11 15:20:29 --> Config Class Initialized
DEBUG - 2016-03-11 15:20:29 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:20:29 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:20:29 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:20:29 --> URI Class Initialized
DEBUG - 2016-03-11 15:20:29 --> Router Class Initialized
DEBUG - 2016-03-11 15:20:29 --> Output Class Initialized
DEBUG - 2016-03-11 15:20:29 --> Security Class Initialized
DEBUG - 2016-03-11 15:20:29 --> Input Class Initialized
DEBUG - 2016-03-11 15:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:20:29 --> Language Class Initialized
DEBUG - 2016-03-11 15:20:29 --> Loader Class Initialized
DEBUG - 2016-03-11 15:20:29 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:20:29 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:20:29 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:20:29 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:20:29 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:20:30 --> Session Class Initialized
DEBUG - 2016-03-11 15:20:30 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:20:30 --> A session cookie was not found.
DEBUG - 2016-03-11 15:20:30 --> Session routines successfully run
DEBUG - 2016-03-11 15:20:30 --> Controller Class Initialized
DEBUG - 2016-03-11 15:20:30 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:20:30 --> Model Class Initialized
DEBUG - 2016-03-11 15:20:30 --> Model Class Initialized
DEBUG - 2016-03-11 15:20:30 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 15:20:30 --> Final output sent to browser
DEBUG - 2016-03-11 15:20:30 --> Total execution time: 1.1501
DEBUG - 2016-03-11 15:20:30 --> Config Class Initialized
DEBUG - 2016-03-11 15:20:30 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:20:30 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:20:30 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:20:30 --> URI Class Initialized
DEBUG - 2016-03-11 15:20:30 --> Router Class Initialized
DEBUG - 2016-03-11 15:20:30 --> Output Class Initialized
DEBUG - 2016-03-11 15:20:30 --> Security Class Initialized
DEBUG - 2016-03-11 15:20:30 --> Input Class Initialized
DEBUG - 2016-03-11 15:20:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:20:30 --> Language Class Initialized
DEBUG - 2016-03-11 15:20:30 --> Loader Class Initialized
DEBUG - 2016-03-11 15:20:30 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:20:30 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:20:30 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:20:30 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:20:30 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:20:32 --> Session Class Initialized
DEBUG - 2016-03-11 15:20:32 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:20:32 --> Session routines successfully run
DEBUG - 2016-03-11 15:20:32 --> Controller Class Initialized
DEBUG - 2016-03-11 15:20:32 --> Final output sent to browser
DEBUG - 2016-03-11 15:20:32 --> Total execution time: 1.1561
DEBUG - 2016-03-11 15:20:58 --> Config Class Initialized
DEBUG - 2016-03-11 15:20:58 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:20:58 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:20:58 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:20:58 --> URI Class Initialized
DEBUG - 2016-03-11 15:20:58 --> Router Class Initialized
DEBUG - 2016-03-11 15:20:58 --> Output Class Initialized
DEBUG - 2016-03-11 15:20:58 --> Security Class Initialized
DEBUG - 2016-03-11 15:20:58 --> Input Class Initialized
DEBUG - 2016-03-11 15:20:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:20:58 --> Language Class Initialized
DEBUG - 2016-03-11 15:20:58 --> Loader Class Initialized
DEBUG - 2016-03-11 15:20:58 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:20:58 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:20:58 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:20:58 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:20:58 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:20:59 --> Session Class Initialized
DEBUG - 2016-03-11 15:20:59 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:20:59 --> A session cookie was not found.
DEBUG - 2016-03-11 15:20:59 --> Session routines successfully run
DEBUG - 2016-03-11 15:20:59 --> Controller Class Initialized
DEBUG - 2016-03-11 15:20:59 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:20:59 --> Model Class Initialized
DEBUG - 2016-03-11 15:20:59 --> Model Class Initialized
DEBUG - 2016-03-11 15:20:59 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 15:20:59 --> Final output sent to browser
DEBUG - 2016-03-11 15:20:59 --> Total execution time: 1.1531
DEBUG - 2016-03-11 15:21:00 --> Config Class Initialized
DEBUG - 2016-03-11 15:21:00 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:21:00 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:21:00 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:21:00 --> URI Class Initialized
DEBUG - 2016-03-11 15:21:00 --> Router Class Initialized
DEBUG - 2016-03-11 15:21:00 --> Output Class Initialized
DEBUG - 2016-03-11 15:21:00 --> Security Class Initialized
DEBUG - 2016-03-11 15:21:00 --> Input Class Initialized
DEBUG - 2016-03-11 15:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:21:00 --> Language Class Initialized
DEBUG - 2016-03-11 15:21:00 --> Loader Class Initialized
DEBUG - 2016-03-11 15:21:00 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:21:00 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:21:00 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:21:00 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:21:00 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:21:01 --> Session Class Initialized
DEBUG - 2016-03-11 15:21:01 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:21:01 --> Session routines successfully run
DEBUG - 2016-03-11 15:21:01 --> Controller Class Initialized
DEBUG - 2016-03-11 15:21:01 --> Final output sent to browser
DEBUG - 2016-03-11 15:21:01 --> Total execution time: 1.1821
DEBUG - 2016-03-11 15:21:12 --> Config Class Initialized
DEBUG - 2016-03-11 15:21:12 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:21:12 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:21:12 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:21:12 --> URI Class Initialized
DEBUG - 2016-03-11 15:21:12 --> Router Class Initialized
DEBUG - 2016-03-11 15:21:12 --> Output Class Initialized
DEBUG - 2016-03-11 15:21:12 --> Security Class Initialized
DEBUG - 2016-03-11 15:21:12 --> Input Class Initialized
DEBUG - 2016-03-11 15:21:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:21:12 --> Language Class Initialized
DEBUG - 2016-03-11 15:21:12 --> Loader Class Initialized
DEBUG - 2016-03-11 15:21:12 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:21:12 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:21:12 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:21:12 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:21:12 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:21:13 --> Session Class Initialized
DEBUG - 2016-03-11 15:21:13 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:21:13 --> Session routines successfully run
DEBUG - 2016-03-11 15:21:13 --> Controller Class Initialized
DEBUG - 2016-03-11 15:21:13 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:21:13 --> Model Class Initialized
DEBUG - 2016-03-11 15:21:13 --> Model Class Initialized
DEBUG - 2016-03-11 15:21:13 --> XSS Filtering completed
DEBUG - 2016-03-11 15:21:13 --> XSS Filtering completed
DEBUG - 2016-03-11 15:21:13 --> XSS Filtering completed
DEBUG - 2016-03-11 15:21:13 --> XSS Filtering completed
DEBUG - 2016-03-11 15:21:13 --> XSS Filtering completed
DEBUG - 2016-03-11 15:21:13 --> XSS Filtering completed
DEBUG - 2016-03-11 15:21:13 --> XSS Filtering completed
DEBUG - 2016-03-11 15:21:13 --> XSS Filtering completed
DEBUG - 2016-03-11 15:21:13 --> Helper loaded: form_helper
DEBUG - 2016-03-11 15:21:13 --> Form Validation Class Initialized
DEBUG - 2016-03-11 15:21:13 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-11 15:21:13 --> Final output sent to browser
DEBUG - 2016-03-11 15:21:13 --> Total execution time: 1.3104
DEBUG - 2016-03-11 15:21:16 --> Config Class Initialized
DEBUG - 2016-03-11 15:21:16 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:21:16 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:21:16 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:21:16 --> URI Class Initialized
DEBUG - 2016-03-11 15:21:16 --> Router Class Initialized
DEBUG - 2016-03-11 15:21:16 --> Output Class Initialized
DEBUG - 2016-03-11 15:21:16 --> Security Class Initialized
DEBUG - 2016-03-11 15:21:16 --> Input Class Initialized
DEBUG - 2016-03-11 15:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:21:16 --> Language Class Initialized
DEBUG - 2016-03-11 15:21:16 --> Loader Class Initialized
DEBUG - 2016-03-11 15:21:16 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:21:16 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:21:16 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:21:16 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:21:16 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:21:17 --> Session Class Initialized
DEBUG - 2016-03-11 15:21:17 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:21:17 --> A session cookie was not found.
DEBUG - 2016-03-11 15:21:17 --> Session routines successfully run
DEBUG - 2016-03-11 15:21:17 --> Controller Class Initialized
DEBUG - 2016-03-11 15:21:17 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:21:17 --> Model Class Initialized
DEBUG - 2016-03-11 15:21:17 --> Model Class Initialized
DEBUG - 2016-03-11 15:21:17 --> File loaded: application/views/campanhas_listar.php
DEBUG - 2016-03-11 15:21:17 --> Final output sent to browser
DEBUG - 2016-03-11 15:21:17 --> Total execution time: 1.1431
DEBUG - 2016-03-11 15:21:18 --> Config Class Initialized
DEBUG - 2016-03-11 15:21:18 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:21:18 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:21:18 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:21:18 --> URI Class Initialized
DEBUG - 2016-03-11 15:21:18 --> Router Class Initialized
DEBUG - 2016-03-11 15:21:18 --> Output Class Initialized
DEBUG - 2016-03-11 15:21:18 --> Security Class Initialized
DEBUG - 2016-03-11 15:21:18 --> Input Class Initialized
DEBUG - 2016-03-11 15:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:21:18 --> Language Class Initialized
DEBUG - 2016-03-11 15:21:18 --> Loader Class Initialized
DEBUG - 2016-03-11 15:21:18 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:21:18 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:21:18 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:21:18 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:21:18 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:21:19 --> Session Class Initialized
DEBUG - 2016-03-11 15:21:19 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:21:19 --> Session routines successfully run
DEBUG - 2016-03-11 15:21:19 --> Controller Class Initialized
DEBUG - 2016-03-11 15:21:19 --> Final output sent to browser
DEBUG - 2016-03-11 15:21:19 --> Total execution time: 1.1371
DEBUG - 2016-03-11 15:37:18 --> Config Class Initialized
DEBUG - 2016-03-11 15:37:18 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:37:18 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:37:18 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:37:18 --> URI Class Initialized
DEBUG - 2016-03-11 15:37:18 --> Router Class Initialized
DEBUG - 2016-03-11 15:37:18 --> Output Class Initialized
DEBUG - 2016-03-11 15:37:18 --> Security Class Initialized
DEBUG - 2016-03-11 15:37:18 --> Input Class Initialized
DEBUG - 2016-03-11 15:37:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:37:18 --> Language Class Initialized
DEBUG - 2016-03-11 15:37:18 --> Loader Class Initialized
DEBUG - 2016-03-11 15:37:18 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:37:18 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:37:18 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:37:18 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:37:18 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:37:19 --> Session Class Initialized
DEBUG - 2016-03-11 15:37:19 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:37:19 --> A session cookie was not found.
DEBUG - 2016-03-11 15:37:19 --> Session routines successfully run
DEBUG - 2016-03-11 15:37:19 --> Controller Class Initialized
DEBUG - 2016-03-11 15:37:19 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:37:19 --> Model Class Initialized
DEBUG - 2016-03-11 15:37:19 --> Model Class Initialized
DEBUG - 2016-03-11 15:37:19 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 15:37:19 --> Final output sent to browser
DEBUG - 2016-03-11 15:37:19 --> Total execution time: 1.2070
DEBUG - 2016-03-11 15:37:20 --> Config Class Initialized
DEBUG - 2016-03-11 15:37:20 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:37:20 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:37:20 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:37:20 --> URI Class Initialized
DEBUG - 2016-03-11 15:37:20 --> Router Class Initialized
DEBUG - 2016-03-11 15:37:20 --> Output Class Initialized
DEBUG - 2016-03-11 15:37:20 --> Security Class Initialized
DEBUG - 2016-03-11 15:37:20 --> Input Class Initialized
DEBUG - 2016-03-11 15:37:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:37:20 --> Language Class Initialized
DEBUG - 2016-03-11 15:37:20 --> Loader Class Initialized
DEBUG - 2016-03-11 15:37:20 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:37:20 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:37:20 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:37:20 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:37:20 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:37:21 --> Session Class Initialized
DEBUG - 2016-03-11 15:37:21 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:37:21 --> Session routines successfully run
DEBUG - 2016-03-11 15:37:21 --> Controller Class Initialized
DEBUG - 2016-03-11 15:37:21 --> Final output sent to browser
DEBUG - 2016-03-11 15:37:21 --> Total execution time: 1.1400
DEBUG - 2016-03-11 15:37:23 --> Config Class Initialized
DEBUG - 2016-03-11 15:37:23 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:37:23 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:37:23 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:37:23 --> URI Class Initialized
DEBUG - 2016-03-11 15:37:23 --> Router Class Initialized
DEBUG - 2016-03-11 15:37:23 --> Output Class Initialized
DEBUG - 2016-03-11 15:37:23 --> Security Class Initialized
DEBUG - 2016-03-11 15:37:23 --> Input Class Initialized
DEBUG - 2016-03-11 15:37:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:37:23 --> Language Class Initialized
DEBUG - 2016-03-11 15:37:23 --> Loader Class Initialized
DEBUG - 2016-03-11 15:37:23 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:37:23 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:37:23 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:37:23 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:37:23 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:37:24 --> Session Class Initialized
DEBUG - 2016-03-11 15:37:24 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:37:24 --> A session cookie was not found.
DEBUG - 2016-03-11 15:37:24 --> Session routines successfully run
DEBUG - 2016-03-11 15:37:24 --> Controller Class Initialized
DEBUG - 2016-03-11 15:37:24 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:37:24 --> Model Class Initialized
DEBUG - 2016-03-11 15:37:24 --> Model Class Initialized
DEBUG - 2016-03-11 15:37:24 --> File loaded: application/views/campanhas_listar.php
DEBUG - 2016-03-11 15:37:24 --> Final output sent to browser
DEBUG - 2016-03-11 15:37:24 --> Total execution time: 1.1150
DEBUG - 2016-03-11 15:37:24 --> Config Class Initialized
DEBUG - 2016-03-11 15:37:24 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:37:24 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:37:24 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:37:24 --> URI Class Initialized
DEBUG - 2016-03-11 15:37:24 --> Router Class Initialized
DEBUG - 2016-03-11 15:37:24 --> Output Class Initialized
DEBUG - 2016-03-11 15:37:24 --> Security Class Initialized
DEBUG - 2016-03-11 15:37:24 --> Input Class Initialized
DEBUG - 2016-03-11 15:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:37:24 --> Language Class Initialized
DEBUG - 2016-03-11 15:37:24 --> Loader Class Initialized
DEBUG - 2016-03-11 15:37:24 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:37:24 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:37:24 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:37:24 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:37:24 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:37:25 --> Session Class Initialized
DEBUG - 2016-03-11 15:37:25 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:37:25 --> Session routines successfully run
DEBUG - 2016-03-11 15:37:25 --> Controller Class Initialized
DEBUG - 2016-03-11 15:37:25 --> Final output sent to browser
DEBUG - 2016-03-11 15:37:25 --> Total execution time: 1.1270
DEBUG - 2016-03-11 15:37:35 --> Config Class Initialized
DEBUG - 2016-03-11 15:37:35 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:37:35 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:37:35 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:37:35 --> URI Class Initialized
DEBUG - 2016-03-11 15:37:35 --> Router Class Initialized
DEBUG - 2016-03-11 15:37:35 --> Output Class Initialized
DEBUG - 2016-03-11 15:37:35 --> Security Class Initialized
DEBUG - 2016-03-11 15:37:35 --> Input Class Initialized
DEBUG - 2016-03-11 15:37:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:37:35 --> Language Class Initialized
DEBUG - 2016-03-11 15:37:35 --> Loader Class Initialized
DEBUG - 2016-03-11 15:37:35 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:37:35 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:37:35 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:37:35 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:37:35 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:37:36 --> Session Class Initialized
DEBUG - 2016-03-11 15:37:36 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:37:36 --> A session cookie was not found.
DEBUG - 2016-03-11 15:37:36 --> Session routines successfully run
DEBUG - 2016-03-11 15:37:36 --> Controller Class Initialized
DEBUG - 2016-03-11 15:37:36 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:37:36 --> Model Class Initialized
DEBUG - 2016-03-11 15:37:36 --> Model Class Initialized
DEBUG - 2016-03-11 15:37:36 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 15:37:36 --> Final output sent to browser
DEBUG - 2016-03-11 15:37:36 --> Total execution time: 1.1090
DEBUG - 2016-03-11 15:37:37 --> Config Class Initialized
DEBUG - 2016-03-11 15:37:37 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:37:37 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:37:37 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:37:37 --> URI Class Initialized
DEBUG - 2016-03-11 15:37:37 --> Router Class Initialized
DEBUG - 2016-03-11 15:37:37 --> Output Class Initialized
DEBUG - 2016-03-11 15:37:37 --> Security Class Initialized
DEBUG - 2016-03-11 15:37:37 --> Input Class Initialized
DEBUG - 2016-03-11 15:37:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:37:37 --> Language Class Initialized
DEBUG - 2016-03-11 15:37:37 --> Loader Class Initialized
DEBUG - 2016-03-11 15:37:37 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:37:37 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:37:37 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:37:37 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:37:37 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:37:38 --> Session Class Initialized
DEBUG - 2016-03-11 15:37:38 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:37:38 --> Session routines successfully run
DEBUG - 2016-03-11 15:37:38 --> Controller Class Initialized
DEBUG - 2016-03-11 15:37:38 --> Final output sent to browser
DEBUG - 2016-03-11 15:37:38 --> Total execution time: 1.1870
DEBUG - 2016-03-11 15:38:16 --> Config Class Initialized
DEBUG - 2016-03-11 15:38:16 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:38:16 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:38:16 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:38:16 --> URI Class Initialized
DEBUG - 2016-03-11 15:38:16 --> Router Class Initialized
DEBUG - 2016-03-11 15:38:16 --> Output Class Initialized
DEBUG - 2016-03-11 15:38:16 --> Security Class Initialized
DEBUG - 2016-03-11 15:38:16 --> Input Class Initialized
DEBUG - 2016-03-11 15:38:16 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:38:16 --> Language Class Initialized
DEBUG - 2016-03-11 15:38:16 --> Loader Class Initialized
DEBUG - 2016-03-11 15:38:16 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:38:16 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:38:16 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:38:16 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:38:16 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:38:17 --> Session Class Initialized
DEBUG - 2016-03-11 15:38:17 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:38:17 --> Session routines successfully run
DEBUG - 2016-03-11 15:38:17 --> Controller Class Initialized
DEBUG - 2016-03-11 15:38:17 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:38:17 --> Model Class Initialized
DEBUG - 2016-03-11 15:38:17 --> Model Class Initialized
DEBUG - 2016-03-11 15:38:17 --> XSS Filtering completed
DEBUG - 2016-03-11 15:38:17 --> XSS Filtering completed
DEBUG - 2016-03-11 15:38:17 --> XSS Filtering completed
DEBUG - 2016-03-11 15:38:17 --> XSS Filtering completed
DEBUG - 2016-03-11 15:38:17 --> XSS Filtering completed
DEBUG - 2016-03-11 15:38:17 --> XSS Filtering completed
DEBUG - 2016-03-11 15:38:17 --> XSS Filtering completed
DEBUG - 2016-03-11 15:38:17 --> XSS Filtering completed
DEBUG - 2016-03-11 15:38:17 --> Helper loaded: form_helper
DEBUG - 2016-03-11 15:38:17 --> Form Validation Class Initialized
ERROR - 2016-03-11 15:38:17 --> Severity: Notice  --> Undefined variable: config D:\xampp\htdocs\superacao\_cmp\application\controllers\campanha.php 154
DEBUG - 2016-03-11 15:38:17 --> Upload Class Initialized
DEBUG - 2016-03-11 15:38:17 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-11 15:38:17 --> Final output sent to browser
DEBUG - 2016-03-11 15:38:17 --> Total execution time: 1.2188
DEBUG - 2016-03-11 15:38:25 --> Config Class Initialized
DEBUG - 2016-03-11 15:38:25 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:38:25 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:38:25 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:38:25 --> URI Class Initialized
DEBUG - 2016-03-11 15:38:25 --> Router Class Initialized
DEBUG - 2016-03-11 15:38:25 --> Output Class Initialized
DEBUG - 2016-03-11 15:38:25 --> Security Class Initialized
DEBUG - 2016-03-11 15:38:25 --> Input Class Initialized
DEBUG - 2016-03-11 15:38:25 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:38:25 --> Language Class Initialized
DEBUG - 2016-03-11 15:38:25 --> Loader Class Initialized
DEBUG - 2016-03-11 15:38:25 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:38:25 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:38:25 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:38:25 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:38:25 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:38:26 --> Session Class Initialized
DEBUG - 2016-03-11 15:38:26 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:38:26 --> Session routines successfully run
DEBUG - 2016-03-11 15:38:26 --> Controller Class Initialized
DEBUG - 2016-03-11 15:38:26 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:38:26 --> Model Class Initialized
DEBUG - 2016-03-11 15:38:26 --> Model Class Initialized
DEBUG - 2016-03-11 15:38:26 --> XSS Filtering completed
DEBUG - 2016-03-11 15:38:26 --> XSS Filtering completed
DEBUG - 2016-03-11 15:38:26 --> XSS Filtering completed
DEBUG - 2016-03-11 15:38:26 --> XSS Filtering completed
DEBUG - 2016-03-11 15:38:26 --> XSS Filtering completed
DEBUG - 2016-03-11 15:38:26 --> XSS Filtering completed
DEBUG - 2016-03-11 15:38:26 --> XSS Filtering completed
DEBUG - 2016-03-11 15:38:26 --> XSS Filtering completed
DEBUG - 2016-03-11 15:38:26 --> Helper loaded: form_helper
DEBUG - 2016-03-11 15:38:26 --> Form Validation Class Initialized
ERROR - 2016-03-11 15:38:26 --> Severity: Notice  --> Undefined variable: config D:\xampp\htdocs\superacao\_cmp\application\controllers\campanha.php 154
DEBUG - 2016-03-11 15:38:26 --> Upload Class Initialized
DEBUG - 2016-03-11 15:38:26 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-11 15:38:26 --> Final output sent to browser
DEBUG - 2016-03-11 15:38:26 --> Total execution time: 1.1958
DEBUG - 2016-03-11 15:39:00 --> Config Class Initialized
DEBUG - 2016-03-11 15:39:00 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:39:00 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:39:00 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:39:00 --> URI Class Initialized
DEBUG - 2016-03-11 15:39:00 --> Router Class Initialized
DEBUG - 2016-03-11 15:39:00 --> Output Class Initialized
DEBUG - 2016-03-11 15:39:00 --> Security Class Initialized
DEBUG - 2016-03-11 15:39:00 --> Input Class Initialized
DEBUG - 2016-03-11 15:39:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:39:00 --> Language Class Initialized
DEBUG - 2016-03-11 15:39:00 --> Loader Class Initialized
DEBUG - 2016-03-11 15:39:00 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:39:00 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:39:00 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:39:00 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:39:00 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:39:01 --> Session Class Initialized
DEBUG - 2016-03-11 15:39:01 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:39:01 --> Session routines successfully run
DEBUG - 2016-03-11 15:39:01 --> Controller Class Initialized
DEBUG - 2016-03-11 15:39:01 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:39:01 --> Model Class Initialized
DEBUG - 2016-03-11 15:39:01 --> Model Class Initialized
DEBUG - 2016-03-11 15:39:01 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:01 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:01 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:01 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:01 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:01 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:01 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:01 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:01 --> Helper loaded: form_helper
DEBUG - 2016-03-11 15:39:01 --> Form Validation Class Initialized
ERROR - 2016-03-11 15:39:01 --> Severity: Notice  --> Undefined variable: upload_config D:\xampp\htdocs\superacao\_cmp\application\controllers\campanha.php 154
DEBUG - 2016-03-11 15:39:01 --> Upload Class Initialized
DEBUG - 2016-03-11 15:39:01 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-11 15:39:01 --> Final output sent to browser
DEBUG - 2016-03-11 15:39:01 --> Total execution time: 1.2068
DEBUG - 2016-03-11 15:39:15 --> Config Class Initialized
DEBUG - 2016-03-11 15:39:15 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:39:15 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:39:15 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:39:15 --> URI Class Initialized
DEBUG - 2016-03-11 15:39:15 --> Router Class Initialized
DEBUG - 2016-03-11 15:39:15 --> Output Class Initialized
DEBUG - 2016-03-11 15:39:15 --> Security Class Initialized
DEBUG - 2016-03-11 15:39:15 --> Input Class Initialized
DEBUG - 2016-03-11 15:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:39:15 --> Language Class Initialized
DEBUG - 2016-03-11 15:39:15 --> Loader Class Initialized
DEBUG - 2016-03-11 15:39:15 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:39:15 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:39:15 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:39:15 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:39:15 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:39:16 --> Session Class Initialized
DEBUG - 2016-03-11 15:39:16 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:39:16 --> Session routines successfully run
DEBUG - 2016-03-11 15:39:16 --> Controller Class Initialized
DEBUG - 2016-03-11 15:39:16 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:39:16 --> Model Class Initialized
DEBUG - 2016-03-11 15:39:16 --> Model Class Initialized
DEBUG - 2016-03-11 15:39:16 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:16 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:16 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:16 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:16 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:16 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:16 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:16 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:16 --> Helper loaded: form_helper
DEBUG - 2016-03-11 15:39:16 --> Form Validation Class Initialized
DEBUG - 2016-03-11 15:39:16 --> Upload Class Initialized
DEBUG - 2016-03-11 15:39:16 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-11 15:39:16 --> Final output sent to browser
DEBUG - 2016-03-11 15:39:16 --> Total execution time: 1.1942
DEBUG - 2016-03-11 15:39:30 --> Config Class Initialized
DEBUG - 2016-03-11 15:39:30 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:39:30 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:39:30 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:39:30 --> URI Class Initialized
DEBUG - 2016-03-11 15:39:30 --> Router Class Initialized
DEBUG - 2016-03-11 15:39:30 --> Output Class Initialized
DEBUG - 2016-03-11 15:39:30 --> Security Class Initialized
DEBUG - 2016-03-11 15:39:30 --> Input Class Initialized
DEBUG - 2016-03-11 15:39:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:39:30 --> Language Class Initialized
DEBUG - 2016-03-11 15:39:30 --> Loader Class Initialized
DEBUG - 2016-03-11 15:39:30 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:39:30 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:39:30 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:39:30 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:39:30 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:39:31 --> Session Class Initialized
DEBUG - 2016-03-11 15:39:31 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:39:31 --> Session routines successfully run
DEBUG - 2016-03-11 15:39:31 --> Controller Class Initialized
DEBUG - 2016-03-11 15:39:31 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:39:31 --> Model Class Initialized
DEBUG - 2016-03-11 15:39:31 --> Model Class Initialized
DEBUG - 2016-03-11 15:39:31 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:31 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:31 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:31 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:31 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:31 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:31 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:31 --> XSS Filtering completed
DEBUG - 2016-03-11 15:39:31 --> Helper loaded: form_helper
DEBUG - 2016-03-11 15:39:31 --> Form Validation Class Initialized
DEBUG - 2016-03-11 15:39:31 --> Upload Class Initialized
DEBUG - 2016-03-11 15:39:31 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-11 15:39:31 --> Final output sent to browser
DEBUG - 2016-03-11 15:39:31 --> Total execution time: 1.2294
DEBUG - 2016-03-11 15:42:21 --> Config Class Initialized
DEBUG - 2016-03-11 15:42:21 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:42:21 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:42:21 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:42:21 --> URI Class Initialized
DEBUG - 2016-03-11 15:42:21 --> Router Class Initialized
DEBUG - 2016-03-11 15:42:21 --> Output Class Initialized
DEBUG - 2016-03-11 15:42:21 --> Security Class Initialized
DEBUG - 2016-03-11 15:42:21 --> Input Class Initialized
DEBUG - 2016-03-11 15:42:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:42:21 --> Language Class Initialized
DEBUG - 2016-03-11 15:42:21 --> Loader Class Initialized
DEBUG - 2016-03-11 15:42:21 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:42:21 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:42:21 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:42:21 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:42:22 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:42:23 --> Session Class Initialized
DEBUG - 2016-03-11 15:42:23 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:42:23 --> Session routines successfully run
DEBUG - 2016-03-11 15:42:23 --> Controller Class Initialized
DEBUG - 2016-03-11 15:42:23 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:42:23 --> Model Class Initialized
DEBUG - 2016-03-11 15:42:23 --> Model Class Initialized
DEBUG - 2016-03-11 15:42:23 --> XSS Filtering completed
DEBUG - 2016-03-11 15:42:23 --> XSS Filtering completed
DEBUG - 2016-03-11 15:42:23 --> XSS Filtering completed
DEBUG - 2016-03-11 15:42:23 --> XSS Filtering completed
DEBUG - 2016-03-11 15:42:23 --> XSS Filtering completed
DEBUG - 2016-03-11 15:42:23 --> XSS Filtering completed
DEBUG - 2016-03-11 15:42:23 --> XSS Filtering completed
DEBUG - 2016-03-11 15:42:23 --> XSS Filtering completed
DEBUG - 2016-03-11 15:42:23 --> Helper loaded: form_helper
DEBUG - 2016-03-11 15:42:23 --> Form Validation Class Initialized
DEBUG - 2016-03-11 15:42:23 --> Upload Class Initialized
DEBUG - 2016-03-11 15:42:23 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-11 15:42:23 --> Final output sent to browser
DEBUG - 2016-03-11 15:42:23 --> Total execution time: 1.2137
DEBUG - 2016-03-11 15:43:53 --> Config Class Initialized
DEBUG - 2016-03-11 15:43:53 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:43:53 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:43:53 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:43:53 --> URI Class Initialized
DEBUG - 2016-03-11 15:43:53 --> Router Class Initialized
DEBUG - 2016-03-11 15:43:53 --> Output Class Initialized
DEBUG - 2016-03-11 15:43:53 --> Security Class Initialized
DEBUG - 2016-03-11 15:43:53 --> Input Class Initialized
DEBUG - 2016-03-11 15:43:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:43:53 --> Language Class Initialized
DEBUG - 2016-03-11 15:43:53 --> Loader Class Initialized
DEBUG - 2016-03-11 15:43:53 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:43:53 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:43:53 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:43:53 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:43:53 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:43:54 --> Session Class Initialized
DEBUG - 2016-03-11 15:43:54 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:43:54 --> A session cookie was not found.
DEBUG - 2016-03-11 15:43:54 --> Session routines successfully run
DEBUG - 2016-03-11 15:43:54 --> Controller Class Initialized
DEBUG - 2016-03-11 15:43:54 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:43:54 --> Model Class Initialized
DEBUG - 2016-03-11 15:43:54 --> Model Class Initialized
DEBUG - 2016-03-11 15:43:54 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 15:43:54 --> Final output sent to browser
DEBUG - 2016-03-11 15:43:54 --> Total execution time: 1.1931
DEBUG - 2016-03-11 15:43:55 --> Config Class Initialized
DEBUG - 2016-03-11 15:43:55 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:43:55 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:43:55 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:43:55 --> URI Class Initialized
DEBUG - 2016-03-11 15:43:55 --> Router Class Initialized
DEBUG - 2016-03-11 15:43:55 --> Output Class Initialized
DEBUG - 2016-03-11 15:43:55 --> Security Class Initialized
DEBUG - 2016-03-11 15:43:55 --> Input Class Initialized
DEBUG - 2016-03-11 15:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:43:55 --> Language Class Initialized
DEBUG - 2016-03-11 15:43:55 --> Loader Class Initialized
DEBUG - 2016-03-11 15:43:55 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:43:55 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:43:55 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:43:55 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:43:55 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:43:56 --> Session Class Initialized
DEBUG - 2016-03-11 15:43:56 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:43:56 --> Session routines successfully run
DEBUG - 2016-03-11 15:43:56 --> Controller Class Initialized
DEBUG - 2016-03-11 15:43:56 --> Final output sent to browser
DEBUG - 2016-03-11 15:43:56 --> Total execution time: 1.2521
DEBUG - 2016-03-11 15:47:18 --> Config Class Initialized
DEBUG - 2016-03-11 15:47:18 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:47:18 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:47:18 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:47:18 --> URI Class Initialized
DEBUG - 2016-03-11 15:47:18 --> Router Class Initialized
DEBUG - 2016-03-11 15:47:18 --> Output Class Initialized
DEBUG - 2016-03-11 15:47:18 --> Security Class Initialized
DEBUG - 2016-03-11 15:47:18 --> Input Class Initialized
DEBUG - 2016-03-11 15:47:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:47:18 --> Language Class Initialized
DEBUG - 2016-03-11 15:47:18 --> Loader Class Initialized
DEBUG - 2016-03-11 15:47:18 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:47:18 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:47:18 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:47:18 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:47:18 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:47:19 --> Session Class Initialized
DEBUG - 2016-03-11 15:47:19 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:47:19 --> A session cookie was not found.
DEBUG - 2016-03-11 15:47:19 --> Session routines successfully run
DEBUG - 2016-03-11 15:47:19 --> Controller Class Initialized
DEBUG - 2016-03-11 15:47:19 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:47:19 --> Model Class Initialized
DEBUG - 2016-03-11 15:47:19 --> Model Class Initialized
DEBUG - 2016-03-11 15:47:19 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 15:47:19 --> Final output sent to browser
DEBUG - 2016-03-11 15:47:19 --> Total execution time: 1.1481
DEBUG - 2016-03-11 15:47:20 --> Config Class Initialized
DEBUG - 2016-03-11 15:47:20 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:47:20 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:47:20 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:47:20 --> URI Class Initialized
DEBUG - 2016-03-11 15:47:20 --> Router Class Initialized
DEBUG - 2016-03-11 15:47:20 --> Output Class Initialized
DEBUG - 2016-03-11 15:47:20 --> Security Class Initialized
DEBUG - 2016-03-11 15:47:20 --> Input Class Initialized
DEBUG - 2016-03-11 15:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:47:20 --> Language Class Initialized
DEBUG - 2016-03-11 15:47:20 --> Loader Class Initialized
DEBUG - 2016-03-11 15:47:20 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:47:20 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:47:20 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:47:20 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:47:20 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:47:21 --> Session Class Initialized
DEBUG - 2016-03-11 15:47:21 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:47:21 --> Session routines successfully run
DEBUG - 2016-03-11 15:47:21 --> Controller Class Initialized
DEBUG - 2016-03-11 15:47:21 --> Final output sent to browser
DEBUG - 2016-03-11 15:47:21 --> Total execution time: 1.2161
DEBUG - 2016-03-11 15:49:22 --> Config Class Initialized
DEBUG - 2016-03-11 15:49:22 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:49:22 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:49:22 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:49:22 --> URI Class Initialized
DEBUG - 2016-03-11 15:49:22 --> Router Class Initialized
DEBUG - 2016-03-11 15:49:22 --> Output Class Initialized
DEBUG - 2016-03-11 15:49:22 --> Security Class Initialized
DEBUG - 2016-03-11 15:49:22 --> Input Class Initialized
DEBUG - 2016-03-11 15:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:49:22 --> Language Class Initialized
DEBUG - 2016-03-11 15:49:22 --> Loader Class Initialized
DEBUG - 2016-03-11 15:49:22 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:49:22 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:49:22 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:49:22 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:49:22 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:49:23 --> Session Class Initialized
DEBUG - 2016-03-11 15:49:23 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:49:23 --> A session cookie was not found.
DEBUG - 2016-03-11 15:49:23 --> Session routines successfully run
DEBUG - 2016-03-11 15:49:23 --> Controller Class Initialized
DEBUG - 2016-03-11 15:49:23 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:49:23 --> Model Class Initialized
DEBUG - 2016-03-11 15:49:23 --> Model Class Initialized
DEBUG - 2016-03-11 15:49:23 --> File loaded: application/views/campanhas_listar.php
DEBUG - 2016-03-11 15:49:23 --> Final output sent to browser
DEBUG - 2016-03-11 15:49:23 --> Total execution time: 1.1491
DEBUG - 2016-03-11 15:49:24 --> Config Class Initialized
DEBUG - 2016-03-11 15:49:24 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:49:24 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:49:24 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:49:24 --> URI Class Initialized
DEBUG - 2016-03-11 15:49:24 --> Router Class Initialized
DEBUG - 2016-03-11 15:49:24 --> Output Class Initialized
DEBUG - 2016-03-11 15:49:24 --> Security Class Initialized
DEBUG - 2016-03-11 15:49:24 --> Input Class Initialized
DEBUG - 2016-03-11 15:49:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:49:24 --> Language Class Initialized
DEBUG - 2016-03-11 15:49:24 --> Loader Class Initialized
DEBUG - 2016-03-11 15:49:24 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:49:24 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:49:24 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:49:24 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:49:24 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:49:25 --> Session Class Initialized
DEBUG - 2016-03-11 15:49:25 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:49:25 --> Session routines successfully run
DEBUG - 2016-03-11 15:49:25 --> Controller Class Initialized
DEBUG - 2016-03-11 15:49:25 --> Final output sent to browser
DEBUG - 2016-03-11 15:49:25 --> Total execution time: 1.1711
DEBUG - 2016-03-11 15:49:29 --> Config Class Initialized
DEBUG - 2016-03-11 15:49:29 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:49:29 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:49:29 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:49:29 --> URI Class Initialized
DEBUG - 2016-03-11 15:49:29 --> Router Class Initialized
DEBUG - 2016-03-11 15:49:29 --> Output Class Initialized
DEBUG - 2016-03-11 15:49:29 --> Security Class Initialized
DEBUG - 2016-03-11 15:49:29 --> Input Class Initialized
DEBUG - 2016-03-11 15:49:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:49:29 --> Language Class Initialized
DEBUG - 2016-03-11 15:49:29 --> Loader Class Initialized
DEBUG - 2016-03-11 15:49:29 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:49:29 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:49:29 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:49:29 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:49:29 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:49:30 --> Session Class Initialized
DEBUG - 2016-03-11 15:49:30 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:49:30 --> A session cookie was not found.
DEBUG - 2016-03-11 15:49:30 --> Session routines successfully run
DEBUG - 2016-03-11 15:49:30 --> Controller Class Initialized
DEBUG - 2016-03-11 15:49:30 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:49:30 --> Model Class Initialized
DEBUG - 2016-03-11 15:49:30 --> Model Class Initialized
DEBUG - 2016-03-11 15:49:30 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 15:49:30 --> Final output sent to browser
DEBUG - 2016-03-11 15:49:30 --> Total execution time: 1.1381
DEBUG - 2016-03-11 15:49:31 --> Config Class Initialized
DEBUG - 2016-03-11 15:49:31 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:49:31 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:49:31 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:49:31 --> URI Class Initialized
DEBUG - 2016-03-11 15:49:31 --> Router Class Initialized
DEBUG - 2016-03-11 15:49:31 --> Output Class Initialized
DEBUG - 2016-03-11 15:49:31 --> Security Class Initialized
DEBUG - 2016-03-11 15:49:31 --> Input Class Initialized
DEBUG - 2016-03-11 15:49:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:49:31 --> Language Class Initialized
DEBUG - 2016-03-11 15:49:31 --> Loader Class Initialized
DEBUG - 2016-03-11 15:49:31 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:49:31 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:49:31 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:49:31 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:49:31 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:49:32 --> Session Class Initialized
DEBUG - 2016-03-11 15:49:32 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:49:32 --> Session routines successfully run
DEBUG - 2016-03-11 15:49:32 --> Controller Class Initialized
DEBUG - 2016-03-11 15:49:32 --> Final output sent to browser
DEBUG - 2016-03-11 15:49:32 --> Total execution time: 1.1371
DEBUG - 2016-03-11 15:51:57 --> Config Class Initialized
DEBUG - 2016-03-11 15:51:57 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:51:57 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:51:57 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:51:57 --> URI Class Initialized
DEBUG - 2016-03-11 15:51:57 --> Router Class Initialized
DEBUG - 2016-03-11 15:51:57 --> Output Class Initialized
DEBUG - 2016-03-11 15:51:57 --> Security Class Initialized
DEBUG - 2016-03-11 15:51:57 --> Input Class Initialized
DEBUG - 2016-03-11 15:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:51:57 --> Language Class Initialized
DEBUG - 2016-03-11 15:51:57 --> Loader Class Initialized
DEBUG - 2016-03-11 15:51:57 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:51:57 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:51:57 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:51:57 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:51:57 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:51:58 --> Session Class Initialized
DEBUG - 2016-03-11 15:51:58 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:51:58 --> A session cookie was not found.
DEBUG - 2016-03-11 15:51:58 --> Session routines successfully run
DEBUG - 2016-03-11 15:51:58 --> Controller Class Initialized
DEBUG - 2016-03-11 15:51:58 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:51:58 --> Model Class Initialized
DEBUG - 2016-03-11 15:51:58 --> Model Class Initialized
DEBUG - 2016-03-11 15:51:58 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 15:51:58 --> Final output sent to browser
DEBUG - 2016-03-11 15:51:58 --> Total execution time: 1.1471
DEBUG - 2016-03-11 15:51:59 --> Config Class Initialized
DEBUG - 2016-03-11 15:51:59 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:51:59 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:51:59 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:51:59 --> URI Class Initialized
DEBUG - 2016-03-11 15:51:59 --> Router Class Initialized
DEBUG - 2016-03-11 15:51:59 --> Output Class Initialized
DEBUG - 2016-03-11 15:51:59 --> Security Class Initialized
DEBUG - 2016-03-11 15:51:59 --> Input Class Initialized
DEBUG - 2016-03-11 15:51:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:51:59 --> Language Class Initialized
DEBUG - 2016-03-11 15:51:59 --> Loader Class Initialized
DEBUG - 2016-03-11 15:51:59 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:51:59 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:51:59 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:51:59 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:51:59 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:52:00 --> Session Class Initialized
DEBUG - 2016-03-11 15:52:00 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:52:00 --> Session routines successfully run
DEBUG - 2016-03-11 15:52:00 --> Controller Class Initialized
DEBUG - 2016-03-11 15:52:00 --> Final output sent to browser
DEBUG - 2016-03-11 15:52:00 --> Total execution time: 1.1781
DEBUG - 2016-03-11 15:52:07 --> Config Class Initialized
DEBUG - 2016-03-11 15:52:07 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:52:07 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:52:07 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:52:07 --> URI Class Initialized
DEBUG - 2016-03-11 15:52:07 --> Router Class Initialized
DEBUG - 2016-03-11 15:52:07 --> Output Class Initialized
DEBUG - 2016-03-11 15:52:07 --> Security Class Initialized
DEBUG - 2016-03-11 15:52:07 --> Input Class Initialized
DEBUG - 2016-03-11 15:52:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:52:07 --> Language Class Initialized
DEBUG - 2016-03-11 15:52:07 --> Loader Class Initialized
DEBUG - 2016-03-11 15:52:07 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:52:07 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:52:07 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:52:07 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:52:07 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:52:08 --> Session Class Initialized
DEBUG - 2016-03-11 15:52:08 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:52:08 --> Session routines successfully run
DEBUG - 2016-03-11 15:52:08 --> Controller Class Initialized
DEBUG - 2016-03-11 15:52:08 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:52:08 --> Model Class Initialized
DEBUG - 2016-03-11 15:52:08 --> Model Class Initialized
DEBUG - 2016-03-11 15:52:08 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:08 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:08 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:08 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:08 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:08 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:08 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:08 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:08 --> Helper loaded: form_helper
DEBUG - 2016-03-11 15:52:08 --> Form Validation Class Initialized
DEBUG - 2016-03-11 15:52:08 --> Language file loaded: language/pt-br/form_validation_lang.php
ERROR - 2016-03-11 15:52:08 --> Severity: Notice  --> Undefined property: Campanha::$upload D:\xampp\htdocs\superacao\_cmp\application\controllers\campanha.php 280
DEBUG - 2016-03-11 15:52:13 --> Config Class Initialized
DEBUG - 2016-03-11 15:52:13 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:52:13 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:52:13 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:52:13 --> URI Class Initialized
DEBUG - 2016-03-11 15:52:13 --> Router Class Initialized
DEBUG - 2016-03-11 15:52:13 --> Output Class Initialized
DEBUG - 2016-03-11 15:52:13 --> Security Class Initialized
DEBUG - 2016-03-11 15:52:13 --> Input Class Initialized
DEBUG - 2016-03-11 15:52:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:52:13 --> Language Class Initialized
DEBUG - 2016-03-11 15:52:13 --> Loader Class Initialized
DEBUG - 2016-03-11 15:52:13 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:52:13 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:52:13 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:52:13 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:52:13 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:52:15 --> Session Class Initialized
DEBUG - 2016-03-11 15:52:15 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:52:15 --> Session routines successfully run
DEBUG - 2016-03-11 15:52:15 --> Controller Class Initialized
DEBUG - 2016-03-11 15:52:15 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:52:15 --> Model Class Initialized
DEBUG - 2016-03-11 15:52:15 --> Model Class Initialized
DEBUG - 2016-03-11 15:52:15 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:15 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:15 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:15 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:15 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:15 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:15 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:15 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:15 --> Helper loaded: form_helper
DEBUG - 2016-03-11 15:52:15 --> Form Validation Class Initialized
DEBUG - 2016-03-11 15:52:15 --> Language file loaded: language/pt-br/form_validation_lang.php
ERROR - 2016-03-11 15:52:15 --> Severity: Notice  --> Undefined property: Campanha::$upload D:\xampp\htdocs\superacao\_cmp\application\controllers\campanha.php 280
DEBUG - 2016-03-11 15:52:45 --> Config Class Initialized
DEBUG - 2016-03-11 15:52:45 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:52:45 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:52:45 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:52:45 --> URI Class Initialized
DEBUG - 2016-03-11 15:52:45 --> Router Class Initialized
DEBUG - 2016-03-11 15:52:45 --> Output Class Initialized
DEBUG - 2016-03-11 15:52:45 --> Security Class Initialized
DEBUG - 2016-03-11 15:52:45 --> Input Class Initialized
DEBUG - 2016-03-11 15:52:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:52:45 --> Language Class Initialized
DEBUG - 2016-03-11 15:52:45 --> Loader Class Initialized
DEBUG - 2016-03-11 15:52:45 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:52:45 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:52:45 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:52:45 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:52:45 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:52:46 --> Session Class Initialized
DEBUG - 2016-03-11 15:52:46 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:52:46 --> Session routines successfully run
DEBUG - 2016-03-11 15:52:46 --> Controller Class Initialized
DEBUG - 2016-03-11 15:52:46 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:52:46 --> Model Class Initialized
DEBUG - 2016-03-11 15:52:46 --> Model Class Initialized
DEBUG - 2016-03-11 15:52:46 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:46 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:46 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:46 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:46 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:46 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:46 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:46 --> XSS Filtering completed
DEBUG - 2016-03-11 15:52:46 --> Helper loaded: form_helper
DEBUG - 2016-03-11 15:52:46 --> Form Validation Class Initialized
DEBUG - 2016-03-11 15:52:46 --> Upload Class Initialized
DEBUG - 2016-03-11 15:52:46 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-11 15:52:46 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 15:52:46 --> Nenhum arquivo foi selecionado para envio.
DEBUG - 2016-03-11 15:52:46 --> Final output sent to browser
DEBUG - 2016-03-11 15:52:46 --> Total execution time: 1.1988
DEBUG - 2016-03-11 15:53:35 --> Config Class Initialized
DEBUG - 2016-03-11 15:53:35 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:53:35 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:53:35 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:53:35 --> URI Class Initialized
DEBUG - 2016-03-11 15:53:35 --> Router Class Initialized
DEBUG - 2016-03-11 15:53:35 --> Output Class Initialized
DEBUG - 2016-03-11 15:53:35 --> Security Class Initialized
DEBUG - 2016-03-11 15:53:35 --> Input Class Initialized
DEBUG - 2016-03-11 15:53:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:53:35 --> Language Class Initialized
DEBUG - 2016-03-11 15:53:35 --> Loader Class Initialized
DEBUG - 2016-03-11 15:53:35 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:53:35 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:53:35 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:53:35 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:53:35 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:53:36 --> Session Class Initialized
DEBUG - 2016-03-11 15:53:36 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:53:36 --> Session routines successfully run
DEBUG - 2016-03-11 15:53:36 --> Controller Class Initialized
DEBUG - 2016-03-11 15:53:36 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:53:36 --> Model Class Initialized
DEBUG - 2016-03-11 15:53:36 --> Model Class Initialized
DEBUG - 2016-03-11 15:53:36 --> XSS Filtering completed
DEBUG - 2016-03-11 15:53:36 --> XSS Filtering completed
DEBUG - 2016-03-11 15:53:36 --> XSS Filtering completed
DEBUG - 2016-03-11 15:53:36 --> XSS Filtering completed
DEBUG - 2016-03-11 15:53:36 --> XSS Filtering completed
DEBUG - 2016-03-11 15:53:36 --> XSS Filtering completed
DEBUG - 2016-03-11 15:53:36 --> XSS Filtering completed
DEBUG - 2016-03-11 15:53:36 --> XSS Filtering completed
DEBUG - 2016-03-11 15:53:36 --> Helper loaded: form_helper
DEBUG - 2016-03-11 15:53:36 --> Form Validation Class Initialized
DEBUG - 2016-03-11 15:53:36 --> Upload Class Initialized
DEBUG - 2016-03-11 15:53:36 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-11 15:53:36 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 15:53:36 --> Nenhum arquivo foi selecionado para envio.
DEBUG - 2016-03-11 15:53:36 --> Final output sent to browser
DEBUG - 2016-03-11 15:53:36 --> Total execution time: 1.2278
DEBUG - 2016-03-11 15:53:53 --> Config Class Initialized
DEBUG - 2016-03-11 15:53:53 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:53:53 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:53:53 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:53:53 --> URI Class Initialized
DEBUG - 2016-03-11 15:53:53 --> Router Class Initialized
DEBUG - 2016-03-11 15:53:53 --> Output Class Initialized
DEBUG - 2016-03-11 15:53:53 --> Security Class Initialized
DEBUG - 2016-03-11 15:53:53 --> Input Class Initialized
DEBUG - 2016-03-11 15:53:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:53:53 --> Language Class Initialized
DEBUG - 2016-03-11 15:53:53 --> Loader Class Initialized
DEBUG - 2016-03-11 15:53:54 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:53:54 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:53:54 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:53:54 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:53:54 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:53:55 --> Session Class Initialized
DEBUG - 2016-03-11 15:53:55 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:53:55 --> Session routines successfully run
DEBUG - 2016-03-11 15:53:55 --> Controller Class Initialized
DEBUG - 2016-03-11 15:53:55 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:53:55 --> Model Class Initialized
DEBUG - 2016-03-11 15:53:55 --> Model Class Initialized
DEBUG - 2016-03-11 15:53:55 --> XSS Filtering completed
DEBUG - 2016-03-11 15:53:55 --> XSS Filtering completed
DEBUG - 2016-03-11 15:53:55 --> XSS Filtering completed
DEBUG - 2016-03-11 15:53:55 --> XSS Filtering completed
DEBUG - 2016-03-11 15:53:55 --> XSS Filtering completed
DEBUG - 2016-03-11 15:53:55 --> XSS Filtering completed
DEBUG - 2016-03-11 15:53:55 --> XSS Filtering completed
DEBUG - 2016-03-11 15:53:55 --> XSS Filtering completed
DEBUG - 2016-03-11 15:54:50 --> Config Class Initialized
DEBUG - 2016-03-11 15:54:50 --> Hooks Class Initialized
DEBUG - 2016-03-11 15:54:50 --> Utf8 Class Initialized
DEBUG - 2016-03-11 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 15:54:50 --> URI Class Initialized
DEBUG - 2016-03-11 15:54:50 --> Router Class Initialized
DEBUG - 2016-03-11 15:54:50 --> Output Class Initialized
DEBUG - 2016-03-11 15:54:50 --> Security Class Initialized
DEBUG - 2016-03-11 15:54:50 --> Input Class Initialized
DEBUG - 2016-03-11 15:54:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 15:54:50 --> Language Class Initialized
DEBUG - 2016-03-11 15:54:50 --> Loader Class Initialized
DEBUG - 2016-03-11 15:54:50 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 15:54:50 --> Helper loaded: url_helper
DEBUG - 2016-03-11 15:54:50 --> Helper loaded: image_helper
DEBUG - 2016-03-11 15:54:50 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 15:54:50 --> Database Driver Class Initialized
DEBUG - 2016-03-11 15:54:51 --> Session Class Initialized
DEBUG - 2016-03-11 15:54:51 --> Helper loaded: string_helper
DEBUG - 2016-03-11 15:54:51 --> Session routines successfully run
DEBUG - 2016-03-11 15:54:51 --> Controller Class Initialized
DEBUG - 2016-03-11 15:54:51 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 15:54:51 --> Model Class Initialized
DEBUG - 2016-03-11 15:54:51 --> Model Class Initialized
DEBUG - 2016-03-11 15:54:51 --> Helper loaded: form_helper
DEBUG - 2016-03-11 15:54:51 --> Form Validation Class Initialized
DEBUG - 2016-03-11 15:54:51 --> Upload Class Initialized
DEBUG - 2016-03-11 15:54:51 --> XSS Filtering completed
DEBUG - 2016-03-11 15:54:51 --> XSS Filtering completed
DEBUG - 2016-03-11 15:54:51 --> XSS Filtering completed
DEBUG - 2016-03-11 15:54:51 --> XSS Filtering completed
DEBUG - 2016-03-11 15:54:51 --> XSS Filtering completed
DEBUG - 2016-03-11 15:54:51 --> XSS Filtering completed
DEBUG - 2016-03-11 15:54:51 --> XSS Filtering completed
DEBUG - 2016-03-11 15:54:51 --> XSS Filtering completed
DEBUG - 2016-03-11 16:02:06 --> Config Class Initialized
DEBUG - 2016-03-11 16:02:06 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:02:06 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:02:06 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:02:06 --> URI Class Initialized
DEBUG - 2016-03-11 16:02:06 --> Router Class Initialized
DEBUG - 2016-03-11 16:02:06 --> Output Class Initialized
DEBUG - 2016-03-11 16:02:06 --> Security Class Initialized
DEBUG - 2016-03-11 16:02:06 --> Input Class Initialized
DEBUG - 2016-03-11 16:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:02:06 --> Language Class Initialized
DEBUG - 2016-03-11 16:02:06 --> Loader Class Initialized
DEBUG - 2016-03-11 16:02:06 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:02:06 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:02:06 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:02:06 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:02:06 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:02:07 --> Session Class Initialized
DEBUG - 2016-03-11 16:02:07 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:02:07 --> Session routines successfully run
DEBUG - 2016-03-11 16:02:07 --> Controller Class Initialized
DEBUG - 2016-03-11 16:02:07 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 16:02:07 --> Model Class Initialized
DEBUG - 2016-03-11 16:02:07 --> Model Class Initialized
DEBUG - 2016-03-11 16:02:07 --> Helper loaded: form_helper
DEBUG - 2016-03-11 16:02:07 --> Form Validation Class Initialized
DEBUG - 2016-03-11 16:02:07 --> Upload Class Initialized
DEBUG - 2016-03-11 16:02:07 --> XSS Filtering completed
DEBUG - 2016-03-11 16:02:07 --> XSS Filtering completed
DEBUG - 2016-03-11 16:02:07 --> XSS Filtering completed
DEBUG - 2016-03-11 16:02:07 --> XSS Filtering completed
DEBUG - 2016-03-11 16:02:07 --> XSS Filtering completed
DEBUG - 2016-03-11 16:02:07 --> XSS Filtering completed
DEBUG - 2016-03-11 16:02:07 --> XSS Filtering completed
DEBUG - 2016-03-11 16:02:07 --> XSS Filtering completed
DEBUG - 2016-03-11 16:02:07 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-11 16:02:07 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 16:02:07 --> Nenhum arquivo foi selecionado para envio.
DEBUG - 2016-03-11 16:02:07 --> Final output sent to browser
DEBUG - 2016-03-11 16:02:07 --> Total execution time: 1.1632
DEBUG - 2016-03-11 16:04:43 --> Config Class Initialized
DEBUG - 2016-03-11 16:04:43 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:04:43 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:04:43 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:04:43 --> URI Class Initialized
DEBUG - 2016-03-11 16:04:43 --> Router Class Initialized
DEBUG - 2016-03-11 16:04:43 --> Output Class Initialized
DEBUG - 2016-03-11 16:04:43 --> Security Class Initialized
DEBUG - 2016-03-11 16:04:43 --> Input Class Initialized
DEBUG - 2016-03-11 16:04:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:04:43 --> Language Class Initialized
DEBUG - 2016-03-11 16:04:43 --> Loader Class Initialized
DEBUG - 2016-03-11 16:04:43 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:04:43 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:04:43 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:04:43 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:04:43 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:04:44 --> Session Class Initialized
DEBUG - 2016-03-11 16:04:44 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:04:44 --> A session cookie was not found.
DEBUG - 2016-03-11 16:04:44 --> Session routines successfully run
DEBUG - 2016-03-11 16:04:44 --> Controller Class Initialized
DEBUG - 2016-03-11 16:04:44 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 16:04:44 --> Model Class Initialized
DEBUG - 2016-03-11 16:04:44 --> Model Class Initialized
DEBUG - 2016-03-11 16:04:44 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 16:04:44 --> Final output sent to browser
DEBUG - 2016-03-11 16:04:44 --> Total execution time: 1.2070
DEBUG - 2016-03-11 16:04:45 --> Config Class Initialized
DEBUG - 2016-03-11 16:04:45 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:04:45 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:04:45 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:04:45 --> URI Class Initialized
DEBUG - 2016-03-11 16:04:45 --> Router Class Initialized
DEBUG - 2016-03-11 16:04:45 --> Output Class Initialized
DEBUG - 2016-03-11 16:04:45 --> Security Class Initialized
DEBUG - 2016-03-11 16:04:45 --> Input Class Initialized
DEBUG - 2016-03-11 16:04:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:04:45 --> Language Class Initialized
DEBUG - 2016-03-11 16:04:45 --> Loader Class Initialized
DEBUG - 2016-03-11 16:04:45 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:04:45 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:04:45 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:04:45 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:04:45 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:04:46 --> Session Class Initialized
DEBUG - 2016-03-11 16:04:46 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:04:46 --> Session routines successfully run
DEBUG - 2016-03-11 16:04:46 --> Controller Class Initialized
DEBUG - 2016-03-11 16:04:46 --> Final output sent to browser
DEBUG - 2016-03-11 16:04:46 --> Total execution time: 1.2610
DEBUG - 2016-03-11 16:10:40 --> Config Class Initialized
DEBUG - 2016-03-11 16:10:40 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:10:40 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:10:40 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:10:40 --> URI Class Initialized
DEBUG - 2016-03-11 16:10:41 --> Router Class Initialized
DEBUG - 2016-03-11 16:10:41 --> Output Class Initialized
DEBUG - 2016-03-11 16:10:41 --> Security Class Initialized
DEBUG - 2016-03-11 16:10:41 --> Input Class Initialized
DEBUG - 2016-03-11 16:10:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:10:41 --> Language Class Initialized
DEBUG - 2016-03-11 16:10:41 --> Loader Class Initialized
DEBUG - 2016-03-11 16:10:41 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:10:41 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:10:41 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:10:41 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:10:41 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:10:42 --> Session Class Initialized
DEBUG - 2016-03-11 16:10:42 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:10:42 --> A session cookie was not found.
DEBUG - 2016-03-11 16:10:42 --> Session routines successfully run
DEBUG - 2016-03-11 16:10:42 --> Controller Class Initialized
DEBUG - 2016-03-11 16:10:42 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 16:10:42 --> Model Class Initialized
DEBUG - 2016-03-11 16:10:42 --> Model Class Initialized
DEBUG - 2016-03-11 16:10:42 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 16:10:42 --> Final output sent to browser
DEBUG - 2016-03-11 16:10:42 --> Total execution time: 1.1640
DEBUG - 2016-03-11 16:54:01 --> Config Class Initialized
DEBUG - 2016-03-11 16:54:01 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:54:01 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:54:01 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:54:01 --> URI Class Initialized
DEBUG - 2016-03-11 16:54:01 --> Router Class Initialized
DEBUG - 2016-03-11 16:54:01 --> Output Class Initialized
DEBUG - 2016-03-11 16:54:01 --> Security Class Initialized
DEBUG - 2016-03-11 16:54:01 --> Input Class Initialized
DEBUG - 2016-03-11 16:54:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:54:01 --> Language Class Initialized
DEBUG - 2016-03-11 16:54:20 --> Config Class Initialized
DEBUG - 2016-03-11 16:54:20 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:54:20 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:54:20 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:54:20 --> URI Class Initialized
DEBUG - 2016-03-11 16:54:20 --> Router Class Initialized
DEBUG - 2016-03-11 16:54:20 --> Output Class Initialized
DEBUG - 2016-03-11 16:54:20 --> Security Class Initialized
DEBUG - 2016-03-11 16:54:20 --> Input Class Initialized
DEBUG - 2016-03-11 16:54:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:54:20 --> Language Class Initialized
DEBUG - 2016-03-11 16:54:20 --> Loader Class Initialized
DEBUG - 2016-03-11 16:54:20 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:54:20 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:54:20 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:54:20 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:54:20 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:54:21 --> Session Class Initialized
DEBUG - 2016-03-11 16:54:21 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:54:21 --> A session cookie was not found.
DEBUG - 2016-03-11 16:54:21 --> Session routines successfully run
DEBUG - 2016-03-11 16:54:21 --> Controller Class Initialized
DEBUG - 2016-03-11 16:54:21 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 16:54:21 --> Model Class Initialized
DEBUG - 2016-03-11 16:54:21 --> Model Class Initialized
DEBUG - 2016-03-11 16:54:21 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 16:54:21 --> Final output sent to browser
DEBUG - 2016-03-11 16:54:21 --> Total execution time: 1.1320
DEBUG - 2016-03-11 16:54:22 --> Config Class Initialized
DEBUG - 2016-03-11 16:54:22 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:54:22 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:54:22 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:54:22 --> URI Class Initialized
DEBUG - 2016-03-11 16:54:22 --> Router Class Initialized
DEBUG - 2016-03-11 16:54:22 --> Output Class Initialized
DEBUG - 2016-03-11 16:54:22 --> Security Class Initialized
DEBUG - 2016-03-11 16:54:22 --> Input Class Initialized
DEBUG - 2016-03-11 16:54:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:54:22 --> Language Class Initialized
DEBUG - 2016-03-11 16:54:22 --> Loader Class Initialized
DEBUG - 2016-03-11 16:54:22 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:54:22 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:54:22 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:54:22 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:54:22 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:54:23 --> Session Class Initialized
DEBUG - 2016-03-11 16:54:23 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:54:23 --> Session routines successfully run
DEBUG - 2016-03-11 16:54:23 --> Controller Class Initialized
DEBUG - 2016-03-11 16:54:23 --> Final output sent to browser
DEBUG - 2016-03-11 16:54:23 --> Total execution time: 1.2000
DEBUG - 2016-03-11 16:54:30 --> Config Class Initialized
DEBUG - 2016-03-11 16:54:30 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:54:30 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:54:30 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:54:30 --> URI Class Initialized
DEBUG - 2016-03-11 16:54:30 --> Router Class Initialized
DEBUG - 2016-03-11 16:54:30 --> Output Class Initialized
DEBUG - 2016-03-11 16:54:30 --> Security Class Initialized
DEBUG - 2016-03-11 16:54:30 --> Input Class Initialized
DEBUG - 2016-03-11 16:54:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:54:30 --> Language Class Initialized
DEBUG - 2016-03-11 16:54:30 --> Loader Class Initialized
DEBUG - 2016-03-11 16:54:30 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:54:30 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:54:30 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:54:30 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:54:30 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:54:31 --> Session Class Initialized
DEBUG - 2016-03-11 16:54:31 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:54:31 --> Session routines successfully run
DEBUG - 2016-03-11 16:54:31 --> Controller Class Initialized
DEBUG - 2016-03-11 16:54:31 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 16:54:31 --> Model Class Initialized
DEBUG - 2016-03-11 16:54:31 --> Model Class Initialized
DEBUG - 2016-03-11 16:54:31 --> Helper loaded: form_helper
DEBUG - 2016-03-11 16:54:31 --> Form Validation Class Initialized
DEBUG - 2016-03-11 16:54:31 --> XSS Filtering completed
DEBUG - 2016-03-11 16:54:31 --> XSS Filtering completed
DEBUG - 2016-03-11 16:54:31 --> XSS Filtering completed
DEBUG - 2016-03-11 16:54:31 --> XSS Filtering completed
DEBUG - 2016-03-11 16:54:31 --> XSS Filtering completed
DEBUG - 2016-03-11 16:54:31 --> XSS Filtering completed
DEBUG - 2016-03-11 16:54:31 --> XSS Filtering completed
DEBUG - 2016-03-11 16:54:31 --> XSS Filtering completed
DEBUG - 2016-03-11 16:54:31 --> XSS Filtering completed
DEBUG - 2016-03-11 16:54:31 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-11 16:54:31 --> Final output sent to browser
DEBUG - 2016-03-11 16:54:31 --> Total execution time: 1.1790
DEBUG - 2016-03-11 16:54:53 --> Config Class Initialized
DEBUG - 2016-03-11 16:54:53 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:54:53 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:54:53 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:54:53 --> URI Class Initialized
DEBUG - 2016-03-11 16:54:53 --> Router Class Initialized
DEBUG - 2016-03-11 16:54:53 --> Output Class Initialized
DEBUG - 2016-03-11 16:54:53 --> Security Class Initialized
DEBUG - 2016-03-11 16:54:53 --> Input Class Initialized
DEBUG - 2016-03-11 16:54:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:54:53 --> Language Class Initialized
DEBUG - 2016-03-11 16:54:53 --> Loader Class Initialized
DEBUG - 2016-03-11 16:54:53 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:54:53 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:54:53 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:54:53 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:54:53 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:54:54 --> Session Class Initialized
DEBUG - 2016-03-11 16:54:54 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:54:54 --> A session cookie was not found.
DEBUG - 2016-03-11 16:54:54 --> Session routines successfully run
DEBUG - 2016-03-11 16:54:54 --> Controller Class Initialized
DEBUG - 2016-03-11 16:54:54 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 16:54:54 --> Model Class Initialized
DEBUG - 2016-03-11 16:54:54 --> Model Class Initialized
DEBUG - 2016-03-11 16:54:54 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 16:54:54 --> Final output sent to browser
DEBUG - 2016-03-11 16:54:54 --> Total execution time: 1.1591
DEBUG - 2016-03-11 16:54:59 --> Config Class Initialized
DEBUG - 2016-03-11 16:54:59 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:54:59 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:54:59 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:54:59 --> URI Class Initialized
DEBUG - 2016-03-11 16:54:59 --> Router Class Initialized
DEBUG - 2016-03-11 16:54:59 --> Output Class Initialized
DEBUG - 2016-03-11 16:54:59 --> Security Class Initialized
DEBUG - 2016-03-11 16:54:59 --> Input Class Initialized
DEBUG - 2016-03-11 16:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:54:59 --> Language Class Initialized
DEBUG - 2016-03-11 16:54:59 --> Loader Class Initialized
DEBUG - 2016-03-11 16:54:59 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:54:59 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:54:59 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:54:59 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:54:59 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:55:00 --> Session Class Initialized
DEBUG - 2016-03-11 16:55:00 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:55:00 --> A session cookie was not found.
DEBUG - 2016-03-11 16:55:00 --> Session routines successfully run
DEBUG - 2016-03-11 16:55:00 --> Controller Class Initialized
DEBUG - 2016-03-11 16:55:00 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 16:55:00 --> Model Class Initialized
DEBUG - 2016-03-11 16:55:00 --> Model Class Initialized
DEBUG - 2016-03-11 16:55:00 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 16:55:00 --> Final output sent to browser
DEBUG - 2016-03-11 16:55:00 --> Total execution time: 1.1091
DEBUG - 2016-03-11 16:55:01 --> Config Class Initialized
DEBUG - 2016-03-11 16:55:01 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:55:01 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:55:01 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:55:01 --> URI Class Initialized
DEBUG - 2016-03-11 16:55:01 --> Router Class Initialized
DEBUG - 2016-03-11 16:55:01 --> Output Class Initialized
DEBUG - 2016-03-11 16:55:01 --> Security Class Initialized
DEBUG - 2016-03-11 16:55:01 --> Input Class Initialized
DEBUG - 2016-03-11 16:55:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:55:01 --> Language Class Initialized
DEBUG - 2016-03-11 16:55:01 --> Loader Class Initialized
DEBUG - 2016-03-11 16:55:01 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:55:01 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:55:01 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:55:01 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:55:01 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:55:02 --> Session Class Initialized
DEBUG - 2016-03-11 16:55:02 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:55:02 --> Session routines successfully run
DEBUG - 2016-03-11 16:55:02 --> Controller Class Initialized
DEBUG - 2016-03-11 16:55:02 --> Final output sent to browser
DEBUG - 2016-03-11 16:55:02 --> Total execution time: 1.1771
DEBUG - 2016-03-11 16:55:08 --> Config Class Initialized
DEBUG - 2016-03-11 16:55:08 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:55:08 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:55:08 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:55:08 --> URI Class Initialized
DEBUG - 2016-03-11 16:55:08 --> Router Class Initialized
DEBUG - 2016-03-11 16:55:08 --> Output Class Initialized
DEBUG - 2016-03-11 16:55:08 --> Security Class Initialized
DEBUG - 2016-03-11 16:55:08 --> Input Class Initialized
DEBUG - 2016-03-11 16:55:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:55:08 --> Language Class Initialized
DEBUG - 2016-03-11 16:55:08 --> Loader Class Initialized
DEBUG - 2016-03-11 16:55:08 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:55:08 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:55:08 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:55:08 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:55:08 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:55:09 --> Session Class Initialized
DEBUG - 2016-03-11 16:55:09 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:55:09 --> Session routines successfully run
DEBUG - 2016-03-11 16:55:09 --> Controller Class Initialized
DEBUG - 2016-03-11 16:55:09 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 16:55:09 --> Model Class Initialized
DEBUG - 2016-03-11 16:55:09 --> Model Class Initialized
DEBUG - 2016-03-11 16:55:09 --> Helper loaded: form_helper
DEBUG - 2016-03-11 16:55:09 --> Form Validation Class Initialized
DEBUG - 2016-03-11 16:55:09 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:09 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:09 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:09 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:09 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:09 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:09 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:09 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:09 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:09 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-11 16:55:09 --> Final output sent to browser
DEBUG - 2016-03-11 16:55:09 --> Total execution time: 1.1961
DEBUG - 2016-03-11 16:55:13 --> Config Class Initialized
DEBUG - 2016-03-11 16:55:13 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:55:13 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:55:13 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:55:13 --> URI Class Initialized
DEBUG - 2016-03-11 16:55:13 --> Router Class Initialized
DEBUG - 2016-03-11 16:55:13 --> Output Class Initialized
DEBUG - 2016-03-11 16:55:13 --> Security Class Initialized
DEBUG - 2016-03-11 16:55:13 --> Input Class Initialized
DEBUG - 2016-03-11 16:55:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:55:13 --> Language Class Initialized
DEBUG - 2016-03-11 16:55:14 --> Loader Class Initialized
DEBUG - 2016-03-11 16:55:14 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:55:14 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:55:14 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:55:14 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:55:14 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:55:15 --> Session Class Initialized
DEBUG - 2016-03-11 16:55:15 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:55:15 --> A session cookie was not found.
DEBUG - 2016-03-11 16:55:15 --> Session routines successfully run
DEBUG - 2016-03-11 16:55:15 --> Controller Class Initialized
DEBUG - 2016-03-11 16:55:15 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 16:55:15 --> Model Class Initialized
DEBUG - 2016-03-11 16:55:15 --> Model Class Initialized
DEBUG - 2016-03-11 16:55:15 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 16:55:15 --> Final output sent to browser
DEBUG - 2016-03-11 16:55:15 --> Total execution time: 1.1661
DEBUG - 2016-03-11 16:55:29 --> Config Class Initialized
DEBUG - 2016-03-11 16:55:29 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:55:29 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:55:29 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:55:29 --> URI Class Initialized
DEBUG - 2016-03-11 16:55:29 --> Router Class Initialized
DEBUG - 2016-03-11 16:55:29 --> Output Class Initialized
DEBUG - 2016-03-11 16:55:29 --> Security Class Initialized
DEBUG - 2016-03-11 16:55:29 --> Input Class Initialized
DEBUG - 2016-03-11 16:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:55:29 --> Language Class Initialized
DEBUG - 2016-03-11 16:55:29 --> Loader Class Initialized
DEBUG - 2016-03-11 16:55:29 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:55:29 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:55:29 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:55:29 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:55:29 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:55:30 --> Session Class Initialized
DEBUG - 2016-03-11 16:55:30 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:55:30 --> A session cookie was not found.
DEBUG - 2016-03-11 16:55:30 --> Session routines successfully run
DEBUG - 2016-03-11 16:55:30 --> Controller Class Initialized
DEBUG - 2016-03-11 16:55:30 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 16:55:30 --> Model Class Initialized
DEBUG - 2016-03-11 16:55:30 --> Model Class Initialized
DEBUG - 2016-03-11 16:55:30 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 16:55:30 --> Final output sent to browser
DEBUG - 2016-03-11 16:55:30 --> Total execution time: 1.1361
DEBUG - 2016-03-11 16:55:31 --> Config Class Initialized
DEBUG - 2016-03-11 16:55:31 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:55:31 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:55:31 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:55:31 --> URI Class Initialized
DEBUG - 2016-03-11 16:55:31 --> Router Class Initialized
DEBUG - 2016-03-11 16:55:31 --> Output Class Initialized
DEBUG - 2016-03-11 16:55:31 --> Security Class Initialized
DEBUG - 2016-03-11 16:55:31 --> Input Class Initialized
DEBUG - 2016-03-11 16:55:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:55:31 --> Language Class Initialized
DEBUG - 2016-03-11 16:55:31 --> Loader Class Initialized
DEBUG - 2016-03-11 16:55:31 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:55:31 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:55:31 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:55:31 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:55:31 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:55:32 --> Session Class Initialized
DEBUG - 2016-03-11 16:55:32 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:55:32 --> Session routines successfully run
DEBUG - 2016-03-11 16:55:32 --> Controller Class Initialized
DEBUG - 2016-03-11 16:55:32 --> Final output sent to browser
DEBUG - 2016-03-11 16:55:32 --> Total execution time: 1.1671
DEBUG - 2016-03-11 16:55:37 --> Config Class Initialized
DEBUG - 2016-03-11 16:55:37 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:55:37 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:55:37 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:55:37 --> URI Class Initialized
DEBUG - 2016-03-11 16:55:37 --> Router Class Initialized
DEBUG - 2016-03-11 16:55:37 --> Output Class Initialized
DEBUG - 2016-03-11 16:55:37 --> Security Class Initialized
DEBUG - 2016-03-11 16:55:37 --> Input Class Initialized
DEBUG - 2016-03-11 16:55:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:55:37 --> Language Class Initialized
DEBUG - 2016-03-11 16:55:37 --> Loader Class Initialized
DEBUG - 2016-03-11 16:55:37 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:55:37 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:55:37 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:55:37 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:55:37 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:55:38 --> Session Class Initialized
DEBUG - 2016-03-11 16:55:38 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:55:38 --> Session routines successfully run
DEBUG - 2016-03-11 16:55:38 --> Controller Class Initialized
DEBUG - 2016-03-11 16:55:38 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 16:55:38 --> Model Class Initialized
DEBUG - 2016-03-11 16:55:38 --> Model Class Initialized
DEBUG - 2016-03-11 16:55:38 --> Helper loaded: form_helper
DEBUG - 2016-03-11 16:55:38 --> Form Validation Class Initialized
DEBUG - 2016-03-11 16:55:38 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:38 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:38 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:38 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:38 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:38 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:38 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:38 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:38 --> XSS Filtering completed
DEBUG - 2016-03-11 16:55:38 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-11 16:55:38 --> Final output sent to browser
DEBUG - 2016-03-11 16:55:38 --> Total execution time: 1.2661
DEBUG - 2016-03-11 16:55:53 --> Config Class Initialized
DEBUG - 2016-03-11 16:55:53 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:55:53 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:55:53 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:55:53 --> URI Class Initialized
DEBUG - 2016-03-11 16:55:53 --> Router Class Initialized
DEBUG - 2016-03-11 16:55:53 --> Output Class Initialized
DEBUG - 2016-03-11 16:55:53 --> Security Class Initialized
DEBUG - 2016-03-11 16:55:53 --> Input Class Initialized
DEBUG - 2016-03-11 16:55:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:55:53 --> Language Class Initialized
DEBUG - 2016-03-11 16:55:53 --> Loader Class Initialized
DEBUG - 2016-03-11 16:55:53 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:55:53 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:55:53 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:55:53 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:55:53 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:55:54 --> Session Class Initialized
DEBUG - 2016-03-11 16:55:54 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:55:54 --> A session cookie was not found.
DEBUG - 2016-03-11 16:55:54 --> Session routines successfully run
DEBUG - 2016-03-11 16:55:54 --> Controller Class Initialized
DEBUG - 2016-03-11 16:55:54 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 16:55:54 --> Model Class Initialized
DEBUG - 2016-03-11 16:55:54 --> Model Class Initialized
DEBUG - 2016-03-11 16:55:54 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 16:55:54 --> Final output sent to browser
DEBUG - 2016-03-11 16:55:54 --> Total execution time: 1.1501
DEBUG - 2016-03-11 16:57:42 --> Config Class Initialized
DEBUG - 2016-03-11 16:57:42 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:57:42 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:57:42 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:57:42 --> URI Class Initialized
DEBUG - 2016-03-11 16:57:42 --> Router Class Initialized
DEBUG - 2016-03-11 16:57:42 --> Output Class Initialized
DEBUG - 2016-03-11 16:57:42 --> Security Class Initialized
DEBUG - 2016-03-11 16:57:42 --> Input Class Initialized
DEBUG - 2016-03-11 16:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:57:42 --> Language Class Initialized
DEBUG - 2016-03-11 16:57:42 --> Loader Class Initialized
DEBUG - 2016-03-11 16:57:42 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:57:42 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:57:42 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:57:42 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:57:42 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:57:43 --> Session Class Initialized
DEBUG - 2016-03-11 16:57:43 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:57:43 --> A session cookie was not found.
DEBUG - 2016-03-11 16:57:43 --> Session routines successfully run
DEBUG - 2016-03-11 16:57:43 --> Controller Class Initialized
DEBUG - 2016-03-11 16:57:43 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 16:57:43 --> Model Class Initialized
DEBUG - 2016-03-11 16:57:43 --> Model Class Initialized
DEBUG - 2016-03-11 16:57:43 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 16:57:43 --> Final output sent to browser
DEBUG - 2016-03-11 16:57:43 --> Total execution time: 1.1811
DEBUG - 2016-03-11 16:57:44 --> Config Class Initialized
DEBUG - 2016-03-11 16:57:44 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:57:44 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:57:44 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:57:44 --> URI Class Initialized
DEBUG - 2016-03-11 16:57:44 --> Router Class Initialized
DEBUG - 2016-03-11 16:57:44 --> Output Class Initialized
DEBUG - 2016-03-11 16:57:44 --> Security Class Initialized
DEBUG - 2016-03-11 16:57:44 --> Input Class Initialized
DEBUG - 2016-03-11 16:57:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:57:44 --> Language Class Initialized
DEBUG - 2016-03-11 16:57:44 --> Loader Class Initialized
DEBUG - 2016-03-11 16:57:44 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:57:44 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:57:44 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:57:44 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:57:44 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:57:45 --> Session Class Initialized
DEBUG - 2016-03-11 16:57:45 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:57:45 --> Session routines successfully run
DEBUG - 2016-03-11 16:57:45 --> Controller Class Initialized
DEBUG - 2016-03-11 16:57:45 --> Final output sent to browser
DEBUG - 2016-03-11 16:57:45 --> Total execution time: 1.1581
DEBUG - 2016-03-11 16:57:49 --> Config Class Initialized
DEBUG - 2016-03-11 16:57:49 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:57:49 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:57:49 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:57:49 --> URI Class Initialized
DEBUG - 2016-03-11 16:57:49 --> Router Class Initialized
DEBUG - 2016-03-11 16:57:49 --> Output Class Initialized
DEBUG - 2016-03-11 16:57:49 --> Security Class Initialized
DEBUG - 2016-03-11 16:57:49 --> Input Class Initialized
DEBUG - 2016-03-11 16:57:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:57:50 --> Language Class Initialized
DEBUG - 2016-03-11 16:57:50 --> Loader Class Initialized
DEBUG - 2016-03-11 16:57:50 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:57:50 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:57:50 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:57:50 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:57:50 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:57:51 --> Session Class Initialized
DEBUG - 2016-03-11 16:57:51 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:57:51 --> Session routines successfully run
DEBUG - 2016-03-11 16:57:51 --> Controller Class Initialized
DEBUG - 2016-03-11 16:57:51 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 16:57:51 --> Model Class Initialized
DEBUG - 2016-03-11 16:57:51 --> Model Class Initialized
DEBUG - 2016-03-11 16:57:51 --> Helper loaded: form_helper
DEBUG - 2016-03-11 16:57:51 --> Form Validation Class Initialized
DEBUG - 2016-03-11 16:57:51 --> XSS Filtering completed
DEBUG - 2016-03-11 16:57:51 --> XSS Filtering completed
DEBUG - 2016-03-11 16:57:51 --> XSS Filtering completed
DEBUG - 2016-03-11 16:57:51 --> XSS Filtering completed
DEBUG - 2016-03-11 16:57:51 --> XSS Filtering completed
DEBUG - 2016-03-11 16:57:51 --> XSS Filtering completed
DEBUG - 2016-03-11 16:57:51 --> XSS Filtering completed
DEBUG - 2016-03-11 16:57:51 --> XSS Filtering completed
DEBUG - 2016-03-11 16:57:51 --> XSS Filtering completed
DEBUG - 2016-03-11 16:57:51 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-11 16:57:51 --> Final output sent to browser
DEBUG - 2016-03-11 16:57:51 --> Total execution time: 1.1941
DEBUG - 2016-03-11 16:57:55 --> Config Class Initialized
DEBUG - 2016-03-11 16:57:55 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:57:55 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:57:55 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:57:55 --> URI Class Initialized
DEBUG - 2016-03-11 16:57:55 --> Router Class Initialized
DEBUG - 2016-03-11 16:57:55 --> Output Class Initialized
DEBUG - 2016-03-11 16:57:55 --> Security Class Initialized
DEBUG - 2016-03-11 16:57:55 --> Input Class Initialized
DEBUG - 2016-03-11 16:57:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:57:55 --> Language Class Initialized
DEBUG - 2016-03-11 16:57:55 --> Loader Class Initialized
DEBUG - 2016-03-11 16:57:55 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:57:55 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:57:55 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:57:55 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:57:55 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:57:56 --> Session Class Initialized
DEBUG - 2016-03-11 16:57:56 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:57:56 --> A session cookie was not found.
DEBUG - 2016-03-11 16:57:56 --> Session routines successfully run
DEBUG - 2016-03-11 16:57:56 --> Controller Class Initialized
DEBUG - 2016-03-11 16:57:56 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 16:57:56 --> Model Class Initialized
DEBUG - 2016-03-11 16:57:56 --> Model Class Initialized
DEBUG - 2016-03-11 16:57:56 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 16:57:56 --> Final output sent to browser
DEBUG - 2016-03-11 16:57:56 --> Total execution time: 1.1471
DEBUG - 2016-03-11 16:59:29 --> Config Class Initialized
DEBUG - 2016-03-11 16:59:29 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:59:29 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:59:29 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:59:29 --> URI Class Initialized
DEBUG - 2016-03-11 16:59:29 --> Router Class Initialized
DEBUG - 2016-03-11 16:59:29 --> Output Class Initialized
DEBUG - 2016-03-11 16:59:29 --> Security Class Initialized
DEBUG - 2016-03-11 16:59:29 --> Input Class Initialized
DEBUG - 2016-03-11 16:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:59:29 --> Language Class Initialized
DEBUG - 2016-03-11 16:59:29 --> Loader Class Initialized
DEBUG - 2016-03-11 16:59:29 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:59:29 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:59:29 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:59:29 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:59:29 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:59:30 --> Session Class Initialized
DEBUG - 2016-03-11 16:59:30 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:59:30 --> A session cookie was not found.
DEBUG - 2016-03-11 16:59:30 --> Session routines successfully run
DEBUG - 2016-03-11 16:59:30 --> Controller Class Initialized
DEBUG - 2016-03-11 16:59:30 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 16:59:30 --> Model Class Initialized
DEBUG - 2016-03-11 16:59:30 --> Model Class Initialized
DEBUG - 2016-03-11 16:59:30 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 16:59:30 --> Final output sent to browser
DEBUG - 2016-03-11 16:59:30 --> Total execution time: 1.1371
DEBUG - 2016-03-11 16:59:31 --> Config Class Initialized
DEBUG - 2016-03-11 16:59:31 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:59:31 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:59:31 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:59:31 --> URI Class Initialized
DEBUG - 2016-03-11 16:59:31 --> Router Class Initialized
DEBUG - 2016-03-11 16:59:31 --> Output Class Initialized
DEBUG - 2016-03-11 16:59:31 --> Security Class Initialized
DEBUG - 2016-03-11 16:59:31 --> Input Class Initialized
DEBUG - 2016-03-11 16:59:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 16:59:31 --> Language Class Initialized
DEBUG - 2016-03-11 16:59:31 --> Loader Class Initialized
DEBUG - 2016-03-11 16:59:31 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 16:59:31 --> Helper loaded: url_helper
DEBUG - 2016-03-11 16:59:31 --> Helper loaded: image_helper
DEBUG - 2016-03-11 16:59:31 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 16:59:31 --> Database Driver Class Initialized
DEBUG - 2016-03-11 16:59:32 --> Session Class Initialized
DEBUG - 2016-03-11 16:59:32 --> Helper loaded: string_helper
DEBUG - 2016-03-11 16:59:32 --> Session routines successfully run
DEBUG - 2016-03-11 16:59:32 --> Controller Class Initialized
DEBUG - 2016-03-11 16:59:32 --> Final output sent to browser
DEBUG - 2016-03-11 16:59:32 --> Total execution time: 1.1431
DEBUG - 2016-03-11 16:59:39 --> Config Class Initialized
DEBUG - 2016-03-11 16:59:39 --> Hooks Class Initialized
DEBUG - 2016-03-11 16:59:39 --> Utf8 Class Initialized
DEBUG - 2016-03-11 16:59:39 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 16:59:39 --> URI Class Initialized
DEBUG - 2016-03-11 16:59:39 --> Router Class Initialized
ERROR - 2016-03-11 16:59:39 --> 404 Page Not Found --> image
DEBUG - 2016-03-11 17:00:07 --> Config Class Initialized
DEBUG - 2016-03-11 17:00:07 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:00:07 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:00:07 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:00:07 --> URI Class Initialized
DEBUG - 2016-03-11 17:00:07 --> Router Class Initialized
DEBUG - 2016-03-11 17:00:07 --> Output Class Initialized
DEBUG - 2016-03-11 17:00:07 --> Security Class Initialized
DEBUG - 2016-03-11 17:00:07 --> Input Class Initialized
DEBUG - 2016-03-11 17:00:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:00:07 --> Language Class Initialized
DEBUG - 2016-03-11 17:00:07 --> Loader Class Initialized
DEBUG - 2016-03-11 17:00:07 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:00:07 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:00:07 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:00:07 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:00:07 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:00:08 --> Session Class Initialized
DEBUG - 2016-03-11 17:00:08 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:00:08 --> A session cookie was not found.
DEBUG - 2016-03-11 17:00:08 --> Session routines successfully run
DEBUG - 2016-03-11 17:00:08 --> Controller Class Initialized
DEBUG - 2016-03-11 17:00:08 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:00:08 --> Model Class Initialized
DEBUG - 2016-03-11 17:00:08 --> Model Class Initialized
DEBUG - 2016-03-11 17:00:08 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 17:00:08 --> Final output sent to browser
DEBUG - 2016-03-11 17:00:08 --> Total execution time: 1.1581
DEBUG - 2016-03-11 17:00:09 --> Config Class Initialized
DEBUG - 2016-03-11 17:00:09 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:00:09 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:00:09 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:00:09 --> URI Class Initialized
DEBUG - 2016-03-11 17:00:09 --> Router Class Initialized
DEBUG - 2016-03-11 17:00:09 --> Output Class Initialized
DEBUG - 2016-03-11 17:00:09 --> Security Class Initialized
DEBUG - 2016-03-11 17:00:09 --> Input Class Initialized
DEBUG - 2016-03-11 17:00:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:00:09 --> Language Class Initialized
DEBUG - 2016-03-11 17:00:09 --> Loader Class Initialized
DEBUG - 2016-03-11 17:00:09 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:00:09 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:00:09 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:00:09 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:00:09 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:00:10 --> Session Class Initialized
DEBUG - 2016-03-11 17:00:10 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:00:10 --> Session routines successfully run
DEBUG - 2016-03-11 17:00:10 --> Controller Class Initialized
DEBUG - 2016-03-11 17:00:10 --> Final output sent to browser
DEBUG - 2016-03-11 17:00:10 --> Total execution time: 1.1791
DEBUG - 2016-03-11 17:00:15 --> Config Class Initialized
DEBUG - 2016-03-11 17:00:15 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:00:15 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:00:15 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:00:15 --> URI Class Initialized
DEBUG - 2016-03-11 17:00:15 --> Router Class Initialized
DEBUG - 2016-03-11 17:00:15 --> Output Class Initialized
DEBUG - 2016-03-11 17:00:15 --> Security Class Initialized
DEBUG - 2016-03-11 17:00:15 --> Input Class Initialized
DEBUG - 2016-03-11 17:00:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:00:15 --> Language Class Initialized
DEBUG - 2016-03-11 17:00:15 --> Loader Class Initialized
DEBUG - 2016-03-11 17:00:15 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:00:15 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:00:15 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:00:15 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:00:15 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:00:16 --> Session Class Initialized
DEBUG - 2016-03-11 17:00:16 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:00:16 --> Session routines successfully run
DEBUG - 2016-03-11 17:00:16 --> Controller Class Initialized
DEBUG - 2016-03-11 17:00:16 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:00:16 --> Model Class Initialized
DEBUG - 2016-03-11 17:00:16 --> Model Class Initialized
ERROR - 2016-03-11 17:00:16 --> 404 Page Not Found --> campanha/upload_avatar
DEBUG - 2016-03-11 17:00:38 --> Config Class Initialized
DEBUG - 2016-03-11 17:00:38 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:00:38 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:00:38 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:00:38 --> URI Class Initialized
DEBUG - 2016-03-11 17:00:38 --> Router Class Initialized
DEBUG - 2016-03-11 17:00:38 --> Output Class Initialized
DEBUG - 2016-03-11 17:00:38 --> Security Class Initialized
DEBUG - 2016-03-11 17:00:38 --> Input Class Initialized
DEBUG - 2016-03-11 17:00:38 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:00:38 --> Language Class Initialized
DEBUG - 2016-03-11 17:00:38 --> Loader Class Initialized
DEBUG - 2016-03-11 17:00:38 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:00:38 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:00:38 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:00:38 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:00:38 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:00:39 --> Session Class Initialized
DEBUG - 2016-03-11 17:00:39 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:00:39 --> A session cookie was not found.
DEBUG - 2016-03-11 17:00:39 --> Session routines successfully run
DEBUG - 2016-03-11 17:00:39 --> Controller Class Initialized
DEBUG - 2016-03-11 17:00:39 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:00:39 --> Model Class Initialized
DEBUG - 2016-03-11 17:00:39 --> Model Class Initialized
DEBUG - 2016-03-11 17:00:39 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 17:00:39 --> Final output sent to browser
DEBUG - 2016-03-11 17:00:39 --> Total execution time: 1.1571
DEBUG - 2016-03-11 17:00:40 --> Config Class Initialized
DEBUG - 2016-03-11 17:00:40 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:00:40 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:00:40 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:00:40 --> URI Class Initialized
DEBUG - 2016-03-11 17:00:40 --> Router Class Initialized
DEBUG - 2016-03-11 17:00:40 --> Output Class Initialized
DEBUG - 2016-03-11 17:00:40 --> Security Class Initialized
DEBUG - 2016-03-11 17:00:40 --> Input Class Initialized
DEBUG - 2016-03-11 17:00:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:00:40 --> Language Class Initialized
DEBUG - 2016-03-11 17:00:40 --> Loader Class Initialized
DEBUG - 2016-03-11 17:00:40 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:00:40 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:00:40 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:00:40 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:00:40 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:00:41 --> Session Class Initialized
DEBUG - 2016-03-11 17:00:41 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:00:41 --> Session routines successfully run
DEBUG - 2016-03-11 17:00:41 --> Controller Class Initialized
DEBUG - 2016-03-11 17:00:41 --> Final output sent to browser
DEBUG - 2016-03-11 17:00:41 --> Total execution time: 1.1601
DEBUG - 2016-03-11 17:00:46 --> Config Class Initialized
DEBUG - 2016-03-11 17:00:46 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:00:46 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:00:46 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:00:46 --> URI Class Initialized
DEBUG - 2016-03-11 17:00:46 --> Router Class Initialized
DEBUG - 2016-03-11 17:00:46 --> Output Class Initialized
DEBUG - 2016-03-11 17:00:46 --> Security Class Initialized
DEBUG - 2016-03-11 17:00:46 --> Input Class Initialized
DEBUG - 2016-03-11 17:00:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:00:46 --> Language Class Initialized
DEBUG - 2016-03-11 17:00:46 --> Loader Class Initialized
DEBUG - 2016-03-11 17:00:46 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:00:46 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:00:46 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:00:46 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:00:46 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:00:47 --> Session Class Initialized
DEBUG - 2016-03-11 17:00:47 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:00:47 --> Session routines successfully run
DEBUG - 2016-03-11 17:00:47 --> Controller Class Initialized
DEBUG - 2016-03-11 17:00:47 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:00:47 --> Model Class Initialized
DEBUG - 2016-03-11 17:00:47 --> Model Class Initialized
DEBUG - 2016-03-11 17:00:47 --> Upload Class Initialized
DEBUG - 2016-03-11 17:00:47 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:00:47 --> Nenhum arquivo foi selecionado para envio.
DEBUG - 2016-03-11 17:00:47 --> Final output sent to browser
DEBUG - 2016-03-11 17:00:47 --> Total execution time: 1.2371
DEBUG - 2016-03-11 17:01:15 --> Config Class Initialized
DEBUG - 2016-03-11 17:01:15 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:01:15 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:01:15 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:01:15 --> URI Class Initialized
DEBUG - 2016-03-11 17:01:15 --> Router Class Initialized
DEBUG - 2016-03-11 17:01:15 --> Output Class Initialized
DEBUG - 2016-03-11 17:01:15 --> Security Class Initialized
DEBUG - 2016-03-11 17:01:15 --> Input Class Initialized
DEBUG - 2016-03-11 17:01:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:01:15 --> Language Class Initialized
DEBUG - 2016-03-11 17:01:15 --> Loader Class Initialized
DEBUG - 2016-03-11 17:01:15 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:01:15 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:01:15 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:01:15 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:01:15 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:01:16 --> Session Class Initialized
DEBUG - 2016-03-11 17:01:16 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:01:16 --> Session routines successfully run
DEBUG - 2016-03-11 17:01:16 --> Controller Class Initialized
DEBUG - 2016-03-11 17:01:16 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:01:16 --> Model Class Initialized
DEBUG - 2016-03-11 17:01:16 --> Model Class Initialized
DEBUG - 2016-03-11 17:01:16 --> Upload Class Initialized
DEBUG - 2016-03-11 17:01:16 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:01:16 --> Nenhum arquivo foi selecionado para envio.
DEBUG - 2016-03-11 17:01:16 --> Final output sent to browser
DEBUG - 2016-03-11 17:01:16 --> Total execution time: 1.1711
DEBUG - 2016-03-11 17:01:22 --> Config Class Initialized
DEBUG - 2016-03-11 17:01:22 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:01:22 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:01:22 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:01:22 --> URI Class Initialized
DEBUG - 2016-03-11 17:01:22 --> Router Class Initialized
DEBUG - 2016-03-11 17:01:22 --> Output Class Initialized
DEBUG - 2016-03-11 17:01:22 --> Security Class Initialized
DEBUG - 2016-03-11 17:01:22 --> Input Class Initialized
DEBUG - 2016-03-11 17:01:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:01:22 --> Language Class Initialized
DEBUG - 2016-03-11 17:01:22 --> Loader Class Initialized
DEBUG - 2016-03-11 17:01:22 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:01:22 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:01:22 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:01:22 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:01:22 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:01:23 --> Session Class Initialized
DEBUG - 2016-03-11 17:01:23 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:01:23 --> Session routines successfully run
DEBUG - 2016-03-11 17:01:23 --> Controller Class Initialized
DEBUG - 2016-03-11 17:01:23 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:01:23 --> Model Class Initialized
DEBUG - 2016-03-11 17:01:23 --> Model Class Initialized
DEBUG - 2016-03-11 17:01:23 --> Upload Class Initialized
DEBUG - 2016-03-11 17:01:23 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:01:23 --> Nenhum arquivo foi selecionado para envio.
DEBUG - 2016-03-11 17:01:23 --> Final output sent to browser
DEBUG - 2016-03-11 17:01:23 --> Total execution time: 1.1761
DEBUG - 2016-03-11 17:02:45 --> Config Class Initialized
DEBUG - 2016-03-11 17:02:45 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:02:45 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:02:45 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:02:45 --> URI Class Initialized
DEBUG - 2016-03-11 17:02:45 --> Router Class Initialized
DEBUG - 2016-03-11 17:02:45 --> Output Class Initialized
DEBUG - 2016-03-11 17:02:45 --> Security Class Initialized
DEBUG - 2016-03-11 17:02:45 --> Input Class Initialized
DEBUG - 2016-03-11 17:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:02:45 --> Language Class Initialized
DEBUG - 2016-03-11 17:02:45 --> Loader Class Initialized
DEBUG - 2016-03-11 17:02:45 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:02:45 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:02:45 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:02:45 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:02:45 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:02:46 --> Session Class Initialized
DEBUG - 2016-03-11 17:02:46 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:02:46 --> A session cookie was not found.
DEBUG - 2016-03-11 17:02:46 --> Session routines successfully run
DEBUG - 2016-03-11 17:02:46 --> Controller Class Initialized
DEBUG - 2016-03-11 17:02:46 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:02:46 --> Model Class Initialized
DEBUG - 2016-03-11 17:02:46 --> Model Class Initialized
DEBUG - 2016-03-11 17:02:46 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 17:02:46 --> Final output sent to browser
DEBUG - 2016-03-11 17:02:46 --> Total execution time: 1.1401
DEBUG - 2016-03-11 17:07:43 --> Config Class Initialized
DEBUG - 2016-03-11 17:07:43 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:07:43 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:07:43 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:07:43 --> URI Class Initialized
DEBUG - 2016-03-11 17:07:43 --> Router Class Initialized
DEBUG - 2016-03-11 17:07:43 --> Output Class Initialized
DEBUG - 2016-03-11 17:07:43 --> Security Class Initialized
DEBUG - 2016-03-11 17:07:43 --> Input Class Initialized
DEBUG - 2016-03-11 17:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:07:43 --> Language Class Initialized
DEBUG - 2016-03-11 17:07:43 --> Loader Class Initialized
DEBUG - 2016-03-11 17:07:43 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:07:43 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:07:43 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:07:43 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:07:43 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:07:44 --> Session Class Initialized
DEBUG - 2016-03-11 17:07:44 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:07:44 --> A session cookie was not found.
DEBUG - 2016-03-11 17:07:44 --> Session routines successfully run
DEBUG - 2016-03-11 17:07:44 --> Controller Class Initialized
DEBUG - 2016-03-11 17:07:44 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:07:44 --> Model Class Initialized
DEBUG - 2016-03-11 17:07:44 --> Model Class Initialized
DEBUG - 2016-03-11 17:07:44 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 17:07:44 --> Final output sent to browser
DEBUG - 2016-03-11 17:07:44 --> Total execution time: 1.1300
DEBUG - 2016-03-11 17:07:45 --> Config Class Initialized
DEBUG - 2016-03-11 17:07:45 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:07:45 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:07:45 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:07:45 --> URI Class Initialized
DEBUG - 2016-03-11 17:07:45 --> Router Class Initialized
DEBUG - 2016-03-11 17:07:45 --> Output Class Initialized
DEBUG - 2016-03-11 17:07:45 --> Security Class Initialized
DEBUG - 2016-03-11 17:07:45 --> Input Class Initialized
DEBUG - 2016-03-11 17:07:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:07:45 --> Language Class Initialized
DEBUG - 2016-03-11 17:07:45 --> Loader Class Initialized
DEBUG - 2016-03-11 17:07:45 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:07:45 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:07:45 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:07:45 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:07:45 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:07:46 --> Session Class Initialized
DEBUG - 2016-03-11 17:07:46 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:07:46 --> Session routines successfully run
DEBUG - 2016-03-11 17:07:46 --> Controller Class Initialized
DEBUG - 2016-03-11 17:07:46 --> Final output sent to browser
DEBUG - 2016-03-11 17:07:46 --> Total execution time: 1.1360
DEBUG - 2016-03-11 17:07:51 --> Config Class Initialized
DEBUG - 2016-03-11 17:07:51 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:07:51 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:07:51 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:07:51 --> URI Class Initialized
DEBUG - 2016-03-11 17:07:51 --> Router Class Initialized
DEBUG - 2016-03-11 17:07:51 --> Output Class Initialized
DEBUG - 2016-03-11 17:07:51 --> Security Class Initialized
DEBUG - 2016-03-11 17:07:51 --> Input Class Initialized
DEBUG - 2016-03-11 17:07:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:07:51 --> Language Class Initialized
DEBUG - 2016-03-11 17:07:51 --> Loader Class Initialized
DEBUG - 2016-03-11 17:07:51 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:07:51 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:07:51 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:07:51 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:07:51 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:07:52 --> Session Class Initialized
DEBUG - 2016-03-11 17:07:52 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:07:52 --> Session routines successfully run
DEBUG - 2016-03-11 17:07:52 --> Controller Class Initialized
DEBUG - 2016-03-11 17:07:52 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:07:52 --> Model Class Initialized
DEBUG - 2016-03-11 17:07:52 --> Model Class Initialized
DEBUG - 2016-03-11 17:07:53 --> Upload Class Initialized
DEBUG - 2016-03-11 17:07:53 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:07:53 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:07:53 --> Final output sent to browser
DEBUG - 2016-03-11 17:07:53 --> Total execution time: 1.2140
DEBUG - 2016-03-11 17:09:11 --> Config Class Initialized
DEBUG - 2016-03-11 17:09:11 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:09:11 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:09:11 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:09:11 --> URI Class Initialized
DEBUG - 2016-03-11 17:09:11 --> Router Class Initialized
DEBUG - 2016-03-11 17:09:11 --> Output Class Initialized
DEBUG - 2016-03-11 17:09:11 --> Security Class Initialized
DEBUG - 2016-03-11 17:09:11 --> Input Class Initialized
DEBUG - 2016-03-11 17:09:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:09:11 --> Language Class Initialized
DEBUG - 2016-03-11 17:09:11 --> Loader Class Initialized
DEBUG - 2016-03-11 17:09:11 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:09:11 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:09:11 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:09:11 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:09:11 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:09:12 --> Session Class Initialized
DEBUG - 2016-03-11 17:09:12 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:09:12 --> A session cookie was not found.
DEBUG - 2016-03-11 17:09:12 --> Session routines successfully run
DEBUG - 2016-03-11 17:09:12 --> Controller Class Initialized
DEBUG - 2016-03-11 17:09:12 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:09:12 --> Model Class Initialized
DEBUG - 2016-03-11 17:09:12 --> Model Class Initialized
DEBUG - 2016-03-11 17:09:12 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 17:09:12 --> Final output sent to browser
DEBUG - 2016-03-11 17:09:12 --> Total execution time: 1.1640
DEBUG - 2016-03-11 17:09:13 --> Config Class Initialized
DEBUG - 2016-03-11 17:09:13 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:09:13 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:09:13 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:09:13 --> URI Class Initialized
DEBUG - 2016-03-11 17:09:13 --> Router Class Initialized
DEBUG - 2016-03-11 17:09:13 --> Output Class Initialized
DEBUG - 2016-03-11 17:09:13 --> Security Class Initialized
DEBUG - 2016-03-11 17:09:13 --> Input Class Initialized
DEBUG - 2016-03-11 17:09:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:09:13 --> Language Class Initialized
DEBUG - 2016-03-11 17:09:13 --> Loader Class Initialized
DEBUG - 2016-03-11 17:09:13 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:09:13 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:09:13 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:09:13 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:09:13 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:09:14 --> Session Class Initialized
DEBUG - 2016-03-11 17:09:14 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:09:14 --> Session routines successfully run
DEBUG - 2016-03-11 17:09:14 --> Controller Class Initialized
DEBUG - 2016-03-11 17:09:14 --> Final output sent to browser
DEBUG - 2016-03-11 17:09:14 --> Total execution time: 1.1650
DEBUG - 2016-03-11 17:09:20 --> Config Class Initialized
DEBUG - 2016-03-11 17:09:20 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:09:20 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:09:20 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:09:20 --> URI Class Initialized
DEBUG - 2016-03-11 17:09:20 --> Router Class Initialized
DEBUG - 2016-03-11 17:09:20 --> Output Class Initialized
DEBUG - 2016-03-11 17:09:20 --> Security Class Initialized
DEBUG - 2016-03-11 17:09:20 --> Input Class Initialized
DEBUG - 2016-03-11 17:09:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:09:20 --> Language Class Initialized
DEBUG - 2016-03-11 17:09:20 --> Loader Class Initialized
DEBUG - 2016-03-11 17:09:20 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:09:20 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:09:20 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:09:20 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:09:20 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:09:21 --> Session Class Initialized
DEBUG - 2016-03-11 17:09:21 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:09:21 --> Session routines successfully run
DEBUG - 2016-03-11 17:09:21 --> Controller Class Initialized
DEBUG - 2016-03-11 17:09:21 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:09:21 --> Model Class Initialized
DEBUG - 2016-03-11 17:09:21 --> Model Class Initialized
DEBUG - 2016-03-11 17:09:21 --> Upload Class Initialized
DEBUG - 2016-03-11 17:09:21 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:09:21 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:09:21 --> Final output sent to browser
DEBUG - 2016-03-11 17:09:21 --> Total execution time: 1.1300
DEBUG - 2016-03-11 17:10:13 --> Config Class Initialized
DEBUG - 2016-03-11 17:10:13 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:10:13 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:10:13 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:10:13 --> URI Class Initialized
DEBUG - 2016-03-11 17:10:13 --> Router Class Initialized
DEBUG - 2016-03-11 17:10:13 --> Output Class Initialized
DEBUG - 2016-03-11 17:10:13 --> Security Class Initialized
DEBUG - 2016-03-11 17:10:13 --> Input Class Initialized
DEBUG - 2016-03-11 17:10:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:10:13 --> Language Class Initialized
DEBUG - 2016-03-11 17:10:13 --> Loader Class Initialized
DEBUG - 2016-03-11 17:10:13 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:10:13 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:10:13 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:10:13 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:10:13 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:10:14 --> Session Class Initialized
DEBUG - 2016-03-11 17:10:14 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:10:14 --> A session cookie was not found.
DEBUG - 2016-03-11 17:10:14 --> Session routines successfully run
DEBUG - 2016-03-11 17:10:14 --> Controller Class Initialized
DEBUG - 2016-03-11 17:10:14 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:10:14 --> Model Class Initialized
DEBUG - 2016-03-11 17:10:14 --> Model Class Initialized
DEBUG - 2016-03-11 17:10:14 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 17:10:14 --> Final output sent to browser
DEBUG - 2016-03-11 17:10:14 --> Total execution time: 1.1400
DEBUG - 2016-03-11 17:10:15 --> Config Class Initialized
DEBUG - 2016-03-11 17:10:15 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:10:15 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:10:15 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:10:15 --> URI Class Initialized
DEBUG - 2016-03-11 17:10:15 --> Router Class Initialized
DEBUG - 2016-03-11 17:10:15 --> Output Class Initialized
DEBUG - 2016-03-11 17:10:15 --> Security Class Initialized
DEBUG - 2016-03-11 17:10:15 --> Input Class Initialized
DEBUG - 2016-03-11 17:10:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:10:15 --> Language Class Initialized
DEBUG - 2016-03-11 17:10:15 --> Loader Class Initialized
DEBUG - 2016-03-11 17:10:15 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:10:15 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:10:15 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:10:15 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:10:15 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:10:16 --> Session Class Initialized
DEBUG - 2016-03-11 17:10:16 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:10:16 --> Session routines successfully run
DEBUG - 2016-03-11 17:10:16 --> Controller Class Initialized
DEBUG - 2016-03-11 17:10:16 --> Final output sent to browser
DEBUG - 2016-03-11 17:10:16 --> Total execution time: 1.1730
DEBUG - 2016-03-11 17:10:22 --> Config Class Initialized
DEBUG - 2016-03-11 17:10:22 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:10:22 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:10:22 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:10:22 --> URI Class Initialized
DEBUG - 2016-03-11 17:10:22 --> Router Class Initialized
DEBUG - 2016-03-11 17:10:22 --> Output Class Initialized
DEBUG - 2016-03-11 17:10:22 --> Security Class Initialized
DEBUG - 2016-03-11 17:10:22 --> Input Class Initialized
DEBUG - 2016-03-11 17:10:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:10:22 --> Language Class Initialized
DEBUG - 2016-03-11 17:10:22 --> Loader Class Initialized
DEBUG - 2016-03-11 17:10:22 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:10:22 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:10:22 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:10:22 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:10:22 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:10:23 --> Session Class Initialized
DEBUG - 2016-03-11 17:10:23 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:10:23 --> Session routines successfully run
DEBUG - 2016-03-11 17:10:23 --> Controller Class Initialized
DEBUG - 2016-03-11 17:10:23 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:10:23 --> Model Class Initialized
DEBUG - 2016-03-11 17:10:23 --> Model Class Initialized
DEBUG - 2016-03-11 17:10:23 --> Upload Class Initialized
DEBUG - 2016-03-11 17:10:23 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:10:23 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:10:23 --> Final output sent to browser
DEBUG - 2016-03-11 17:10:23 --> Total execution time: 1.1310
DEBUG - 2016-03-11 17:10:42 --> Config Class Initialized
DEBUG - 2016-03-11 17:10:42 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:10:42 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:10:42 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:10:42 --> URI Class Initialized
DEBUG - 2016-03-11 17:10:42 --> Router Class Initialized
DEBUG - 2016-03-11 17:10:42 --> Output Class Initialized
DEBUG - 2016-03-11 17:10:42 --> Security Class Initialized
DEBUG - 2016-03-11 17:10:42 --> Input Class Initialized
DEBUG - 2016-03-11 17:10:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:10:42 --> Language Class Initialized
DEBUG - 2016-03-11 17:10:42 --> Loader Class Initialized
DEBUG - 2016-03-11 17:10:42 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:10:42 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:10:42 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:10:42 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:10:42 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:10:43 --> Session Class Initialized
DEBUG - 2016-03-11 17:10:43 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:10:43 --> A session cookie was not found.
DEBUG - 2016-03-11 17:10:43 --> Session routines successfully run
DEBUG - 2016-03-11 17:10:43 --> Controller Class Initialized
DEBUG - 2016-03-11 17:10:43 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:10:43 --> Model Class Initialized
DEBUG - 2016-03-11 17:10:43 --> Model Class Initialized
DEBUG - 2016-03-11 17:10:43 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 17:10:43 --> Final output sent to browser
DEBUG - 2016-03-11 17:10:43 --> Total execution time: 1.1500
DEBUG - 2016-03-11 17:10:44 --> Config Class Initialized
DEBUG - 2016-03-11 17:10:44 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:10:44 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:10:44 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:10:44 --> URI Class Initialized
DEBUG - 2016-03-11 17:10:44 --> Router Class Initialized
DEBUG - 2016-03-11 17:10:44 --> Output Class Initialized
DEBUG - 2016-03-11 17:10:44 --> Security Class Initialized
DEBUG - 2016-03-11 17:10:44 --> Input Class Initialized
DEBUG - 2016-03-11 17:10:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:10:44 --> Language Class Initialized
DEBUG - 2016-03-11 17:10:44 --> Loader Class Initialized
DEBUG - 2016-03-11 17:10:44 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:10:44 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:10:44 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:10:44 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:10:44 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:10:45 --> Session Class Initialized
DEBUG - 2016-03-11 17:10:45 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:10:45 --> Session routines successfully run
DEBUG - 2016-03-11 17:10:45 --> Controller Class Initialized
DEBUG - 2016-03-11 17:10:45 --> Final output sent to browser
DEBUG - 2016-03-11 17:10:45 --> Total execution time: 1.1860
DEBUG - 2016-03-11 17:10:50 --> Config Class Initialized
DEBUG - 2016-03-11 17:10:50 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:10:50 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:10:50 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:10:50 --> URI Class Initialized
DEBUG - 2016-03-11 17:10:50 --> Router Class Initialized
DEBUG - 2016-03-11 17:10:50 --> Output Class Initialized
DEBUG - 2016-03-11 17:10:50 --> Security Class Initialized
DEBUG - 2016-03-11 17:10:50 --> Input Class Initialized
DEBUG - 2016-03-11 17:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:10:50 --> Language Class Initialized
DEBUG - 2016-03-11 17:10:50 --> Loader Class Initialized
DEBUG - 2016-03-11 17:10:50 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:10:50 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:10:50 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:10:50 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:10:50 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:10:51 --> Session Class Initialized
DEBUG - 2016-03-11 17:10:51 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:10:51 --> Session routines successfully run
DEBUG - 2016-03-11 17:10:51 --> Controller Class Initialized
DEBUG - 2016-03-11 17:10:51 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:10:51 --> Model Class Initialized
DEBUG - 2016-03-11 17:10:51 --> Model Class Initialized
DEBUG - 2016-03-11 17:10:51 --> Upload Class Initialized
DEBUG - 2016-03-11 17:10:51 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:10:51 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:10:51 --> Final output sent to browser
DEBUG - 2016-03-11 17:10:51 --> Total execution time: 1.1110
DEBUG - 2016-03-11 17:13:33 --> Config Class Initialized
DEBUG - 2016-03-11 17:13:33 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:13:33 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:13:33 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:13:33 --> URI Class Initialized
DEBUG - 2016-03-11 17:13:33 --> Router Class Initialized
DEBUG - 2016-03-11 17:13:33 --> Output Class Initialized
DEBUG - 2016-03-11 17:13:33 --> Security Class Initialized
DEBUG - 2016-03-11 17:13:33 --> Input Class Initialized
DEBUG - 2016-03-11 17:13:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:13:33 --> Language Class Initialized
DEBUG - 2016-03-11 17:13:33 --> Loader Class Initialized
DEBUG - 2016-03-11 17:13:33 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:13:33 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:13:33 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:13:33 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:13:33 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:13:34 --> Session Class Initialized
DEBUG - 2016-03-11 17:13:34 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:13:34 --> A session cookie was not found.
DEBUG - 2016-03-11 17:13:34 --> Session routines successfully run
DEBUG - 2016-03-11 17:13:34 --> Controller Class Initialized
DEBUG - 2016-03-11 17:13:34 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:13:34 --> Model Class Initialized
DEBUG - 2016-03-11 17:13:34 --> Model Class Initialized
DEBUG - 2016-03-11 17:13:34 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 17:13:34 --> Final output sent to browser
DEBUG - 2016-03-11 17:13:34 --> Total execution time: 1.1600
DEBUG - 2016-03-11 17:13:35 --> Config Class Initialized
DEBUG - 2016-03-11 17:13:35 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:13:35 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:13:35 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:13:35 --> URI Class Initialized
DEBUG - 2016-03-11 17:13:35 --> Router Class Initialized
DEBUG - 2016-03-11 17:13:35 --> Output Class Initialized
DEBUG - 2016-03-11 17:13:35 --> Security Class Initialized
DEBUG - 2016-03-11 17:13:35 --> Input Class Initialized
DEBUG - 2016-03-11 17:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:13:35 --> Language Class Initialized
DEBUG - 2016-03-11 17:13:35 --> Loader Class Initialized
DEBUG - 2016-03-11 17:13:35 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:13:35 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:13:35 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:13:35 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:13:35 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:13:36 --> Session Class Initialized
DEBUG - 2016-03-11 17:13:36 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:13:36 --> Session routines successfully run
DEBUG - 2016-03-11 17:13:36 --> Controller Class Initialized
DEBUG - 2016-03-11 17:13:36 --> Final output sent to browser
DEBUG - 2016-03-11 17:13:36 --> Total execution time: 1.1720
DEBUG - 2016-03-11 17:13:42 --> Config Class Initialized
DEBUG - 2016-03-11 17:13:42 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:13:42 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:13:42 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:13:42 --> URI Class Initialized
DEBUG - 2016-03-11 17:13:42 --> Router Class Initialized
DEBUG - 2016-03-11 17:13:42 --> Output Class Initialized
DEBUG - 2016-03-11 17:13:42 --> Security Class Initialized
DEBUG - 2016-03-11 17:13:42 --> Input Class Initialized
DEBUG - 2016-03-11 17:13:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:13:42 --> Language Class Initialized
DEBUG - 2016-03-11 17:13:42 --> Loader Class Initialized
DEBUG - 2016-03-11 17:13:42 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:13:42 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:13:42 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:13:42 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:13:42 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:13:43 --> Session Class Initialized
DEBUG - 2016-03-11 17:13:43 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:13:43 --> Session routines successfully run
DEBUG - 2016-03-11 17:13:43 --> Controller Class Initialized
DEBUG - 2016-03-11 17:13:43 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:13:43 --> Model Class Initialized
DEBUG - 2016-03-11 17:13:43 --> Model Class Initialized
DEBUG - 2016-03-11 17:13:43 --> Upload Class Initialized
DEBUG - 2016-03-11 17:13:43 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:13:43 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:13:43 --> Final output sent to browser
DEBUG - 2016-03-11 17:13:43 --> Total execution time: 1.1310
DEBUG - 2016-03-11 17:14:57 --> Config Class Initialized
DEBUG - 2016-03-11 17:14:57 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:14:57 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:14:57 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:14:57 --> URI Class Initialized
DEBUG - 2016-03-11 17:14:57 --> Router Class Initialized
DEBUG - 2016-03-11 17:14:57 --> Output Class Initialized
DEBUG - 2016-03-11 17:14:57 --> Security Class Initialized
DEBUG - 2016-03-11 17:14:57 --> Input Class Initialized
DEBUG - 2016-03-11 17:14:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:14:57 --> Language Class Initialized
DEBUG - 2016-03-11 17:14:57 --> Loader Class Initialized
DEBUG - 2016-03-11 17:14:57 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:14:57 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:14:57 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:14:57 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:14:57 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:14:58 --> Session Class Initialized
DEBUG - 2016-03-11 17:14:58 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:14:58 --> A session cookie was not found.
DEBUG - 2016-03-11 17:14:58 --> Session routines successfully run
DEBUG - 2016-03-11 17:14:58 --> Controller Class Initialized
DEBUG - 2016-03-11 17:14:58 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:14:58 --> Model Class Initialized
DEBUG - 2016-03-11 17:14:58 --> Model Class Initialized
DEBUG - 2016-03-11 17:14:58 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 17:14:58 --> Final output sent to browser
DEBUG - 2016-03-11 17:14:58 --> Total execution time: 1.1560
DEBUG - 2016-03-11 17:14:59 --> Config Class Initialized
DEBUG - 2016-03-11 17:14:59 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:14:59 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:14:59 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:14:59 --> URI Class Initialized
DEBUG - 2016-03-11 17:14:59 --> Router Class Initialized
DEBUG - 2016-03-11 17:14:59 --> Output Class Initialized
DEBUG - 2016-03-11 17:14:59 --> Security Class Initialized
DEBUG - 2016-03-11 17:14:59 --> Input Class Initialized
DEBUG - 2016-03-11 17:14:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:14:59 --> Language Class Initialized
DEBUG - 2016-03-11 17:14:59 --> Loader Class Initialized
DEBUG - 2016-03-11 17:14:59 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:14:59 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:14:59 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:14:59 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:14:59 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:15:00 --> Session Class Initialized
DEBUG - 2016-03-11 17:15:00 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:15:00 --> Session routines successfully run
DEBUG - 2016-03-11 17:15:00 --> Controller Class Initialized
DEBUG - 2016-03-11 17:15:00 --> Final output sent to browser
DEBUG - 2016-03-11 17:15:00 --> Total execution time: 1.1800
DEBUG - 2016-03-11 17:15:07 --> Config Class Initialized
DEBUG - 2016-03-11 17:15:07 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:15:07 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:15:07 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:15:07 --> URI Class Initialized
DEBUG - 2016-03-11 17:15:07 --> Router Class Initialized
DEBUG - 2016-03-11 17:15:07 --> Output Class Initialized
DEBUG - 2016-03-11 17:15:07 --> Security Class Initialized
DEBUG - 2016-03-11 17:15:07 --> Input Class Initialized
DEBUG - 2016-03-11 17:15:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:15:07 --> Language Class Initialized
DEBUG - 2016-03-11 17:15:07 --> Loader Class Initialized
DEBUG - 2016-03-11 17:15:07 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:15:07 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:15:07 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:15:07 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:15:07 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:15:08 --> Session Class Initialized
DEBUG - 2016-03-11 17:15:08 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:15:08 --> Session routines successfully run
DEBUG - 2016-03-11 17:15:08 --> Controller Class Initialized
DEBUG - 2016-03-11 17:15:08 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:15:08 --> Model Class Initialized
DEBUG - 2016-03-11 17:15:08 --> Model Class Initialized
DEBUG - 2016-03-11 17:15:08 --> Upload Class Initialized
DEBUG - 2016-03-11 17:15:08 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:15:08 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:15:08 --> Final output sent to browser
DEBUG - 2016-03-11 17:15:08 --> Total execution time: 1.1430
DEBUG - 2016-03-11 17:15:28 --> Config Class Initialized
DEBUG - 2016-03-11 17:15:28 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:15:28 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:15:28 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:15:28 --> URI Class Initialized
DEBUG - 2016-03-11 17:15:28 --> Router Class Initialized
DEBUG - 2016-03-11 17:15:28 --> Output Class Initialized
DEBUG - 2016-03-11 17:15:28 --> Security Class Initialized
DEBUG - 2016-03-11 17:15:28 --> Input Class Initialized
DEBUG - 2016-03-11 17:15:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:15:28 --> Language Class Initialized
DEBUG - 2016-03-11 17:15:28 --> Loader Class Initialized
DEBUG - 2016-03-11 17:15:28 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:15:28 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:15:28 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:15:28 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:15:28 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:15:29 --> Session Class Initialized
DEBUG - 2016-03-11 17:15:29 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:15:29 --> Session routines successfully run
DEBUG - 2016-03-11 17:15:29 --> Controller Class Initialized
DEBUG - 2016-03-11 17:15:29 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:15:29 --> Model Class Initialized
DEBUG - 2016-03-11 17:15:29 --> Model Class Initialized
DEBUG - 2016-03-11 17:16:17 --> Config Class Initialized
DEBUG - 2016-03-11 17:16:17 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:16:17 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:16:17 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:16:17 --> URI Class Initialized
DEBUG - 2016-03-11 17:16:17 --> Router Class Initialized
DEBUG - 2016-03-11 17:16:17 --> Output Class Initialized
DEBUG - 2016-03-11 17:16:17 --> Security Class Initialized
DEBUG - 2016-03-11 17:16:17 --> Input Class Initialized
DEBUG - 2016-03-11 17:16:17 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:16:17 --> Language Class Initialized
DEBUG - 2016-03-11 17:16:17 --> Loader Class Initialized
DEBUG - 2016-03-11 17:16:17 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:16:17 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:16:17 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:16:17 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:16:17 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:16:18 --> Session Class Initialized
DEBUG - 2016-03-11 17:16:18 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:16:18 --> Session routines successfully run
DEBUG - 2016-03-11 17:16:18 --> Controller Class Initialized
DEBUG - 2016-03-11 17:16:18 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:16:18 --> Model Class Initialized
DEBUG - 2016-03-11 17:16:18 --> Model Class Initialized
DEBUG - 2016-03-11 17:16:30 --> Config Class Initialized
DEBUG - 2016-03-11 17:16:30 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:16:30 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:16:30 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:16:30 --> URI Class Initialized
DEBUG - 2016-03-11 17:16:30 --> Router Class Initialized
DEBUG - 2016-03-11 17:16:30 --> Output Class Initialized
DEBUG - 2016-03-11 17:16:30 --> Security Class Initialized
DEBUG - 2016-03-11 17:16:30 --> Input Class Initialized
DEBUG - 2016-03-11 17:16:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:16:30 --> Language Class Initialized
DEBUG - 2016-03-11 17:16:30 --> Loader Class Initialized
DEBUG - 2016-03-11 17:16:30 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:16:30 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:16:30 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:16:30 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:16:30 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:16:31 --> Session Class Initialized
DEBUG - 2016-03-11 17:16:31 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:16:31 --> Session routines successfully run
DEBUG - 2016-03-11 17:16:31 --> Controller Class Initialized
DEBUG - 2016-03-11 17:16:31 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:16:31 --> Model Class Initialized
DEBUG - 2016-03-11 17:16:31 --> Model Class Initialized
DEBUG - 2016-03-11 17:17:23 --> Config Class Initialized
DEBUG - 2016-03-11 17:17:23 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:17:23 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:17:23 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:17:23 --> URI Class Initialized
DEBUG - 2016-03-11 17:17:23 --> Router Class Initialized
DEBUG - 2016-03-11 17:17:23 --> Output Class Initialized
DEBUG - 2016-03-11 17:17:23 --> Security Class Initialized
DEBUG - 2016-03-11 17:17:23 --> Input Class Initialized
DEBUG - 2016-03-11 17:17:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:17:23 --> Language Class Initialized
DEBUG - 2016-03-11 17:17:23 --> Loader Class Initialized
DEBUG - 2016-03-11 17:17:23 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:17:23 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:17:23 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:17:23 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:17:23 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:17:24 --> Session Class Initialized
DEBUG - 2016-03-11 17:17:24 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:17:24 --> Session routines successfully run
DEBUG - 2016-03-11 17:17:24 --> Controller Class Initialized
DEBUG - 2016-03-11 17:17:24 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:17:24 --> Model Class Initialized
DEBUG - 2016-03-11 17:17:24 --> Model Class Initialized
DEBUG - 2016-03-11 17:18:42 --> Config Class Initialized
DEBUG - 2016-03-11 17:18:42 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:18:42 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:18:42 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:18:42 --> URI Class Initialized
DEBUG - 2016-03-11 17:18:42 --> Router Class Initialized
DEBUG - 2016-03-11 17:18:42 --> Output Class Initialized
DEBUG - 2016-03-11 17:18:42 --> Security Class Initialized
DEBUG - 2016-03-11 17:18:42 --> Input Class Initialized
DEBUG - 2016-03-11 17:18:42 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:18:42 --> Language Class Initialized
DEBUG - 2016-03-11 17:18:42 --> Loader Class Initialized
DEBUG - 2016-03-11 17:18:42 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:18:42 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:18:42 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:18:42 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:18:42 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:18:43 --> Session Class Initialized
DEBUG - 2016-03-11 17:18:43 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:18:43 --> Session routines successfully run
DEBUG - 2016-03-11 17:18:43 --> Controller Class Initialized
DEBUG - 2016-03-11 17:18:43 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:18:43 --> Model Class Initialized
DEBUG - 2016-03-11 17:18:43 --> Model Class Initialized
DEBUG - 2016-03-11 17:18:43 --> Upload Class Initialized
DEBUG - 2016-03-11 17:18:43 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:18:43 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:18:43 --> Final output sent to browser
DEBUG - 2016-03-11 17:18:43 --> Total execution time: 1.1811
DEBUG - 2016-03-11 17:18:53 --> Config Class Initialized
DEBUG - 2016-03-11 17:18:53 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:18:53 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:18:53 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:18:53 --> URI Class Initialized
DEBUG - 2016-03-11 17:18:53 --> Router Class Initialized
DEBUG - 2016-03-11 17:18:53 --> Output Class Initialized
DEBUG - 2016-03-11 17:18:53 --> Security Class Initialized
DEBUG - 2016-03-11 17:18:53 --> Input Class Initialized
DEBUG - 2016-03-11 17:18:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:18:53 --> Language Class Initialized
DEBUG - 2016-03-11 17:18:53 --> Loader Class Initialized
DEBUG - 2016-03-11 17:18:53 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:18:53 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:18:53 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:18:53 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:18:53 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:18:54 --> Session Class Initialized
DEBUG - 2016-03-11 17:18:54 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:18:54 --> Session routines successfully run
DEBUG - 2016-03-11 17:18:54 --> Controller Class Initialized
DEBUG - 2016-03-11 17:18:54 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:18:54 --> Model Class Initialized
DEBUG - 2016-03-11 17:18:54 --> Model Class Initialized
DEBUG - 2016-03-11 17:18:54 --> Upload Class Initialized
DEBUG - 2016-03-11 17:18:54 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:18:54 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:18:54 --> Final output sent to browser
DEBUG - 2016-03-11 17:18:54 --> Total execution time: 1.1481
DEBUG - 2016-03-11 17:20:20 --> Config Class Initialized
DEBUG - 2016-03-11 17:20:20 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:20:20 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:20:20 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:20:20 --> URI Class Initialized
DEBUG - 2016-03-11 17:20:20 --> Router Class Initialized
DEBUG - 2016-03-11 17:20:20 --> Output Class Initialized
DEBUG - 2016-03-11 17:20:20 --> Security Class Initialized
DEBUG - 2016-03-11 17:20:20 --> Input Class Initialized
DEBUG - 2016-03-11 17:20:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:20:20 --> Language Class Initialized
DEBUG - 2016-03-11 17:20:20 --> Loader Class Initialized
DEBUG - 2016-03-11 17:20:20 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:20:20 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:20:20 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:20:20 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:20:20 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:20:21 --> Session Class Initialized
DEBUG - 2016-03-11 17:20:21 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:20:21 --> Session routines successfully run
DEBUG - 2016-03-11 17:20:21 --> Controller Class Initialized
DEBUG - 2016-03-11 17:20:21 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:20:21 --> Model Class Initialized
DEBUG - 2016-03-11 17:20:21 --> Model Class Initialized
DEBUG - 2016-03-11 17:20:21 --> Upload Class Initialized
DEBUG - 2016-03-11 17:20:21 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:20:21 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:20:21 --> Final output sent to browser
DEBUG - 2016-03-11 17:20:21 --> Total execution time: 1.1541
DEBUG - 2016-03-11 17:21:37 --> Config Class Initialized
DEBUG - 2016-03-11 17:21:37 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:21:37 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:21:37 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:21:37 --> URI Class Initialized
DEBUG - 2016-03-11 17:21:37 --> Router Class Initialized
DEBUG - 2016-03-11 17:21:37 --> Output Class Initialized
DEBUG - 2016-03-11 17:21:37 --> Security Class Initialized
DEBUG - 2016-03-11 17:21:37 --> Input Class Initialized
DEBUG - 2016-03-11 17:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:21:37 --> Language Class Initialized
DEBUG - 2016-03-11 17:21:37 --> Loader Class Initialized
DEBUG - 2016-03-11 17:21:37 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:21:37 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:21:37 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:21:37 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:21:37 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:21:38 --> Session Class Initialized
DEBUG - 2016-03-11 17:21:38 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:21:38 --> Session routines successfully run
DEBUG - 2016-03-11 17:21:38 --> Controller Class Initialized
DEBUG - 2016-03-11 17:21:38 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:21:39 --> Model Class Initialized
DEBUG - 2016-03-11 17:21:39 --> Model Class Initialized
DEBUG - 2016-03-11 17:22:03 --> Config Class Initialized
DEBUG - 2016-03-11 17:22:03 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:22:03 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:22:03 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:22:03 --> URI Class Initialized
DEBUG - 2016-03-11 17:22:03 --> Router Class Initialized
DEBUG - 2016-03-11 17:22:03 --> Output Class Initialized
DEBUG - 2016-03-11 17:22:03 --> Security Class Initialized
DEBUG - 2016-03-11 17:22:03 --> Input Class Initialized
DEBUG - 2016-03-11 17:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:22:03 --> Language Class Initialized
DEBUG - 2016-03-11 17:22:03 --> Loader Class Initialized
DEBUG - 2016-03-11 17:22:03 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:22:03 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:22:03 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:22:03 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:22:03 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:22:04 --> Session Class Initialized
DEBUG - 2016-03-11 17:22:04 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:22:04 --> Session routines successfully run
DEBUG - 2016-03-11 17:22:04 --> Controller Class Initialized
DEBUG - 2016-03-11 17:22:04 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:22:04 --> Model Class Initialized
DEBUG - 2016-03-11 17:22:04 --> Model Class Initialized
DEBUG - 2016-03-11 17:22:04 --> Upload Class Initialized
DEBUG - 2016-03-11 17:22:04 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:22:04 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:22:04 --> Final output sent to browser
DEBUG - 2016-03-11 17:22:04 --> Total execution time: 1.1571
DEBUG - 2016-03-11 17:22:26 --> Config Class Initialized
DEBUG - 2016-03-11 17:22:26 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:22:26 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:22:26 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:22:26 --> URI Class Initialized
DEBUG - 2016-03-11 17:22:26 --> Router Class Initialized
DEBUG - 2016-03-11 17:22:26 --> Output Class Initialized
DEBUG - 2016-03-11 17:22:26 --> Security Class Initialized
DEBUG - 2016-03-11 17:22:26 --> Input Class Initialized
DEBUG - 2016-03-11 17:22:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:22:26 --> Language Class Initialized
DEBUG - 2016-03-11 17:22:26 --> Loader Class Initialized
DEBUG - 2016-03-11 17:22:26 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:22:26 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:22:26 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:22:26 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:22:26 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:22:27 --> Session Class Initialized
DEBUG - 2016-03-11 17:22:27 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:22:27 --> Session routines successfully run
DEBUG - 2016-03-11 17:22:27 --> Controller Class Initialized
DEBUG - 2016-03-11 17:22:27 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:22:27 --> Model Class Initialized
DEBUG - 2016-03-11 17:22:27 --> Model Class Initialized
DEBUG - 2016-03-11 17:22:27 --> Upload Class Initialized
DEBUG - 2016-03-11 17:22:27 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:22:27 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:22:27 --> Final output sent to browser
DEBUG - 2016-03-11 17:22:27 --> Total execution time: 1.1111
DEBUG - 2016-03-11 17:23:45 --> Config Class Initialized
DEBUG - 2016-03-11 17:23:45 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:23:45 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:23:45 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:23:45 --> URI Class Initialized
DEBUG - 2016-03-11 17:23:45 --> Router Class Initialized
DEBUG - 2016-03-11 17:23:45 --> Output Class Initialized
DEBUG - 2016-03-11 17:23:45 --> Security Class Initialized
DEBUG - 2016-03-11 17:23:45 --> Input Class Initialized
DEBUG - 2016-03-11 17:23:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:23:45 --> Language Class Initialized
DEBUG - 2016-03-11 17:23:45 --> Loader Class Initialized
DEBUG - 2016-03-11 17:23:45 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:23:45 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:23:45 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:23:45 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:23:45 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:23:46 --> Session Class Initialized
DEBUG - 2016-03-11 17:23:47 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:23:47 --> Session routines successfully run
DEBUG - 2016-03-11 17:23:47 --> Controller Class Initialized
DEBUG - 2016-03-11 17:23:47 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:23:47 --> Model Class Initialized
DEBUG - 2016-03-11 17:23:47 --> Model Class Initialized
DEBUG - 2016-03-11 17:23:47 --> Upload Class Initialized
DEBUG - 2016-03-11 17:23:47 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:23:47 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:23:47 --> Final output sent to browser
DEBUG - 2016-03-11 17:23:47 --> Total execution time: 1.2161
DEBUG - 2016-03-11 17:24:03 --> Config Class Initialized
DEBUG - 2016-03-11 17:24:03 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:24:03 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:24:03 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:24:03 --> URI Class Initialized
DEBUG - 2016-03-11 17:24:03 --> Router Class Initialized
DEBUG - 2016-03-11 17:24:03 --> Output Class Initialized
DEBUG - 2016-03-11 17:24:03 --> Security Class Initialized
DEBUG - 2016-03-11 17:24:03 --> Input Class Initialized
DEBUG - 2016-03-11 17:24:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:24:03 --> Language Class Initialized
DEBUG - 2016-03-11 17:24:03 --> Loader Class Initialized
DEBUG - 2016-03-11 17:24:03 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:24:03 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:24:03 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:24:03 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:24:03 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:24:04 --> Session Class Initialized
DEBUG - 2016-03-11 17:24:04 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:24:04 --> Session routines successfully run
DEBUG - 2016-03-11 17:24:04 --> Controller Class Initialized
DEBUG - 2016-03-11 17:24:04 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:24:04 --> Model Class Initialized
DEBUG - 2016-03-11 17:24:04 --> Model Class Initialized
DEBUG - 2016-03-11 17:24:28 --> Config Class Initialized
DEBUG - 2016-03-11 17:24:28 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:24:28 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:24:28 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:24:28 --> URI Class Initialized
DEBUG - 2016-03-11 17:24:28 --> Router Class Initialized
DEBUG - 2016-03-11 17:24:28 --> Output Class Initialized
DEBUG - 2016-03-11 17:24:28 --> Security Class Initialized
DEBUG - 2016-03-11 17:24:28 --> Input Class Initialized
DEBUG - 2016-03-11 17:24:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:24:28 --> Language Class Initialized
DEBUG - 2016-03-11 17:24:28 --> Loader Class Initialized
DEBUG - 2016-03-11 17:24:28 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:24:28 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:24:28 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:24:28 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:24:28 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:24:29 --> Session Class Initialized
DEBUG - 2016-03-11 17:24:29 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:24:29 --> A session cookie was not found.
DEBUG - 2016-03-11 17:24:29 --> Session routines successfully run
DEBUG - 2016-03-11 17:24:29 --> Controller Class Initialized
DEBUG - 2016-03-11 17:24:29 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:24:29 --> Model Class Initialized
DEBUG - 2016-03-11 17:24:29 --> Model Class Initialized
DEBUG - 2016-03-11 17:24:29 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 17:24:29 --> Final output sent to browser
DEBUG - 2016-03-11 17:24:29 --> Total execution time: 1.1320
DEBUG - 2016-03-11 17:24:30 --> Config Class Initialized
DEBUG - 2016-03-11 17:24:30 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:24:30 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:24:30 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:24:30 --> URI Class Initialized
DEBUG - 2016-03-11 17:24:30 --> Router Class Initialized
DEBUG - 2016-03-11 17:24:30 --> Output Class Initialized
DEBUG - 2016-03-11 17:24:30 --> Security Class Initialized
DEBUG - 2016-03-11 17:24:30 --> Input Class Initialized
DEBUG - 2016-03-11 17:24:30 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:24:30 --> Language Class Initialized
DEBUG - 2016-03-11 17:24:30 --> Loader Class Initialized
DEBUG - 2016-03-11 17:24:30 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:24:30 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:24:30 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:24:30 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:24:30 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:24:31 --> Session Class Initialized
DEBUG - 2016-03-11 17:24:31 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:24:31 --> Session routines successfully run
DEBUG - 2016-03-11 17:24:31 --> Controller Class Initialized
DEBUG - 2016-03-11 17:24:31 --> Final output sent to browser
DEBUG - 2016-03-11 17:24:31 --> Total execution time: 1.2060
DEBUG - 2016-03-11 17:24:36 --> Config Class Initialized
DEBUG - 2016-03-11 17:24:36 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:24:36 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:24:36 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:24:36 --> URI Class Initialized
DEBUG - 2016-03-11 17:24:36 --> Router Class Initialized
DEBUG - 2016-03-11 17:24:36 --> Output Class Initialized
DEBUG - 2016-03-11 17:24:36 --> Security Class Initialized
DEBUG - 2016-03-11 17:24:36 --> Input Class Initialized
DEBUG - 2016-03-11 17:24:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:24:36 --> Language Class Initialized
DEBUG - 2016-03-11 17:24:36 --> Loader Class Initialized
DEBUG - 2016-03-11 17:24:36 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:24:36 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:24:36 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:24:36 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:24:36 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:24:37 --> Session Class Initialized
DEBUG - 2016-03-11 17:24:37 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:24:37 --> Session routines successfully run
DEBUG - 2016-03-11 17:24:37 --> Controller Class Initialized
DEBUG - 2016-03-11 17:24:37 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:24:37 --> Model Class Initialized
DEBUG - 2016-03-11 17:24:37 --> Model Class Initialized
DEBUG - 2016-03-11 17:24:37 --> Upload Class Initialized
DEBUG - 2016-03-11 17:24:37 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:24:37 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:24:37 --> Final output sent to browser
DEBUG - 2016-03-11 17:24:37 --> Total execution time: 1.1170
DEBUG - 2016-03-11 17:26:06 --> Config Class Initialized
DEBUG - 2016-03-11 17:26:06 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:26:06 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:26:06 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:26:06 --> URI Class Initialized
DEBUG - 2016-03-11 17:26:06 --> Router Class Initialized
DEBUG - 2016-03-11 17:26:06 --> Output Class Initialized
DEBUG - 2016-03-11 17:26:06 --> Security Class Initialized
DEBUG - 2016-03-11 17:26:06 --> Input Class Initialized
DEBUG - 2016-03-11 17:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:26:06 --> Language Class Initialized
DEBUG - 2016-03-11 17:26:06 --> Loader Class Initialized
DEBUG - 2016-03-11 17:26:06 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:26:06 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:26:06 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:26:06 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:26:06 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:26:07 --> Session Class Initialized
DEBUG - 2016-03-11 17:26:07 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:26:07 --> A session cookie was not found.
DEBUG - 2016-03-11 17:26:07 --> Session routines successfully run
DEBUG - 2016-03-11 17:26:07 --> Controller Class Initialized
DEBUG - 2016-03-11 17:26:07 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:26:07 --> Model Class Initialized
DEBUG - 2016-03-11 17:26:07 --> Model Class Initialized
DEBUG - 2016-03-11 17:26:07 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 17:26:07 --> Final output sent to browser
DEBUG - 2016-03-11 17:26:07 --> Total execution time: 1.2010
DEBUG - 2016-03-11 17:26:08 --> Config Class Initialized
DEBUG - 2016-03-11 17:26:08 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:26:08 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:26:08 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:26:08 --> URI Class Initialized
DEBUG - 2016-03-11 17:26:08 --> Router Class Initialized
DEBUG - 2016-03-11 17:26:08 --> Output Class Initialized
DEBUG - 2016-03-11 17:26:08 --> Security Class Initialized
DEBUG - 2016-03-11 17:26:08 --> Input Class Initialized
DEBUG - 2016-03-11 17:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:26:08 --> Language Class Initialized
DEBUG - 2016-03-11 17:26:08 --> Loader Class Initialized
DEBUG - 2016-03-11 17:26:08 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:26:08 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:26:08 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:26:08 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:26:08 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:26:09 --> Session Class Initialized
DEBUG - 2016-03-11 17:26:09 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:26:09 --> Session routines successfully run
DEBUG - 2016-03-11 17:26:09 --> Controller Class Initialized
DEBUG - 2016-03-11 17:26:09 --> Final output sent to browser
DEBUG - 2016-03-11 17:26:09 --> Total execution time: 1.1200
DEBUG - 2016-03-11 17:26:15 --> Config Class Initialized
DEBUG - 2016-03-11 17:26:15 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:26:15 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:26:15 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:26:15 --> URI Class Initialized
DEBUG - 2016-03-11 17:26:15 --> Router Class Initialized
DEBUG - 2016-03-11 17:26:15 --> Output Class Initialized
DEBUG - 2016-03-11 17:26:15 --> Security Class Initialized
DEBUG - 2016-03-11 17:26:15 --> Input Class Initialized
DEBUG - 2016-03-11 17:26:15 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:26:15 --> Language Class Initialized
DEBUG - 2016-03-11 17:26:15 --> Loader Class Initialized
DEBUG - 2016-03-11 17:26:15 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:26:15 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:26:15 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:26:15 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:26:15 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:26:16 --> Session Class Initialized
DEBUG - 2016-03-11 17:26:16 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:26:16 --> Session routines successfully run
DEBUG - 2016-03-11 17:26:16 --> Controller Class Initialized
DEBUG - 2016-03-11 17:26:16 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:26:16 --> Model Class Initialized
DEBUG - 2016-03-11 17:26:16 --> Model Class Initialized
DEBUG - 2016-03-11 17:26:16 --> Upload Class Initialized
DEBUG - 2016-03-11 17:26:16 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:26:16 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:26:16 --> Final output sent to browser
DEBUG - 2016-03-11 17:26:16 --> Total execution time: 1.1550
DEBUG - 2016-03-11 17:37:40 --> Config Class Initialized
DEBUG - 2016-03-11 17:37:40 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:37:40 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:37:40 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:37:40 --> URI Class Initialized
DEBUG - 2016-03-11 17:37:40 --> Router Class Initialized
DEBUG - 2016-03-11 17:37:40 --> Output Class Initialized
DEBUG - 2016-03-11 17:37:40 --> Security Class Initialized
DEBUG - 2016-03-11 17:37:40 --> Input Class Initialized
DEBUG - 2016-03-11 17:37:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:37:40 --> Language Class Initialized
DEBUG - 2016-03-11 17:37:40 --> Loader Class Initialized
DEBUG - 2016-03-11 17:37:40 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:37:40 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:37:40 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:37:40 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:37:40 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:37:41 --> Session Class Initialized
DEBUG - 2016-03-11 17:37:41 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:37:41 --> A session cookie was not found.
DEBUG - 2016-03-11 17:37:41 --> Session routines successfully run
DEBUG - 2016-03-11 17:37:41 --> Controller Class Initialized
DEBUG - 2016-03-11 17:37:41 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:37:41 --> Model Class Initialized
DEBUG - 2016-03-11 17:37:41 --> Model Class Initialized
DEBUG - 2016-03-11 17:37:41 --> File loaded: application/views/campanhas_listar.php
DEBUG - 2016-03-11 17:37:41 --> Final output sent to browser
DEBUG - 2016-03-11 17:37:41 --> Total execution time: 1.1421
DEBUG - 2016-03-11 17:37:41 --> Config Class Initialized
DEBUG - 2016-03-11 17:37:41 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:37:41 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:37:41 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:37:41 --> URI Class Initialized
DEBUG - 2016-03-11 17:37:41 --> Router Class Initialized
DEBUG - 2016-03-11 17:37:41 --> Output Class Initialized
DEBUG - 2016-03-11 17:37:41 --> Security Class Initialized
DEBUG - 2016-03-11 17:37:41 --> Input Class Initialized
DEBUG - 2016-03-11 17:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:37:41 --> Language Class Initialized
DEBUG - 2016-03-11 17:37:41 --> Loader Class Initialized
DEBUG - 2016-03-11 17:37:41 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:37:41 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:37:41 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:37:41 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:37:42 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:37:43 --> Session Class Initialized
DEBUG - 2016-03-11 17:37:43 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:37:43 --> Session routines successfully run
DEBUG - 2016-03-11 17:37:43 --> Controller Class Initialized
DEBUG - 2016-03-11 17:37:43 --> Final output sent to browser
DEBUG - 2016-03-11 17:37:43 --> Total execution time: 1.1171
DEBUG - 2016-03-11 17:37:57 --> Config Class Initialized
DEBUG - 2016-03-11 17:37:57 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:37:57 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:37:57 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:37:57 --> URI Class Initialized
DEBUG - 2016-03-11 17:37:57 --> Router Class Initialized
DEBUG - 2016-03-11 17:37:57 --> Output Class Initialized
DEBUG - 2016-03-11 17:37:57 --> Security Class Initialized
DEBUG - 2016-03-11 17:37:57 --> Input Class Initialized
DEBUG - 2016-03-11 17:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:37:57 --> Language Class Initialized
DEBUG - 2016-03-11 17:37:58 --> Loader Class Initialized
DEBUG - 2016-03-11 17:37:58 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:37:58 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:37:58 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:37:58 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:37:58 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:37:59 --> Session Class Initialized
DEBUG - 2016-03-11 17:37:59 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:37:59 --> A session cookie was not found.
DEBUG - 2016-03-11 17:37:59 --> Session routines successfully run
DEBUG - 2016-03-11 17:37:59 --> Controller Class Initialized
DEBUG - 2016-03-11 17:37:59 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:37:59 --> Model Class Initialized
DEBUG - 2016-03-11 17:37:59 --> Model Class Initialized
DEBUG - 2016-03-11 17:37:59 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 17:37:59 --> Final output sent to browser
DEBUG - 2016-03-11 17:37:59 --> Total execution time: 1.1891
DEBUG - 2016-03-11 17:37:59 --> Config Class Initialized
DEBUG - 2016-03-11 17:37:59 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:37:59 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:37:59 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:37:59 --> URI Class Initialized
DEBUG - 2016-03-11 17:37:59 --> Router Class Initialized
DEBUG - 2016-03-11 17:37:59 --> Output Class Initialized
DEBUG - 2016-03-11 17:37:59 --> Security Class Initialized
DEBUG - 2016-03-11 17:37:59 --> Input Class Initialized
DEBUG - 2016-03-11 17:37:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:37:59 --> Language Class Initialized
DEBUG - 2016-03-11 17:38:00 --> Loader Class Initialized
DEBUG - 2016-03-11 17:38:00 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:38:00 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:38:00 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:38:00 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:38:00 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:38:01 --> Session Class Initialized
DEBUG - 2016-03-11 17:38:01 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:38:01 --> Session routines successfully run
DEBUG - 2016-03-11 17:38:01 --> Controller Class Initialized
DEBUG - 2016-03-11 17:38:01 --> Final output sent to browser
DEBUG - 2016-03-11 17:38:01 --> Total execution time: 1.1961
DEBUG - 2016-03-11 17:38:10 --> Config Class Initialized
DEBUG - 2016-03-11 17:38:10 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:38:10 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:38:10 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:38:10 --> URI Class Initialized
DEBUG - 2016-03-11 17:38:10 --> Router Class Initialized
DEBUG - 2016-03-11 17:38:10 --> Output Class Initialized
DEBUG - 2016-03-11 17:38:10 --> Security Class Initialized
DEBUG - 2016-03-11 17:38:10 --> Input Class Initialized
DEBUG - 2016-03-11 17:38:10 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:38:10 --> Language Class Initialized
DEBUG - 2016-03-11 17:38:10 --> Loader Class Initialized
DEBUG - 2016-03-11 17:38:10 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:38:10 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:38:10 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:38:10 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:38:10 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:38:12 --> Session Class Initialized
DEBUG - 2016-03-11 17:38:12 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:38:12 --> Session routines successfully run
DEBUG - 2016-03-11 17:38:12 --> Controller Class Initialized
DEBUG - 2016-03-11 17:38:12 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:38:12 --> Model Class Initialized
DEBUG - 2016-03-11 17:38:12 --> Model Class Initialized
DEBUG - 2016-03-11 17:38:12 --> Upload Class Initialized
DEBUG - 2016-03-11 17:38:12 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:38:12 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:38:12 --> Final output sent to browser
DEBUG - 2016-03-11 17:38:12 --> Total execution time: 1.1491
DEBUG - 2016-03-11 17:41:21 --> Config Class Initialized
DEBUG - 2016-03-11 17:41:21 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:41:21 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:41:21 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:41:21 --> URI Class Initialized
DEBUG - 2016-03-11 17:41:21 --> Router Class Initialized
DEBUG - 2016-03-11 17:41:21 --> Output Class Initialized
DEBUG - 2016-03-11 17:41:21 --> Security Class Initialized
DEBUG - 2016-03-11 17:41:21 --> Input Class Initialized
DEBUG - 2016-03-11 17:41:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:41:21 --> Language Class Initialized
DEBUG - 2016-03-11 17:41:21 --> Loader Class Initialized
DEBUG - 2016-03-11 17:41:21 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:41:21 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:41:21 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:41:21 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:41:21 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:41:22 --> Session Class Initialized
DEBUG - 2016-03-11 17:41:22 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:41:22 --> Session routines successfully run
DEBUG - 2016-03-11 17:41:22 --> Controller Class Initialized
DEBUG - 2016-03-11 17:41:22 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:41:22 --> Model Class Initialized
DEBUG - 2016-03-11 17:41:22 --> Model Class Initialized
DEBUG - 2016-03-11 17:41:22 --> Upload Class Initialized
DEBUG - 2016-03-11 17:41:22 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:41:22 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:41:22 --> Final output sent to browser
DEBUG - 2016-03-11 17:41:22 --> Total execution time: 1.1351
DEBUG - 2016-03-11 17:43:06 --> Config Class Initialized
DEBUG - 2016-03-11 17:43:06 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:43:06 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:43:06 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:43:06 --> URI Class Initialized
DEBUG - 2016-03-11 17:43:06 --> Router Class Initialized
DEBUG - 2016-03-11 17:43:06 --> Output Class Initialized
DEBUG - 2016-03-11 17:43:06 --> Security Class Initialized
DEBUG - 2016-03-11 17:43:06 --> Input Class Initialized
DEBUG - 2016-03-11 17:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:43:06 --> Language Class Initialized
DEBUG - 2016-03-11 17:43:06 --> Loader Class Initialized
DEBUG - 2016-03-11 17:43:06 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:43:06 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:43:06 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:43:06 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:43:06 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:43:07 --> Session Class Initialized
DEBUG - 2016-03-11 17:43:07 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:43:07 --> A session cookie was not found.
DEBUG - 2016-03-11 17:43:07 --> Session routines successfully run
DEBUG - 2016-03-11 17:43:07 --> Controller Class Initialized
DEBUG - 2016-03-11 17:43:07 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:43:07 --> Model Class Initialized
DEBUG - 2016-03-11 17:43:07 --> Model Class Initialized
DEBUG - 2016-03-11 17:43:08 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-11 17:43:08 --> Final output sent to browser
DEBUG - 2016-03-11 17:43:08 --> Total execution time: 1.2441
DEBUG - 2016-03-11 17:43:09 --> Config Class Initialized
DEBUG - 2016-03-11 17:43:09 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:43:09 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:43:09 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:43:09 --> URI Class Initialized
DEBUG - 2016-03-11 17:43:09 --> Router Class Initialized
DEBUG - 2016-03-11 17:43:09 --> Output Class Initialized
DEBUG - 2016-03-11 17:43:09 --> Security Class Initialized
DEBUG - 2016-03-11 17:43:09 --> Input Class Initialized
DEBUG - 2016-03-11 17:43:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:43:09 --> Language Class Initialized
DEBUG - 2016-03-11 17:43:09 --> Loader Class Initialized
DEBUG - 2016-03-11 17:43:09 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:43:09 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:43:09 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:43:09 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:43:09 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:43:10 --> Session Class Initialized
DEBUG - 2016-03-11 17:43:10 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:43:10 --> Session routines successfully run
DEBUG - 2016-03-11 17:43:10 --> Controller Class Initialized
DEBUG - 2016-03-11 17:43:10 --> Final output sent to browser
DEBUG - 2016-03-11 17:43:10 --> Total execution time: 1.1241
DEBUG - 2016-03-11 17:43:13 --> Config Class Initialized
DEBUG - 2016-03-11 17:43:13 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:43:13 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:43:13 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:43:13 --> URI Class Initialized
DEBUG - 2016-03-11 17:43:13 --> Router Class Initialized
DEBUG - 2016-03-11 17:43:13 --> Output Class Initialized
DEBUG - 2016-03-11 17:43:13 --> Security Class Initialized
DEBUG - 2016-03-11 17:43:13 --> Input Class Initialized
DEBUG - 2016-03-11 17:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:43:13 --> Language Class Initialized
DEBUG - 2016-03-11 17:43:13 --> Loader Class Initialized
DEBUG - 2016-03-11 17:43:13 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:43:13 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:43:13 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:43:13 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:43:13 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:43:14 --> Session Class Initialized
DEBUG - 2016-03-11 17:43:14 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:43:14 --> Session routines successfully run
DEBUG - 2016-03-11 17:43:14 --> Controller Class Initialized
DEBUG - 2016-03-11 17:43:14 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:43:14 --> Model Class Initialized
DEBUG - 2016-03-11 17:43:14 --> Model Class Initialized
DEBUG - 2016-03-11 17:43:14 --> Upload Class Initialized
DEBUG - 2016-03-11 17:43:14 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:43:14 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:43:14 --> Final output sent to browser
DEBUG - 2016-03-11 17:43:14 --> Total execution time: 1.1311
DEBUG - 2016-03-11 17:43:22 --> Config Class Initialized
DEBUG - 2016-03-11 17:43:22 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:43:22 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:43:22 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:43:22 --> URI Class Initialized
DEBUG - 2016-03-11 17:43:22 --> Router Class Initialized
DEBUG - 2016-03-11 17:43:22 --> Output Class Initialized
DEBUG - 2016-03-11 17:43:22 --> Security Class Initialized
DEBUG - 2016-03-11 17:43:22 --> Input Class Initialized
DEBUG - 2016-03-11 17:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:43:22 --> Language Class Initialized
DEBUG - 2016-03-11 17:43:22 --> Loader Class Initialized
DEBUG - 2016-03-11 17:43:22 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:43:22 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:43:22 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:43:22 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:43:22 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:43:23 --> Session Class Initialized
DEBUG - 2016-03-11 17:43:23 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:43:23 --> Session routines successfully run
DEBUG - 2016-03-11 17:43:23 --> Controller Class Initialized
DEBUG - 2016-03-11 17:43:23 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:43:23 --> Model Class Initialized
DEBUG - 2016-03-11 17:43:23 --> Model Class Initialized
DEBUG - 2016-03-11 17:43:23 --> Upload Class Initialized
DEBUG - 2016-03-11 17:43:23 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:43:23 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:43:23 --> Final output sent to browser
DEBUG - 2016-03-11 17:43:23 --> Total execution time: 1.1611
DEBUG - 2016-03-11 17:46:33 --> Config Class Initialized
DEBUG - 2016-03-11 17:46:33 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:46:33 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:46:33 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:46:33 --> URI Class Initialized
DEBUG - 2016-03-11 17:46:33 --> Router Class Initialized
DEBUG - 2016-03-11 17:46:33 --> Output Class Initialized
DEBUG - 2016-03-11 17:46:33 --> Security Class Initialized
DEBUG - 2016-03-11 17:46:33 --> Input Class Initialized
DEBUG - 2016-03-11 17:46:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:46:33 --> Language Class Initialized
DEBUG - 2016-03-11 17:46:33 --> Loader Class Initialized
DEBUG - 2016-03-11 17:46:33 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:46:33 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:46:33 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:46:33 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:46:33 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:46:34 --> Session Class Initialized
DEBUG - 2016-03-11 17:46:34 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:46:34 --> Session routines successfully run
DEBUG - 2016-03-11 17:46:34 --> Controller Class Initialized
DEBUG - 2016-03-11 17:46:34 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:46:34 --> Model Class Initialized
DEBUG - 2016-03-11 17:46:34 --> Model Class Initialized
DEBUG - 2016-03-11 17:46:34 --> Upload Class Initialized
DEBUG - 2016-03-11 17:46:34 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:46:34 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:46:34 --> Final output sent to browser
DEBUG - 2016-03-11 17:46:34 --> Total execution time: 1.1261
DEBUG - 2016-03-11 17:47:19 --> Config Class Initialized
DEBUG - 2016-03-11 17:47:19 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:47:19 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:47:19 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:47:19 --> URI Class Initialized
DEBUG - 2016-03-11 17:47:19 --> Router Class Initialized
DEBUG - 2016-03-11 17:47:19 --> Output Class Initialized
DEBUG - 2016-03-11 17:47:19 --> Security Class Initialized
DEBUG - 2016-03-11 17:47:19 --> Input Class Initialized
DEBUG - 2016-03-11 17:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:47:19 --> Language Class Initialized
DEBUG - 2016-03-11 17:47:19 --> Loader Class Initialized
DEBUG - 2016-03-11 17:47:19 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:47:19 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:47:19 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:47:19 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:47:19 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:47:20 --> Session Class Initialized
DEBUG - 2016-03-11 17:47:20 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:47:20 --> Session routines successfully run
DEBUG - 2016-03-11 17:47:20 --> Controller Class Initialized
DEBUG - 2016-03-11 17:47:20 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:47:20 --> Model Class Initialized
DEBUG - 2016-03-11 17:47:20 --> Model Class Initialized
ERROR - 2016-03-11 17:47:20 --> Severity: Notice  --> Undefined variable: upload_config D:\xampp\htdocs\superacao\_cmp\application\controllers\campanha.php 12
ERROR - 2016-03-11 17:47:20 --> Severity: Notice  --> Undefined variable: upload_path D:\xampp\htdocs\superacao\_cmp\application\controllers\campanha.php 12
DEBUG - 2016-03-11 17:48:03 --> Config Class Initialized
DEBUG - 2016-03-11 17:48:03 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:48:03 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:48:03 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:48:03 --> URI Class Initialized
DEBUG - 2016-03-11 17:48:03 --> Router Class Initialized
DEBUG - 2016-03-11 17:48:03 --> Output Class Initialized
DEBUG - 2016-03-11 17:48:03 --> Security Class Initialized
DEBUG - 2016-03-11 17:48:03 --> Input Class Initialized
DEBUG - 2016-03-11 17:48:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:48:03 --> Language Class Initialized
DEBUG - 2016-03-11 17:48:03 --> Loader Class Initialized
DEBUG - 2016-03-11 17:48:03 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:48:03 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:48:03 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:48:03 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:48:03 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:48:04 --> Session Class Initialized
DEBUG - 2016-03-11 17:48:04 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:48:04 --> Session routines successfully run
DEBUG - 2016-03-11 17:48:04 --> Controller Class Initialized
DEBUG - 2016-03-11 17:48:04 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:48:05 --> Model Class Initialized
DEBUG - 2016-03-11 17:48:05 --> Model Class Initialized
ERROR - 2016-03-11 17:48:05 --> Severity: Notice  --> Undefined variable: upload_config D:\xampp\htdocs\superacao\_cmp\application\controllers\campanha.php 12
DEBUG - 2016-03-11 17:48:33 --> Config Class Initialized
DEBUG - 2016-03-11 17:48:33 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:48:33 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:48:33 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:48:33 --> URI Class Initialized
DEBUG - 2016-03-11 17:48:33 --> Router Class Initialized
DEBUG - 2016-03-11 17:48:33 --> Output Class Initialized
DEBUG - 2016-03-11 17:48:33 --> Security Class Initialized
DEBUG - 2016-03-11 17:48:33 --> Input Class Initialized
DEBUG - 2016-03-11 17:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:48:33 --> Language Class Initialized
DEBUG - 2016-03-11 17:48:33 --> Loader Class Initialized
DEBUG - 2016-03-11 17:48:33 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:48:33 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:48:33 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:48:33 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:48:33 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:48:34 --> Session Class Initialized
DEBUG - 2016-03-11 17:48:34 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:48:34 --> Session routines successfully run
DEBUG - 2016-03-11 17:48:34 --> Controller Class Initialized
DEBUG - 2016-03-11 17:48:34 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:48:34 --> Model Class Initialized
DEBUG - 2016-03-11 17:48:34 --> Model Class Initialized
ERROR - 2016-03-11 17:48:34 --> Severity: Notice  --> Undefined variable: upload_config D:\xampp\htdocs\superacao\_cmp\application\controllers\campanha.php 12
DEBUG - 2016-03-11 17:49:40 --> Config Class Initialized
DEBUG - 2016-03-11 17:49:40 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:49:40 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:49:40 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:49:40 --> URI Class Initialized
DEBUG - 2016-03-11 17:49:40 --> Router Class Initialized
DEBUG - 2016-03-11 17:49:40 --> Output Class Initialized
DEBUG - 2016-03-11 17:49:40 --> Security Class Initialized
DEBUG - 2016-03-11 17:49:40 --> Input Class Initialized
DEBUG - 2016-03-11 17:49:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:49:40 --> Language Class Initialized
DEBUG - 2016-03-11 17:49:40 --> Loader Class Initialized
DEBUG - 2016-03-11 17:49:40 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:49:40 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:49:40 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:49:40 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:49:40 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:49:41 --> Session Class Initialized
DEBUG - 2016-03-11 17:49:41 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:49:41 --> Session routines successfully run
DEBUG - 2016-03-11 17:49:41 --> Controller Class Initialized
DEBUG - 2016-03-11 17:49:41 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:49:41 --> Model Class Initialized
DEBUG - 2016-03-11 17:49:41 --> Model Class Initialized
DEBUG - 2016-03-11 17:49:41 --> Upload Class Initialized
DEBUG - 2016-03-11 17:49:41 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:49:41 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:49:41 --> Final output sent to browser
DEBUG - 2016-03-11 17:49:41 --> Total execution time: 1.1621
DEBUG - 2016-03-11 17:51:06 --> Config Class Initialized
DEBUG - 2016-03-11 17:51:06 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:51:06 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:51:06 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:51:06 --> URI Class Initialized
DEBUG - 2016-03-11 17:51:06 --> Router Class Initialized
DEBUG - 2016-03-11 17:51:06 --> Output Class Initialized
DEBUG - 2016-03-11 17:51:06 --> Security Class Initialized
DEBUG - 2016-03-11 17:51:06 --> Input Class Initialized
DEBUG - 2016-03-11 17:51:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:51:06 --> Language Class Initialized
DEBUG - 2016-03-11 17:51:06 --> Loader Class Initialized
DEBUG - 2016-03-11 17:51:06 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:51:06 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:51:06 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:51:06 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:51:06 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:51:07 --> Session Class Initialized
DEBUG - 2016-03-11 17:51:07 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:51:07 --> Session routines successfully run
DEBUG - 2016-03-11 17:51:07 --> Controller Class Initialized
DEBUG - 2016-03-11 17:51:07 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:51:07 --> Model Class Initialized
DEBUG - 2016-03-11 17:51:08 --> Model Class Initialized
DEBUG - 2016-03-11 17:51:08 --> Upload Class Initialized
DEBUG - 2016-03-11 17:51:08 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:51:08 --> O caminho de envio parece ser inválido.
DEBUG - 2016-03-11 17:51:08 --> Final output sent to browser
DEBUG - 2016-03-11 17:51:08 --> Total execution time: 1.1281
DEBUG - 2016-03-11 17:51:35 --> Config Class Initialized
DEBUG - 2016-03-11 17:51:35 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:51:35 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:51:35 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:51:35 --> URI Class Initialized
DEBUG - 2016-03-11 17:51:35 --> Router Class Initialized
DEBUG - 2016-03-11 17:51:35 --> Output Class Initialized
DEBUG - 2016-03-11 17:51:35 --> Security Class Initialized
DEBUG - 2016-03-11 17:51:35 --> Input Class Initialized
DEBUG - 2016-03-11 17:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:51:35 --> Language Class Initialized
DEBUG - 2016-03-11 17:51:35 --> Loader Class Initialized
DEBUG - 2016-03-11 17:51:35 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:51:35 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:51:35 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:51:35 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:51:35 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:51:36 --> Session Class Initialized
DEBUG - 2016-03-11 17:51:36 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:51:36 --> Session routines successfully run
DEBUG - 2016-03-11 17:51:36 --> Controller Class Initialized
DEBUG - 2016-03-11 17:51:36 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:51:36 --> Model Class Initialized
DEBUG - 2016-03-11 17:51:36 --> Model Class Initialized
DEBUG - 2016-03-11 17:51:36 --> Upload Class Initialized
DEBUG - 2016-03-11 17:51:36 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:51:36 --> Nenhum arquivo foi selecionado para envio.
DEBUG - 2016-03-11 17:51:36 --> Final output sent to browser
DEBUG - 2016-03-11 17:51:36 --> Total execution time: 1.1611
DEBUG - 2016-03-11 17:51:53 --> Config Class Initialized
DEBUG - 2016-03-11 17:51:53 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:51:53 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:51:53 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:51:53 --> URI Class Initialized
DEBUG - 2016-03-11 17:51:53 --> Router Class Initialized
DEBUG - 2016-03-11 17:51:53 --> Output Class Initialized
DEBUG - 2016-03-11 17:51:53 --> Security Class Initialized
DEBUG - 2016-03-11 17:51:53 --> Input Class Initialized
DEBUG - 2016-03-11 17:51:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:51:53 --> Language Class Initialized
DEBUG - 2016-03-11 17:51:53 --> Loader Class Initialized
DEBUG - 2016-03-11 17:51:53 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:51:53 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:51:53 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:51:53 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:51:53 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:51:54 --> Session Class Initialized
DEBUG - 2016-03-11 17:51:54 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:51:54 --> Session routines successfully run
DEBUG - 2016-03-11 17:51:54 --> Controller Class Initialized
DEBUG - 2016-03-11 17:51:54 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:51:54 --> Model Class Initialized
DEBUG - 2016-03-11 17:51:54 --> Model Class Initialized
DEBUG - 2016-03-11 17:51:54 --> Upload Class Initialized
ERROR - 2016-03-11 17:51:54 --> Severity: Notice  --> Undefined variable: upload_exact_dimension D:\xampp\htdocs\superacao\_cmp\application\controllers\campanha.php 269
ERROR - 2016-03-11 17:51:54 --> Severity: Notice  --> Undefined variable: upload_exact_dimension D:\xampp\htdocs\superacao\_cmp\application\controllers\campanha.php 273
ERROR - 2016-03-11 17:51:54 --> Severity: Notice  --> Undefined variable: upload_exact_dimension D:\xampp\htdocs\superacao\_cmp\application\controllers\campanha.php 273
DEBUG - 2016-03-11 17:51:54 --> Final output sent to browser
DEBUG - 2016-03-11 17:51:54 --> Total execution time: 1.2371
DEBUG - 2016-03-11 17:56:48 --> Config Class Initialized
DEBUG - 2016-03-11 17:56:48 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:56:48 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:56:48 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:56:48 --> URI Class Initialized
DEBUG - 2016-03-11 17:56:48 --> Router Class Initialized
DEBUG - 2016-03-11 17:56:48 --> Output Class Initialized
DEBUG - 2016-03-11 17:56:48 --> Security Class Initialized
DEBUG - 2016-03-11 17:56:48 --> Input Class Initialized
DEBUG - 2016-03-11 17:56:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:56:48 --> Language Class Initialized
DEBUG - 2016-03-11 17:57:20 --> Config Class Initialized
DEBUG - 2016-03-11 17:57:20 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:57:20 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:57:20 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:57:20 --> URI Class Initialized
DEBUG - 2016-03-11 17:57:20 --> Router Class Initialized
DEBUG - 2016-03-11 17:57:20 --> Output Class Initialized
DEBUG - 2016-03-11 17:57:20 --> Security Class Initialized
DEBUG - 2016-03-11 17:57:20 --> Input Class Initialized
DEBUG - 2016-03-11 17:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:57:20 --> Language Class Initialized
DEBUG - 2016-03-11 17:57:40 --> Config Class Initialized
DEBUG - 2016-03-11 17:57:40 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:57:40 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:57:40 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:57:40 --> URI Class Initialized
DEBUG - 2016-03-11 17:57:40 --> Router Class Initialized
DEBUG - 2016-03-11 17:57:40 --> Output Class Initialized
DEBUG - 2016-03-11 17:57:40 --> Security Class Initialized
DEBUG - 2016-03-11 17:57:40 --> Input Class Initialized
DEBUG - 2016-03-11 17:57:40 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:57:40 --> Language Class Initialized
DEBUG - 2016-03-11 17:57:40 --> Loader Class Initialized
DEBUG - 2016-03-11 17:57:40 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:57:40 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:57:40 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:57:40 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:57:40 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:57:41 --> Session Class Initialized
DEBUG - 2016-03-11 17:57:41 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:57:41 --> Session routines successfully run
DEBUG - 2016-03-11 17:57:41 --> Controller Class Initialized
DEBUG - 2016-03-11 17:57:41 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:57:41 --> Model Class Initialized
DEBUG - 2016-03-11 17:57:41 --> Model Class Initialized
ERROR - 2016-03-11 17:57:41 --> Severity: Warning  --> Creating default object from empty value D:\xampp\htdocs\superacao\_cmp\application\controllers\campanha.php 18
DEBUG - 2016-03-11 17:57:41 --> Upload Class Initialized
DEBUG - 2016-03-11 17:57:41 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:57:41 --> Nenhum arquivo foi selecionado para envio.
DEBUG - 2016-03-11 17:57:41 --> Final output sent to browser
DEBUG - 2016-03-11 17:57:41 --> Total execution time: 1.1531
DEBUG - 2016-03-11 17:58:01 --> Config Class Initialized
DEBUG - 2016-03-11 17:58:01 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:58:01 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:58:01 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:58:01 --> URI Class Initialized
DEBUG - 2016-03-11 17:58:01 --> Router Class Initialized
DEBUG - 2016-03-11 17:58:01 --> Output Class Initialized
DEBUG - 2016-03-11 17:58:01 --> Security Class Initialized
DEBUG - 2016-03-11 17:58:01 --> Input Class Initialized
DEBUG - 2016-03-11 17:58:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:58:01 --> Language Class Initialized
DEBUG - 2016-03-11 17:58:01 --> Loader Class Initialized
DEBUG - 2016-03-11 17:58:01 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:58:01 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:58:01 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:58:01 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:58:01 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:58:02 --> Session Class Initialized
DEBUG - 2016-03-11 17:58:02 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:58:02 --> Session routines successfully run
DEBUG - 2016-03-11 17:58:02 --> Controller Class Initialized
DEBUG - 2016-03-11 17:58:02 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-03-11 17:58:02 --> Model Class Initialized
DEBUG - 2016-03-11 17:58:02 --> Upload Class Initialized
DEBUG - 2016-03-11 17:58:02 --> Language file loaded: language/pt-br/upload_lang.php
ERROR - 2016-03-11 17:58:02 --> Nenhum arquivo foi selecionado para envio.
DEBUG - 2016-03-11 17:58:02 --> Final output sent to browser
DEBUG - 2016-03-11 17:58:02 --> Total execution time: 1.1211
DEBUG - 2016-03-11 17:58:09 --> Config Class Initialized
DEBUG - 2016-03-11 17:58:09 --> Hooks Class Initialized
DEBUG - 2016-03-11 17:58:09 --> Utf8 Class Initialized
DEBUG - 2016-03-11 17:58:09 --> UTF-8 Support Enabled
DEBUG - 2016-03-11 17:58:09 --> URI Class Initialized
DEBUG - 2016-03-11 17:58:09 --> Router Class Initialized
DEBUG - 2016-03-11 17:58:09 --> Output Class Initialized
DEBUG - 2016-03-11 17:58:09 --> Security Class Initialized
DEBUG - 2016-03-11 17:58:09 --> Input Class Initialized
DEBUG - 2016-03-11 17:58:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-11 17:58:09 --> Language Class Initialized
DEBUG - 2016-03-11 17:58:09 --> Loader Class Initialized
DEBUG - 2016-03-11 17:58:09 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-11 17:58:09 --> Helper loaded: url_helper
DEBUG - 2016-03-11 17:58:09 --> Helper loaded: image_helper
DEBUG - 2016-03-11 17:58:09 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-11 17:58:09 --> Database Driver Class Initialized
DEBUG - 2016-03-11 17:58:10 --> Session Class Initialized
DEBUG - 2016-03-11 17:58:10 --> Helper loaded: string_helper
DEBUG - 2016-03-11 17:58:10 --> Session routines successfully run
DEBUG - 2016-03-11 17:58:10 --> Controller Class Initialized
DEBUG - 2016-03-11 17:58:10 --> Helper loaded: super_url_helper
DEBUG - 2016-03-11 17:58:10 --> Model Class Initialized
DEBUG - 2016-03-11 17:58:10 --> Model Class Initialized
DEBUG - 2016-03-11 17:58:10 --> Upload Class Initialized
DEBUG - 2016-03-11 17:58:10 --> Final output sent to browser
DEBUG - 2016-03-11 17:58:10 --> Total execution time: 1.1641
