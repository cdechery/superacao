<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-03-14 13:13:57 --> Config Class Initialized
DEBUG - 2016-03-14 13:13:57 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:13:57 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:13:57 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:13:57 --> URI Class Initialized
DEBUG - 2016-03-14 13:13:57 --> Router Class Initialized
DEBUG - 2016-03-14 13:13:57 --> Output Class Initialized
DEBUG - 2016-03-14 13:13:57 --> Security Class Initialized
DEBUG - 2016-03-14 13:13:57 --> Input Class Initialized
DEBUG - 2016-03-14 13:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:13:57 --> Language Class Initialized
DEBUG - 2016-03-14 13:13:57 --> Loader Class Initialized
DEBUG - 2016-03-14 13:13:57 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:13:57 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:13:57 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:13:58 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:13:58 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:13:59 --> Session Class Initialized
DEBUG - 2016-03-14 13:13:59 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:13:59 --> A session cookie was not found.
DEBUG - 2016-03-14 13:13:59 --> Session routines successfully run
DEBUG - 2016-03-14 13:13:59 --> Controller Class Initialized
DEBUG - 2016-03-14 13:13:59 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 13:13:59 --> Model Class Initialized
DEBUG - 2016-03-14 13:13:59 --> Model Class Initialized
DEBUG - 2016-03-14 13:13:59 --> File loaded: application/views/campanhas_listar.php
DEBUG - 2016-03-14 13:13:59 --> Final output sent to browser
DEBUG - 2016-03-14 13:13:59 --> Total execution time: 1.2480
DEBUG - 2016-03-14 13:13:59 --> Config Class Initialized
DEBUG - 2016-03-14 13:13:59 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:13:59 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:13:59 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:13:59 --> URI Class Initialized
DEBUG - 2016-03-14 13:13:59 --> Router Class Initialized
DEBUG - 2016-03-14 13:13:59 --> Output Class Initialized
DEBUG - 2016-03-14 13:13:59 --> Security Class Initialized
DEBUG - 2016-03-14 13:13:59 --> Input Class Initialized
DEBUG - 2016-03-14 13:13:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:13:59 --> Language Class Initialized
DEBUG - 2016-03-14 13:13:59 --> Loader Class Initialized
DEBUG - 2016-03-14 13:13:59 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:13:59 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:13:59 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:13:59 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:13:59 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:14:00 --> Session Class Initialized
DEBUG - 2016-03-14 13:14:00 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:14:00 --> A session cookie was not found.
DEBUG - 2016-03-14 13:14:00 --> Session routines successfully run
DEBUG - 2016-03-14 13:14:00 --> Controller Class Initialized
DEBUG - 2016-03-14 13:14:00 --> Final output sent to browser
DEBUG - 2016-03-14 13:14:00 --> Total execution time: 1.1570
DEBUG - 2016-03-14 13:14:04 --> Config Class Initialized
DEBUG - 2016-03-14 13:14:04 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:14:04 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:14:04 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:14:04 --> URI Class Initialized
DEBUG - 2016-03-14 13:14:04 --> Router Class Initialized
DEBUG - 2016-03-14 13:14:04 --> Output Class Initialized
DEBUG - 2016-03-14 13:14:04 --> Security Class Initialized
DEBUG - 2016-03-14 13:14:04 --> Input Class Initialized
DEBUG - 2016-03-14 13:14:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:14:04 --> Language Class Initialized
DEBUG - 2016-03-14 13:14:04 --> Loader Class Initialized
DEBUG - 2016-03-14 13:14:04 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:14:04 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:14:04 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:14:04 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:14:04 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:14:05 --> Session Class Initialized
DEBUG - 2016-03-14 13:14:05 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:14:05 --> A session cookie was not found.
DEBUG - 2016-03-14 13:14:05 --> Session routines successfully run
DEBUG - 2016-03-14 13:14:05 --> Controller Class Initialized
DEBUG - 2016-03-14 13:14:05 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 13:14:05 --> Model Class Initialized
DEBUG - 2016-03-14 13:14:05 --> Model Class Initialized
DEBUG - 2016-03-14 13:14:05 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-14 13:14:05 --> Final output sent to browser
DEBUG - 2016-03-14 13:14:05 --> Total execution time: 1.1420
DEBUG - 2016-03-14 13:14:06 --> Config Class Initialized
DEBUG - 2016-03-14 13:14:06 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:14:06 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:14:06 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:14:06 --> URI Class Initialized
DEBUG - 2016-03-14 13:14:06 --> Router Class Initialized
DEBUG - 2016-03-14 13:14:06 --> Output Class Initialized
DEBUG - 2016-03-14 13:14:06 --> Security Class Initialized
DEBUG - 2016-03-14 13:14:06 --> Input Class Initialized
DEBUG - 2016-03-14 13:14:06 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:14:06 --> Language Class Initialized
DEBUG - 2016-03-14 13:14:06 --> Loader Class Initialized
DEBUG - 2016-03-14 13:14:06 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:14:06 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:14:06 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:14:06 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:14:06 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:14:07 --> Session Class Initialized
DEBUG - 2016-03-14 13:14:07 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:14:07 --> Session routines successfully run
DEBUG - 2016-03-14 13:14:07 --> Controller Class Initialized
DEBUG - 2016-03-14 13:14:07 --> Final output sent to browser
DEBUG - 2016-03-14 13:14:07 --> Total execution time: 1.1830
DEBUG - 2016-03-14 13:15:12 --> Config Class Initialized
DEBUG - 2016-03-14 13:15:12 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:15:12 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:15:12 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:15:12 --> URI Class Initialized
DEBUG - 2016-03-14 13:15:12 --> Router Class Initialized
DEBUG - 2016-03-14 13:15:12 --> Output Class Initialized
DEBUG - 2016-03-14 13:15:12 --> Security Class Initialized
DEBUG - 2016-03-14 13:15:12 --> Input Class Initialized
DEBUG - 2016-03-14 13:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:15:12 --> Language Class Initialized
DEBUG - 2016-03-14 13:15:12 --> Loader Class Initialized
DEBUG - 2016-03-14 13:15:12 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:15:12 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:15:12 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:15:12 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:15:12 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:15:13 --> Session Class Initialized
DEBUG - 2016-03-14 13:15:13 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:15:13 --> Session routines successfully run
DEBUG - 2016-03-14 13:15:13 --> Controller Class Initialized
DEBUG - 2016-03-14 13:15:13 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 13:15:13 --> Model Class Initialized
DEBUG - 2016-03-14 13:15:13 --> Model Class Initialized
DEBUG - 2016-03-14 13:15:13 --> Helper loaded: form_helper
DEBUG - 2016-03-14 13:15:13 --> Form Validation Class Initialized
DEBUG - 2016-03-14 13:15:13 --> XSS Filtering completed
DEBUG - 2016-03-14 13:15:13 --> XSS Filtering completed
DEBUG - 2016-03-14 13:15:13 --> XSS Filtering completed
DEBUG - 2016-03-14 13:15:13 --> XSS Filtering completed
DEBUG - 2016-03-14 13:15:13 --> XSS Filtering completed
DEBUG - 2016-03-14 13:15:13 --> XSS Filtering completed
DEBUG - 2016-03-14 13:15:13 --> XSS Filtering completed
DEBUG - 2016-03-14 13:15:13 --> XSS Filtering completed
DEBUG - 2016-03-14 13:15:13 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-14 13:15:13 --> Final output sent to browser
DEBUG - 2016-03-14 13:15:13 --> Total execution time: 1.3636
DEBUG - 2016-03-14 13:15:14 --> Config Class Initialized
DEBUG - 2016-03-14 13:15:14 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:15:14 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:15:14 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:15:14 --> URI Class Initialized
DEBUG - 2016-03-14 13:15:14 --> Router Class Initialized
DEBUG - 2016-03-14 13:15:14 --> Output Class Initialized
DEBUG - 2016-03-14 13:15:14 --> Security Class Initialized
DEBUG - 2016-03-14 13:15:14 --> Input Class Initialized
DEBUG - 2016-03-14 13:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:15:14 --> Language Class Initialized
DEBUG - 2016-03-14 13:15:14 --> Loader Class Initialized
DEBUG - 2016-03-14 13:15:14 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:15:14 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:15:14 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:15:14 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:15:14 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:15:15 --> Session Class Initialized
DEBUG - 2016-03-14 13:15:15 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:15:15 --> Session routines successfully run
DEBUG - 2016-03-14 13:15:15 --> Controller Class Initialized
DEBUG - 2016-03-14 13:15:15 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 13:15:15 --> Model Class Initialized
DEBUG - 2016-03-14 13:15:15 --> Model Class Initialized
DEBUG - 2016-03-14 13:15:15 --> Upload Class Initialized
DEBUG - 2016-03-14 13:15:15 --> Final output sent to browser
DEBUG - 2016-03-14 13:15:15 --> Total execution time: 1.2200
DEBUG - 2016-03-14 13:16:48 --> Config Class Initialized
DEBUG - 2016-03-14 13:16:48 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:16:48 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:16:48 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:16:48 --> URI Class Initialized
DEBUG - 2016-03-14 13:16:48 --> Router Class Initialized
DEBUG - 2016-03-14 13:16:48 --> Output Class Initialized
DEBUG - 2016-03-14 13:16:48 --> Security Class Initialized
DEBUG - 2016-03-14 13:16:48 --> Input Class Initialized
DEBUG - 2016-03-14 13:16:48 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:16:48 --> Language Class Initialized
DEBUG - 2016-03-14 13:16:48 --> Loader Class Initialized
DEBUG - 2016-03-14 13:16:48 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:16:48 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:16:48 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:16:48 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:16:48 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:16:49 --> Session Class Initialized
DEBUG - 2016-03-14 13:16:49 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:16:49 --> Session routines successfully run
DEBUG - 2016-03-14 13:16:49 --> Controller Class Initialized
DEBUG - 2016-03-14 13:16:49 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 13:16:49 --> Model Class Initialized
DEBUG - 2016-03-14 13:16:49 --> Model Class Initialized
DEBUG - 2016-03-14 13:16:49 --> Helper loaded: form_helper
DEBUG - 2016-03-14 13:16:49 --> Form Validation Class Initialized
DEBUG - 2016-03-14 13:16:49 --> XSS Filtering completed
DEBUG - 2016-03-14 13:16:49 --> XSS Filtering completed
DEBUG - 2016-03-14 13:16:49 --> XSS Filtering completed
DEBUG - 2016-03-14 13:16:49 --> XSS Filtering completed
DEBUG - 2016-03-14 13:16:49 --> XSS Filtering completed
DEBUG - 2016-03-14 13:16:49 --> XSS Filtering completed
DEBUG - 2016-03-14 13:16:49 --> XSS Filtering completed
DEBUG - 2016-03-14 13:16:49 --> XSS Filtering completed
DEBUG - 2016-03-14 13:16:49 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-14 13:16:49 --> Final output sent to browser
DEBUG - 2016-03-14 13:16:49 --> Total execution time: 1.3714
DEBUG - 2016-03-14 13:16:49 --> Config Class Initialized
DEBUG - 2016-03-14 13:16:49 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:16:49 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:16:49 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:16:49 --> URI Class Initialized
DEBUG - 2016-03-14 13:16:49 --> Router Class Initialized
DEBUG - 2016-03-14 13:16:49 --> Output Class Initialized
DEBUG - 2016-03-14 13:16:49 --> Security Class Initialized
DEBUG - 2016-03-14 13:16:49 --> Input Class Initialized
DEBUG - 2016-03-14 13:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:16:49 --> Language Class Initialized
DEBUG - 2016-03-14 13:16:49 --> Loader Class Initialized
DEBUG - 2016-03-14 13:16:49 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:16:49 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:16:49 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:16:49 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:16:49 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:16:50 --> Session Class Initialized
DEBUG - 2016-03-14 13:16:50 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:16:50 --> Session routines successfully run
DEBUG - 2016-03-14 13:16:50 --> Controller Class Initialized
DEBUG - 2016-03-14 13:16:50 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 13:16:50 --> Model Class Initialized
DEBUG - 2016-03-14 13:16:50 --> Model Class Initialized
DEBUG - 2016-03-14 13:16:50 --> Upload Class Initialized
DEBUG - 2016-03-14 13:16:51 --> Final output sent to browser
DEBUG - 2016-03-14 13:16:51 --> Total execution time: 2.2250
DEBUG - 2016-03-14 13:16:54 --> Config Class Initialized
DEBUG - 2016-03-14 13:16:54 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:16:54 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:16:54 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:16:55 --> URI Class Initialized
DEBUG - 2016-03-14 13:16:55 --> Router Class Initialized
DEBUG - 2016-03-14 13:16:55 --> Output Class Initialized
DEBUG - 2016-03-14 13:16:55 --> Security Class Initialized
DEBUG - 2016-03-14 13:16:55 --> Input Class Initialized
DEBUG - 2016-03-14 13:16:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:16:55 --> Language Class Initialized
DEBUG - 2016-03-14 13:16:55 --> Loader Class Initialized
DEBUG - 2016-03-14 13:16:55 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:16:55 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:16:55 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:16:55 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:16:55 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:16:56 --> Session Class Initialized
DEBUG - 2016-03-14 13:16:56 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:16:56 --> A session cookie was not found.
DEBUG - 2016-03-14 13:16:56 --> Session routines successfully run
DEBUG - 2016-03-14 13:16:56 --> Controller Class Initialized
DEBUG - 2016-03-14 13:16:56 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 13:16:56 --> Model Class Initialized
DEBUG - 2016-03-14 13:16:56 --> Model Class Initialized
DEBUG - 2016-03-14 13:16:56 --> File loaded: application/views/campanhas_listar.php
DEBUG - 2016-03-14 13:16:56 --> Final output sent to browser
DEBUG - 2016-03-14 13:16:56 --> Total execution time: 1.1170
DEBUG - 2016-03-14 13:16:56 --> Config Class Initialized
DEBUG - 2016-03-14 13:16:56 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:16:56 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:16:56 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:16:56 --> URI Class Initialized
DEBUG - 2016-03-14 13:16:56 --> Router Class Initialized
DEBUG - 2016-03-14 13:16:56 --> Output Class Initialized
DEBUG - 2016-03-14 13:16:56 --> Security Class Initialized
DEBUG - 2016-03-14 13:16:56 --> Input Class Initialized
DEBUG - 2016-03-14 13:16:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:16:56 --> Language Class Initialized
DEBUG - 2016-03-14 13:16:56 --> Loader Class Initialized
DEBUG - 2016-03-14 13:16:56 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:16:56 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:16:56 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:16:56 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:16:56 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:16:58 --> Session Class Initialized
DEBUG - 2016-03-14 13:16:58 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:16:58 --> Session routines successfully run
DEBUG - 2016-03-14 13:16:58 --> Controller Class Initialized
DEBUG - 2016-03-14 13:16:58 --> Final output sent to browser
DEBUG - 2016-03-14 13:16:58 --> Total execution time: 1.1110
DEBUG - 2016-03-14 13:17:01 --> Config Class Initialized
DEBUG - 2016-03-14 13:17:01 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:17:01 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:17:01 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:17:01 --> URI Class Initialized
DEBUG - 2016-03-14 13:17:01 --> Router Class Initialized
DEBUG - 2016-03-14 13:17:01 --> Output Class Initialized
DEBUG - 2016-03-14 13:17:01 --> Security Class Initialized
DEBUG - 2016-03-14 13:17:01 --> Input Class Initialized
DEBUG - 2016-03-14 13:17:01 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:17:01 --> Language Class Initialized
DEBUG - 2016-03-14 13:17:01 --> Loader Class Initialized
DEBUG - 2016-03-14 13:17:01 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:17:01 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:17:01 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:17:01 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:17:01 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:17:02 --> Session Class Initialized
DEBUG - 2016-03-14 13:17:02 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:17:02 --> A session cookie was not found.
DEBUG - 2016-03-14 13:17:02 --> Session routines successfully run
DEBUG - 2016-03-14 13:17:02 --> Controller Class Initialized
DEBUG - 2016-03-14 13:17:02 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 13:17:02 --> Model Class Initialized
DEBUG - 2016-03-14 13:17:02 --> Model Class Initialized
DEBUG - 2016-03-14 13:17:02 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-14 13:17:02 --> Final output sent to browser
DEBUG - 2016-03-14 13:17:02 --> Total execution time: 1.1590
DEBUG - 2016-03-14 13:17:03 --> Config Class Initialized
DEBUG - 2016-03-14 13:17:03 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:17:03 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:17:03 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:17:03 --> URI Class Initialized
DEBUG - 2016-03-14 13:17:03 --> Router Class Initialized
DEBUG - 2016-03-14 13:17:03 --> Output Class Initialized
DEBUG - 2016-03-14 13:17:03 --> Security Class Initialized
DEBUG - 2016-03-14 13:17:03 --> Input Class Initialized
DEBUG - 2016-03-14 13:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:17:03 --> Language Class Initialized
DEBUG - 2016-03-14 13:17:03 --> Loader Class Initialized
DEBUG - 2016-03-14 13:17:03 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:17:03 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:17:03 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:17:03 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:17:03 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:17:04 --> Session Class Initialized
DEBUG - 2016-03-14 13:17:04 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:17:04 --> Session routines successfully run
DEBUG - 2016-03-14 13:17:04 --> Controller Class Initialized
DEBUG - 2016-03-14 13:17:04 --> Final output sent to browser
DEBUG - 2016-03-14 13:17:04 --> Total execution time: 1.1950
DEBUG - 2016-03-14 13:19:23 --> Config Class Initialized
DEBUG - 2016-03-14 13:19:23 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:19:23 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:19:23 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:19:23 --> URI Class Initialized
DEBUG - 2016-03-14 13:19:23 --> Router Class Initialized
DEBUG - 2016-03-14 13:19:23 --> Output Class Initialized
DEBUG - 2016-03-14 13:19:23 --> Security Class Initialized
DEBUG - 2016-03-14 13:19:23 --> Input Class Initialized
DEBUG - 2016-03-14 13:19:23 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:19:23 --> Language Class Initialized
DEBUG - 2016-03-14 13:19:23 --> Loader Class Initialized
DEBUG - 2016-03-14 13:19:23 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:19:23 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:19:23 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:19:23 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:19:23 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:19:24 --> Session Class Initialized
DEBUG - 2016-03-14 13:19:24 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:19:24 --> Session routines successfully run
DEBUG - 2016-03-14 13:19:24 --> Controller Class Initialized
DEBUG - 2016-03-14 13:19:24 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 13:19:24 --> Model Class Initialized
DEBUG - 2016-03-14 13:19:24 --> Model Class Initialized
DEBUG - 2016-03-14 13:19:24 --> Helper loaded: form_helper
DEBUG - 2016-03-14 13:19:24 --> Form Validation Class Initialized
DEBUG - 2016-03-14 13:19:24 --> XSS Filtering completed
DEBUG - 2016-03-14 13:19:24 --> XSS Filtering completed
DEBUG - 2016-03-14 13:19:24 --> XSS Filtering completed
DEBUG - 2016-03-14 13:19:24 --> XSS Filtering completed
DEBUG - 2016-03-14 13:19:24 --> XSS Filtering completed
DEBUG - 2016-03-14 13:19:24 --> XSS Filtering completed
DEBUG - 2016-03-14 13:19:24 --> XSS Filtering completed
DEBUG - 2016-03-14 13:19:24 --> XSS Filtering completed
DEBUG - 2016-03-14 13:19:24 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-14 13:19:24 --> Final output sent to browser
DEBUG - 2016-03-14 13:19:24 --> Total execution time: 1.3536
DEBUG - 2016-03-14 13:19:24 --> Config Class Initialized
DEBUG - 2016-03-14 13:19:24 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:19:24 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:19:24 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:19:24 --> URI Class Initialized
DEBUG - 2016-03-14 13:19:24 --> Router Class Initialized
DEBUG - 2016-03-14 13:19:24 --> Output Class Initialized
DEBUG - 2016-03-14 13:19:24 --> Security Class Initialized
DEBUG - 2016-03-14 13:19:24 --> Input Class Initialized
DEBUG - 2016-03-14 13:19:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:19:24 --> Language Class Initialized
DEBUG - 2016-03-14 13:19:24 --> Loader Class Initialized
DEBUG - 2016-03-14 13:19:24 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:19:24 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:19:24 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:19:24 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:19:24 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:19:25 --> Session Class Initialized
DEBUG - 2016-03-14 13:19:25 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:19:25 --> Session routines successfully run
DEBUG - 2016-03-14 13:19:25 --> Controller Class Initialized
DEBUG - 2016-03-14 13:19:25 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 13:19:25 --> Model Class Initialized
DEBUG - 2016-03-14 13:19:25 --> Model Class Initialized
DEBUG - 2016-03-14 13:19:25 --> Upload Class Initialized
DEBUG - 2016-03-14 13:19:26 --> Final output sent to browser
DEBUG - 2016-03-14 13:19:26 --> Total execution time: 1.8710
DEBUG - 2016-03-14 13:19:29 --> Config Class Initialized
DEBUG - 2016-03-14 13:19:29 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:19:29 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:19:29 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:19:29 --> URI Class Initialized
DEBUG - 2016-03-14 13:19:29 --> Router Class Initialized
DEBUG - 2016-03-14 13:19:29 --> Output Class Initialized
DEBUG - 2016-03-14 13:19:29 --> Security Class Initialized
DEBUG - 2016-03-14 13:19:29 --> Input Class Initialized
DEBUG - 2016-03-14 13:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:19:29 --> Language Class Initialized
DEBUG - 2016-03-14 13:19:29 --> Loader Class Initialized
DEBUG - 2016-03-14 13:19:29 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:19:29 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:19:29 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:19:29 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:19:29 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:19:30 --> Session Class Initialized
DEBUG - 2016-03-14 13:19:30 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:19:30 --> A session cookie was not found.
DEBUG - 2016-03-14 13:19:30 --> Session routines successfully run
DEBUG - 2016-03-14 13:19:30 --> Controller Class Initialized
DEBUG - 2016-03-14 13:19:30 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 13:19:30 --> Model Class Initialized
DEBUG - 2016-03-14 13:19:30 --> Model Class Initialized
DEBUG - 2016-03-14 13:19:30 --> File loaded: application/views/campanhas_listar.php
DEBUG - 2016-03-14 13:19:30 --> Final output sent to browser
DEBUG - 2016-03-14 13:19:30 --> Total execution time: 1.1630
DEBUG - 2016-03-14 13:19:31 --> Config Class Initialized
DEBUG - 2016-03-14 13:19:31 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:19:31 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:19:31 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:19:31 --> URI Class Initialized
DEBUG - 2016-03-14 13:19:31 --> Router Class Initialized
DEBUG - 2016-03-14 13:19:31 --> Output Class Initialized
DEBUG - 2016-03-14 13:19:31 --> Security Class Initialized
DEBUG - 2016-03-14 13:19:31 --> Input Class Initialized
DEBUG - 2016-03-14 13:19:31 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:19:31 --> Language Class Initialized
DEBUG - 2016-03-14 13:19:31 --> Loader Class Initialized
DEBUG - 2016-03-14 13:19:31 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:19:31 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:19:31 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:19:31 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:19:31 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:19:32 --> Session Class Initialized
DEBUG - 2016-03-14 13:19:32 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:19:32 --> Session routines successfully run
DEBUG - 2016-03-14 13:19:32 --> Controller Class Initialized
DEBUG - 2016-03-14 13:19:32 --> Final output sent to browser
DEBUG - 2016-03-14 13:19:32 --> Total execution time: 1.1430
DEBUG - 2016-03-14 13:19:53 --> Config Class Initialized
DEBUG - 2016-03-14 13:19:53 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:19:53 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:19:53 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:19:53 --> URI Class Initialized
DEBUG - 2016-03-14 13:19:53 --> Router Class Initialized
DEBUG - 2016-03-14 13:19:53 --> Output Class Initialized
DEBUG - 2016-03-14 13:19:53 --> Security Class Initialized
DEBUG - 2016-03-14 13:19:53 --> Input Class Initialized
DEBUG - 2016-03-14 13:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:19:53 --> Language Class Initialized
DEBUG - 2016-03-14 13:19:53 --> Loader Class Initialized
DEBUG - 2016-03-14 13:19:53 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:19:53 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:19:53 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:19:53 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:19:53 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:19:54 --> Session Class Initialized
DEBUG - 2016-03-14 13:19:54 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:19:54 --> A session cookie was not found.
DEBUG - 2016-03-14 13:19:54 --> Session routines successfully run
DEBUG - 2016-03-14 13:19:54 --> Controller Class Initialized
DEBUG - 2016-03-14 13:19:54 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 13:19:54 --> Model Class Initialized
DEBUG - 2016-03-14 13:19:54 --> Model Class Initialized
DEBUG - 2016-03-14 13:19:54 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-14 13:19:54 --> Final output sent to browser
DEBUG - 2016-03-14 13:19:54 --> Total execution time: 1.1170
DEBUG - 2016-03-14 13:19:55 --> Config Class Initialized
DEBUG - 2016-03-14 13:19:55 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:19:55 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:19:55 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:19:55 --> URI Class Initialized
DEBUG - 2016-03-14 13:19:55 --> Router Class Initialized
DEBUG - 2016-03-14 13:19:55 --> Output Class Initialized
DEBUG - 2016-03-14 13:19:55 --> Security Class Initialized
DEBUG - 2016-03-14 13:19:55 --> Input Class Initialized
DEBUG - 2016-03-14 13:19:55 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:19:55 --> Language Class Initialized
DEBUG - 2016-03-14 13:19:55 --> Loader Class Initialized
DEBUG - 2016-03-14 13:19:55 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:19:55 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:19:55 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:19:55 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:19:55 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:19:56 --> Session Class Initialized
DEBUG - 2016-03-14 13:19:56 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:19:56 --> Session routines successfully run
DEBUG - 2016-03-14 13:19:56 --> Controller Class Initialized
DEBUG - 2016-03-14 13:19:56 --> Final output sent to browser
DEBUG - 2016-03-14 13:19:56 --> Total execution time: 1.1600
DEBUG - 2016-03-14 13:20:02 --> Config Class Initialized
DEBUG - 2016-03-14 13:20:02 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:20:02 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:20:02 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:20:02 --> URI Class Initialized
DEBUG - 2016-03-14 13:20:02 --> Router Class Initialized
DEBUG - 2016-03-14 13:20:02 --> Output Class Initialized
DEBUG - 2016-03-14 13:20:02 --> Security Class Initialized
DEBUG - 2016-03-14 13:20:02 --> Input Class Initialized
DEBUG - 2016-03-14 13:20:02 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:20:02 --> Language Class Initialized
DEBUG - 2016-03-14 13:20:02 --> Loader Class Initialized
DEBUG - 2016-03-14 13:20:02 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:20:02 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:20:02 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:20:02 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:20:02 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:20:03 --> Session Class Initialized
DEBUG - 2016-03-14 13:20:03 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:20:03 --> Session routines successfully run
DEBUG - 2016-03-14 13:20:03 --> Controller Class Initialized
DEBUG - 2016-03-14 13:20:03 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 13:20:03 --> Model Class Initialized
DEBUG - 2016-03-14 13:20:03 --> Model Class Initialized
DEBUG - 2016-03-14 13:20:03 --> Helper loaded: form_helper
DEBUG - 2016-03-14 13:20:03 --> Form Validation Class Initialized
DEBUG - 2016-03-14 13:20:03 --> XSS Filtering completed
DEBUG - 2016-03-14 13:20:03 --> XSS Filtering completed
DEBUG - 2016-03-14 13:20:03 --> XSS Filtering completed
DEBUG - 2016-03-14 13:20:03 --> XSS Filtering completed
DEBUG - 2016-03-14 13:20:03 --> XSS Filtering completed
DEBUG - 2016-03-14 13:20:03 --> XSS Filtering completed
DEBUG - 2016-03-14 13:20:03 --> XSS Filtering completed
DEBUG - 2016-03-14 13:20:03 --> XSS Filtering completed
DEBUG - 2016-03-14 13:20:03 --> Language file loaded: language/pt-br/form_validation_lang.php
DEBUG - 2016-03-14 13:20:03 --> Final output sent to browser
DEBUG - 2016-03-14 13:20:03 --> Total execution time: 1.3268
DEBUG - 2016-03-14 13:20:04 --> Config Class Initialized
DEBUG - 2016-03-14 13:20:04 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:20:04 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:20:04 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:20:04 --> URI Class Initialized
DEBUG - 2016-03-14 13:20:04 --> Router Class Initialized
DEBUG - 2016-03-14 13:20:04 --> Output Class Initialized
DEBUG - 2016-03-14 13:20:04 --> Security Class Initialized
DEBUG - 2016-03-14 13:20:04 --> Input Class Initialized
DEBUG - 2016-03-14 13:20:04 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:20:04 --> Language Class Initialized
DEBUG - 2016-03-14 13:20:04 --> Loader Class Initialized
DEBUG - 2016-03-14 13:20:04 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:20:04 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:20:04 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:20:04 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:20:04 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:20:05 --> Session Class Initialized
DEBUG - 2016-03-14 13:20:05 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:20:05 --> Session routines successfully run
DEBUG - 2016-03-14 13:20:05 --> Controller Class Initialized
DEBUG - 2016-03-14 13:20:05 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 13:20:05 --> Model Class Initialized
DEBUG - 2016-03-14 13:20:05 --> Model Class Initialized
DEBUG - 2016-03-14 13:20:05 --> Upload Class Initialized
DEBUG - 2016-03-14 13:20:06 --> Final output sent to browser
DEBUG - 2016-03-14 13:20:06 --> Total execution time: 2.0380
DEBUG - 2016-03-14 13:20:09 --> Config Class Initialized
DEBUG - 2016-03-14 13:20:09 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:20:09 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:20:09 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:20:09 --> URI Class Initialized
DEBUG - 2016-03-14 13:20:09 --> Router Class Initialized
DEBUG - 2016-03-14 13:20:09 --> Output Class Initialized
DEBUG - 2016-03-14 13:20:09 --> Security Class Initialized
DEBUG - 2016-03-14 13:20:09 --> Input Class Initialized
DEBUG - 2016-03-14 13:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:20:09 --> Language Class Initialized
DEBUG - 2016-03-14 13:20:09 --> Loader Class Initialized
DEBUG - 2016-03-14 13:20:09 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:20:09 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:20:09 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:20:09 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:20:09 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:20:10 --> Session Class Initialized
DEBUG - 2016-03-14 13:20:10 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:20:10 --> A session cookie was not found.
DEBUG - 2016-03-14 13:20:10 --> Session routines successfully run
DEBUG - 2016-03-14 13:20:10 --> Controller Class Initialized
DEBUG - 2016-03-14 13:20:10 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 13:20:10 --> Model Class Initialized
DEBUG - 2016-03-14 13:20:10 --> Model Class Initialized
DEBUG - 2016-03-14 13:20:10 --> File loaded: application/views/campanhas_listar.php
DEBUG - 2016-03-14 13:20:10 --> Final output sent to browser
DEBUG - 2016-03-14 13:20:10 --> Total execution time: 1.0900
DEBUG - 2016-03-14 13:20:10 --> Config Class Initialized
DEBUG - 2016-03-14 13:20:10 --> Hooks Class Initialized
DEBUG - 2016-03-14 13:20:10 --> Utf8 Class Initialized
DEBUG - 2016-03-14 13:20:10 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 13:20:10 --> URI Class Initialized
DEBUG - 2016-03-14 13:20:10 --> Router Class Initialized
DEBUG - 2016-03-14 13:20:11 --> Output Class Initialized
DEBUG - 2016-03-14 13:20:11 --> Security Class Initialized
DEBUG - 2016-03-14 13:20:11 --> Input Class Initialized
DEBUG - 2016-03-14 13:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 13:20:11 --> Language Class Initialized
DEBUG - 2016-03-14 13:20:11 --> Loader Class Initialized
DEBUG - 2016-03-14 13:20:11 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 13:20:11 --> Helper loaded: url_helper
DEBUG - 2016-03-14 13:20:11 --> Helper loaded: image_helper
DEBUG - 2016-03-14 13:20:11 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 13:20:11 --> Database Driver Class Initialized
DEBUG - 2016-03-14 13:20:12 --> Session Class Initialized
DEBUG - 2016-03-14 13:20:12 --> Helper loaded: string_helper
DEBUG - 2016-03-14 13:20:12 --> Session routines successfully run
DEBUG - 2016-03-14 13:20:12 --> Controller Class Initialized
DEBUG - 2016-03-14 13:20:12 --> Final output sent to browser
DEBUG - 2016-03-14 13:20:12 --> Total execution time: 1.1990
DEBUG - 2016-03-14 15:13:35 --> Config Class Initialized
DEBUG - 2016-03-14 15:13:35 --> Hooks Class Initialized
DEBUG - 2016-03-14 15:13:35 --> Utf8 Class Initialized
DEBUG - 2016-03-14 15:13:35 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 15:13:35 --> URI Class Initialized
DEBUG - 2016-03-14 15:13:35 --> Router Class Initialized
DEBUG - 2016-03-14 15:13:35 --> Output Class Initialized
DEBUG - 2016-03-14 15:13:35 --> Security Class Initialized
DEBUG - 2016-03-14 15:13:35 --> Input Class Initialized
DEBUG - 2016-03-14 15:13:35 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 15:13:35 --> Language Class Initialized
DEBUG - 2016-03-14 15:13:35 --> Loader Class Initialized
DEBUG - 2016-03-14 15:13:35 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 15:13:35 --> Helper loaded: url_helper
DEBUG - 2016-03-14 15:13:35 --> Helper loaded: image_helper
DEBUG - 2016-03-14 15:13:35 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 15:13:35 --> Database Driver Class Initialized
DEBUG - 2016-03-14 15:13:36 --> Session Class Initialized
DEBUG - 2016-03-14 15:13:36 --> Helper loaded: string_helper
DEBUG - 2016-03-14 15:13:36 --> A session cookie was not found.
DEBUG - 2016-03-14 15:13:36 --> Session routines successfully run
DEBUG - 2016-03-14 15:13:36 --> Controller Class Initialized
DEBUG - 2016-03-14 15:13:36 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 15:13:36 --> Model Class Initialized
DEBUG - 2016-03-14 15:13:36 --> Model Class Initialized
DEBUG - 2016-03-14 15:13:36 --> File loaded: application/views/campanhas_listar.php
DEBUG - 2016-03-14 15:13:36 --> Final output sent to browser
DEBUG - 2016-03-14 15:13:36 --> Total execution time: 1.3430
DEBUG - 2016-03-14 15:13:42 --> Config Class Initialized
DEBUG - 2016-03-14 15:13:42 --> Hooks Class Initialized
DEBUG - 2016-03-14 15:13:42 --> Utf8 Class Initialized
DEBUG - 2016-03-14 15:13:42 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 15:13:42 --> URI Class Initialized
DEBUG - 2016-03-14 15:13:42 --> Router Class Initialized
DEBUG - 2016-03-14 15:13:43 --> Output Class Initialized
DEBUG - 2016-03-14 15:13:43 --> Security Class Initialized
DEBUG - 2016-03-14 15:13:43 --> Input Class Initialized
DEBUG - 2016-03-14 15:13:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 15:13:43 --> Language Class Initialized
DEBUG - 2016-03-14 15:13:43 --> Loader Class Initialized
DEBUG - 2016-03-14 15:13:43 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 15:13:43 --> Helper loaded: url_helper
DEBUG - 2016-03-14 15:13:43 --> Helper loaded: image_helper
DEBUG - 2016-03-14 15:13:43 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 15:13:43 --> Database Driver Class Initialized
DEBUG - 2016-03-14 15:13:44 --> Session Class Initialized
DEBUG - 2016-03-14 15:13:44 --> Helper loaded: string_helper
DEBUG - 2016-03-14 15:13:44 --> A session cookie was not found.
DEBUG - 2016-03-14 15:13:44 --> Session routines successfully run
DEBUG - 2016-03-14 15:13:44 --> Controller Class Initialized
DEBUG - 2016-03-14 15:13:44 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 15:13:44 --> Model Class Initialized
DEBUG - 2016-03-14 15:13:44 --> Model Class Initialized
DEBUG - 2016-03-14 15:13:44 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-14 15:13:44 --> Final output sent to browser
DEBUG - 2016-03-14 15:13:44 --> Total execution time: 1.1580
DEBUG - 2016-03-14 15:13:44 --> Config Class Initialized
DEBUG - 2016-03-14 15:13:44 --> Hooks Class Initialized
DEBUG - 2016-03-14 15:13:44 --> Utf8 Class Initialized
DEBUG - 2016-03-14 15:13:44 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 15:13:44 --> URI Class Initialized
DEBUG - 2016-03-14 15:13:44 --> Router Class Initialized
DEBUG - 2016-03-14 15:13:44 --> Output Class Initialized
DEBUG - 2016-03-14 15:13:44 --> Security Class Initialized
DEBUG - 2016-03-14 15:13:44 --> Input Class Initialized
DEBUG - 2016-03-14 15:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 15:13:44 --> Language Class Initialized
DEBUG - 2016-03-14 15:13:44 --> Loader Class Initialized
DEBUG - 2016-03-14 15:13:44 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 15:13:44 --> Helper loaded: url_helper
DEBUG - 2016-03-14 15:13:44 --> Helper loaded: image_helper
DEBUG - 2016-03-14 15:13:44 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 15:13:44 --> Database Driver Class Initialized
DEBUG - 2016-03-14 15:13:45 --> Session Class Initialized
DEBUG - 2016-03-14 15:13:45 --> Helper loaded: string_helper
DEBUG - 2016-03-14 15:13:45 --> Session routines successfully run
DEBUG - 2016-03-14 15:13:45 --> Controller Class Initialized
DEBUG - 2016-03-14 15:13:45 --> Final output sent to browser
DEBUG - 2016-03-14 15:13:45 --> Total execution time: 1.1490
DEBUG - 2016-03-14 15:14:07 --> Config Class Initialized
DEBUG - 2016-03-14 15:14:07 --> Hooks Class Initialized
DEBUG - 2016-03-14 15:14:07 --> Utf8 Class Initialized
DEBUG - 2016-03-14 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 15:14:07 --> URI Class Initialized
DEBUG - 2016-03-14 15:14:07 --> Router Class Initialized
DEBUG - 2016-03-14 15:14:07 --> Output Class Initialized
DEBUG - 2016-03-14 15:14:07 --> Security Class Initialized
DEBUG - 2016-03-14 15:14:07 --> Input Class Initialized
DEBUG - 2016-03-14 15:14:07 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 15:14:07 --> Language Class Initialized
DEBUG - 2016-03-14 15:14:07 --> Loader Class Initialized
DEBUG - 2016-03-14 15:14:07 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 15:14:07 --> Helper loaded: url_helper
DEBUG - 2016-03-14 15:14:07 --> Helper loaded: image_helper
DEBUG - 2016-03-14 15:14:07 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 15:14:07 --> Database Driver Class Initialized
DEBUG - 2016-03-14 15:14:08 --> Session Class Initialized
DEBUG - 2016-03-14 15:14:08 --> Helper loaded: string_helper
DEBUG - 2016-03-14 15:14:08 --> A session cookie was not found.
DEBUG - 2016-03-14 15:14:08 --> Session routines successfully run
DEBUG - 2016-03-14 15:14:08 --> Controller Class Initialized
DEBUG - 2016-03-14 15:14:08 --> Helper loaded: super_url_helper
DEBUG - 2016-03-14 15:14:08 --> Model Class Initialized
DEBUG - 2016-03-14 15:14:08 --> Model Class Initialized
DEBUG - 2016-03-14 15:14:08 --> File loaded: application/views/campanha_form.php
DEBUG - 2016-03-14 15:14:08 --> Final output sent to browser
DEBUG - 2016-03-14 15:14:08 --> Total execution time: 1.1710
DEBUG - 2016-03-14 15:14:09 --> Config Class Initialized
DEBUG - 2016-03-14 15:14:09 --> Hooks Class Initialized
DEBUG - 2016-03-14 15:14:09 --> Utf8 Class Initialized
DEBUG - 2016-03-14 15:14:09 --> UTF-8 Support Enabled
DEBUG - 2016-03-14 15:14:09 --> URI Class Initialized
DEBUG - 2016-03-14 15:14:09 --> Router Class Initialized
DEBUG - 2016-03-14 15:14:09 --> Output Class Initialized
DEBUG - 2016-03-14 15:14:09 --> Security Class Initialized
DEBUG - 2016-03-14 15:14:09 --> Input Class Initialized
DEBUG - 2016-03-14 15:14:09 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-14 15:14:09 --> Language Class Initialized
DEBUG - 2016-03-14 15:14:09 --> Loader Class Initialized
DEBUG - 2016-03-14 15:14:09 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-14 15:14:09 --> Helper loaded: url_helper
DEBUG - 2016-03-14 15:14:09 --> Helper loaded: image_helper
DEBUG - 2016-03-14 15:14:09 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-14 15:14:09 --> Database Driver Class Initialized
DEBUG - 2016-03-14 15:14:10 --> Session Class Initialized
DEBUG - 2016-03-14 15:14:10 --> Helper loaded: string_helper
DEBUG - 2016-03-14 15:14:10 --> Session routines successfully run
DEBUG - 2016-03-14 15:14:10 --> Controller Class Initialized
DEBUG - 2016-03-14 15:14:10 --> Final output sent to browser
DEBUG - 2016-03-14 15:14:10 --> Total execution time: 1.1350
