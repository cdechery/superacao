<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2016-03-09 15:42:32 --> Config Class Initialized
DEBUG - 2016-03-09 15:42:32 --> Hooks Class Initialized
DEBUG - 2016-03-09 15:42:32 --> Utf8 Class Initialized
DEBUG - 2016-03-09 15:42:32 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 15:42:32 --> URI Class Initialized
DEBUG - 2016-03-09 15:42:32 --> Router Class Initialized
DEBUG - 2016-03-09 15:42:32 --> Output Class Initialized
DEBUG - 2016-03-09 15:42:32 --> Security Class Initialized
DEBUG - 2016-03-09 15:42:32 --> Input Class Initialized
DEBUG - 2016-03-09 15:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 15:42:32 --> Language Class Initialized
DEBUG - 2016-03-09 15:42:32 --> Loader Class Initialized
DEBUG - 2016-03-09 15:42:33 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 15:42:33 --> Helper loaded: url_helper
DEBUG - 2016-03-09 15:42:33 --> Helper loaded: image_helper
DEBUG - 2016-03-09 15:42:33 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 15:42:33 --> Database Driver Class Initialized
DEBUG - 2016-03-09 15:42:34 --> Session Class Initialized
DEBUG - 2016-03-09 15:42:34 --> Helper loaded: string_helper
DEBUG - 2016-03-09 15:42:34 --> A session cookie was not found.
DEBUG - 2016-03-09 15:42:34 --> Session routines successfully run
DEBUG - 2016-03-09 15:42:34 --> Controller Class Initialized
DEBUG - 2016-03-09 15:42:34 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 15:42:34 --> Model Class Initialized
DEBUG - 2016-03-09 15:42:34 --> Model Class Initialized
DEBUG - 2016-03-09 15:42:34 --> File loaded: application/views/campanhas_ativas.php
DEBUG - 2016-03-09 15:42:34 --> Final output sent to browser
DEBUG - 2016-03-09 15:42:34 --> Total execution time: 1.3707
DEBUG - 2016-03-09 15:42:34 --> Config Class Initialized
DEBUG - 2016-03-09 15:42:34 --> Hooks Class Initialized
DEBUG - 2016-03-09 15:42:34 --> Utf8 Class Initialized
DEBUG - 2016-03-09 15:42:34 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 15:42:34 --> URI Class Initialized
DEBUG - 2016-03-09 15:42:34 --> Router Class Initialized
DEBUG - 2016-03-09 15:42:34 --> Output Class Initialized
DEBUG - 2016-03-09 15:42:34 --> Security Class Initialized
DEBUG - 2016-03-09 15:42:34 --> Input Class Initialized
DEBUG - 2016-03-09 15:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 15:42:34 --> Language Class Initialized
DEBUG - 2016-03-09 15:42:34 --> Loader Class Initialized
DEBUG - 2016-03-09 15:42:34 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 15:42:34 --> Helper loaded: url_helper
DEBUG - 2016-03-09 15:42:34 --> Helper loaded: image_helper
DEBUG - 2016-03-09 15:42:34 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 15:42:34 --> Database Driver Class Initialized
DEBUG - 2016-03-09 15:42:35 --> Session Class Initialized
DEBUG - 2016-03-09 15:42:35 --> Helper loaded: string_helper
DEBUG - 2016-03-09 15:42:35 --> Session routines successfully run
DEBUG - 2016-03-09 15:42:35 --> Controller Class Initialized
DEBUG - 2016-03-09 15:42:35 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 15:42:35 --> Model Class Initialized
DEBUG - 2016-03-09 15:42:35 --> Model Class Initialized
ERROR - 2016-03-09 15:42:35 --> 404 Page Not Found --> campanha/imgs
DEBUG - 2016-03-09 15:43:22 --> Config Class Initialized
DEBUG - 2016-03-09 15:43:22 --> Hooks Class Initialized
DEBUG - 2016-03-09 15:43:22 --> Utf8 Class Initialized
DEBUG - 2016-03-09 15:43:22 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 15:43:22 --> URI Class Initialized
DEBUG - 2016-03-09 15:43:22 --> Router Class Initialized
DEBUG - 2016-03-09 15:43:22 --> Output Class Initialized
DEBUG - 2016-03-09 15:43:22 --> Security Class Initialized
DEBUG - 2016-03-09 15:43:22 --> Input Class Initialized
DEBUG - 2016-03-09 15:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 15:43:22 --> Language Class Initialized
DEBUG - 2016-03-09 15:43:22 --> Loader Class Initialized
DEBUG - 2016-03-09 15:43:22 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 15:43:22 --> Helper loaded: url_helper
DEBUG - 2016-03-09 15:43:22 --> Helper loaded: image_helper
DEBUG - 2016-03-09 15:43:22 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 15:43:22 --> Database Driver Class Initialized
DEBUG - 2016-03-09 15:43:23 --> Session Class Initialized
DEBUG - 2016-03-09 15:43:23 --> Helper loaded: string_helper
DEBUG - 2016-03-09 15:43:23 --> Session routines successfully run
DEBUG - 2016-03-09 15:43:23 --> Controller Class Initialized
DEBUG - 2016-03-09 15:43:23 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 15:43:23 --> Model Class Initialized
DEBUG - 2016-03-09 15:43:23 --> Model Class Initialized
DEBUG - 2016-03-09 15:43:23 --> File loaded: application/views/campanhas_ativas.php
DEBUG - 2016-03-09 15:43:23 --> Final output sent to browser
DEBUG - 2016-03-09 15:43:23 --> Total execution time: 1.1298
DEBUG - 2016-03-09 15:43:24 --> Config Class Initialized
DEBUG - 2016-03-09 15:43:24 --> Hooks Class Initialized
DEBUG - 2016-03-09 15:43:24 --> Utf8 Class Initialized
DEBUG - 2016-03-09 15:43:24 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 15:43:24 --> URI Class Initialized
DEBUG - 2016-03-09 15:43:24 --> Router Class Initialized
DEBUG - 2016-03-09 15:43:24 --> Output Class Initialized
DEBUG - 2016-03-09 15:43:24 --> Security Class Initialized
DEBUG - 2016-03-09 15:43:24 --> Input Class Initialized
DEBUG - 2016-03-09 15:43:24 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 15:43:24 --> Language Class Initialized
DEBUG - 2016-03-09 15:43:24 --> Loader Class Initialized
DEBUG - 2016-03-09 15:43:24 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 15:43:24 --> Helper loaded: url_helper
DEBUG - 2016-03-09 15:43:24 --> Helper loaded: image_helper
DEBUG - 2016-03-09 15:43:24 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 15:43:24 --> Database Driver Class Initialized
DEBUG - 2016-03-09 15:43:25 --> Session Class Initialized
DEBUG - 2016-03-09 15:43:25 --> Helper loaded: string_helper
DEBUG - 2016-03-09 15:43:25 --> Session routines successfully run
DEBUG - 2016-03-09 15:43:25 --> Controller Class Initialized
DEBUG - 2016-03-09 15:43:25 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 15:43:25 --> Model Class Initialized
DEBUG - 2016-03-09 15:43:25 --> Model Class Initialized
ERROR - 2016-03-09 15:43:25 --> 404 Page Not Found --> campanha/imgs
DEBUG - 2016-03-09 15:43:45 --> Config Class Initialized
DEBUG - 2016-03-09 15:43:45 --> Hooks Class Initialized
DEBUG - 2016-03-09 15:43:45 --> Utf8 Class Initialized
DEBUG - 2016-03-09 15:43:45 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 15:43:45 --> URI Class Initialized
DEBUG - 2016-03-09 15:43:45 --> Router Class Initialized
DEBUG - 2016-03-09 15:43:45 --> Output Class Initialized
DEBUG - 2016-03-09 15:43:45 --> Security Class Initialized
DEBUG - 2016-03-09 15:43:45 --> Input Class Initialized
DEBUG - 2016-03-09 15:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 15:43:45 --> Language Class Initialized
DEBUG - 2016-03-09 15:43:45 --> Loader Class Initialized
DEBUG - 2016-03-09 15:43:45 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 15:43:45 --> Helper loaded: url_helper
DEBUG - 2016-03-09 15:43:45 --> Helper loaded: image_helper
DEBUG - 2016-03-09 15:43:45 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 15:43:45 --> Database Driver Class Initialized
DEBUG - 2016-03-09 15:43:46 --> Session Class Initialized
DEBUG - 2016-03-09 15:43:46 --> Helper loaded: string_helper
DEBUG - 2016-03-09 15:43:46 --> Session routines successfully run
DEBUG - 2016-03-09 15:43:46 --> Controller Class Initialized
DEBUG - 2016-03-09 15:43:46 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 15:43:46 --> Model Class Initialized
DEBUG - 2016-03-09 15:43:46 --> Model Class Initialized
DEBUG - 2016-03-09 15:43:46 --> File loaded: application/views/campanhas_ativas.php
DEBUG - 2016-03-09 15:43:46 --> Final output sent to browser
DEBUG - 2016-03-09 15:43:46 --> Total execution time: 1.1148
DEBUG - 2016-03-09 15:43:46 --> Config Class Initialized
DEBUG - 2016-03-09 15:43:46 --> Hooks Class Initialized
DEBUG - 2016-03-09 15:43:46 --> Utf8 Class Initialized
DEBUG - 2016-03-09 15:43:46 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 15:43:46 --> URI Class Initialized
DEBUG - 2016-03-09 15:43:46 --> Router Class Initialized
DEBUG - 2016-03-09 15:43:46 --> Output Class Initialized
DEBUG - 2016-03-09 15:43:46 --> Security Class Initialized
DEBUG - 2016-03-09 15:43:46 --> Input Class Initialized
DEBUG - 2016-03-09 15:43:46 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 15:43:46 --> Language Class Initialized
DEBUG - 2016-03-09 15:43:46 --> Loader Class Initialized
DEBUG - 2016-03-09 15:43:46 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 15:43:46 --> Helper loaded: url_helper
DEBUG - 2016-03-09 15:43:46 --> Helper loaded: image_helper
DEBUG - 2016-03-09 15:43:46 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 15:43:46 --> Database Driver Class Initialized
DEBUG - 2016-03-09 15:43:47 --> Session Class Initialized
DEBUG - 2016-03-09 15:43:47 --> Helper loaded: string_helper
DEBUG - 2016-03-09 15:43:47 --> Session routines successfully run
DEBUG - 2016-03-09 15:43:47 --> Controller Class Initialized
DEBUG - 2016-03-09 15:43:47 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 15:43:47 --> Model Class Initialized
DEBUG - 2016-03-09 15:43:47 --> Model Class Initialized
ERROR - 2016-03-09 15:43:47 --> 404 Page Not Found --> campanha/imgs
DEBUG - 2016-03-09 15:46:20 --> Config Class Initialized
DEBUG - 2016-03-09 15:46:20 --> Hooks Class Initialized
DEBUG - 2016-03-09 15:46:20 --> Utf8 Class Initialized
DEBUG - 2016-03-09 15:46:20 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 15:46:20 --> URI Class Initialized
DEBUG - 2016-03-09 15:46:20 --> Router Class Initialized
DEBUG - 2016-03-09 15:46:20 --> Output Class Initialized
DEBUG - 2016-03-09 15:46:20 --> Security Class Initialized
DEBUG - 2016-03-09 15:46:20 --> Input Class Initialized
DEBUG - 2016-03-09 15:46:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 15:46:20 --> Language Class Initialized
DEBUG - 2016-03-09 15:46:20 --> Loader Class Initialized
DEBUG - 2016-03-09 15:46:20 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 15:46:20 --> Helper loaded: url_helper
DEBUG - 2016-03-09 15:46:20 --> Helper loaded: image_helper
DEBUG - 2016-03-09 15:46:20 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 15:46:20 --> Database Driver Class Initialized
DEBUG - 2016-03-09 15:46:21 --> Session Class Initialized
DEBUG - 2016-03-09 15:46:21 --> Helper loaded: string_helper
DEBUG - 2016-03-09 15:46:21 --> Session routines successfully run
DEBUG - 2016-03-09 15:46:21 --> Controller Class Initialized
DEBUG - 2016-03-09 15:46:21 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 15:46:21 --> Model Class Initialized
DEBUG - 2016-03-09 15:46:21 --> Model Class Initialized
DEBUG - 2016-03-09 15:46:21 --> File loaded: application/views/campanhas_ativas.php
DEBUG - 2016-03-09 15:46:21 --> Final output sent to browser
DEBUG - 2016-03-09 15:46:21 --> Total execution time: 1.1420
DEBUG - 2016-03-09 15:46:21 --> Config Class Initialized
DEBUG - 2016-03-09 15:46:21 --> Hooks Class Initialized
DEBUG - 2016-03-09 15:46:21 --> Utf8 Class Initialized
DEBUG - 2016-03-09 15:46:21 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 15:46:21 --> URI Class Initialized
DEBUG - 2016-03-09 15:46:21 --> Router Class Initialized
DEBUG - 2016-03-09 15:46:21 --> Output Class Initialized
DEBUG - 2016-03-09 15:46:21 --> Security Class Initialized
DEBUG - 2016-03-09 15:46:21 --> Input Class Initialized
DEBUG - 2016-03-09 15:46:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 15:46:21 --> Language Class Initialized
DEBUG - 2016-03-09 15:46:21 --> Loader Class Initialized
DEBUG - 2016-03-09 15:46:21 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 15:46:21 --> Helper loaded: url_helper
DEBUG - 2016-03-09 15:46:21 --> Helper loaded: image_helper
DEBUG - 2016-03-09 15:46:21 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 15:46:21 --> Database Driver Class Initialized
DEBUG - 2016-03-09 15:46:22 --> Session Class Initialized
DEBUG - 2016-03-09 15:46:22 --> Helper loaded: string_helper
DEBUG - 2016-03-09 15:46:22 --> Session routines successfully run
DEBUG - 2016-03-09 15:46:22 --> Controller Class Initialized
DEBUG - 2016-03-09 15:46:22 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 15:46:22 --> Model Class Initialized
DEBUG - 2016-03-09 15:46:22 --> Model Class Initialized
ERROR - 2016-03-09 15:46:22 --> 404 Page Not Found --> campanha/imgs
DEBUG - 2016-03-09 15:46:43 --> Config Class Initialized
DEBUG - 2016-03-09 15:46:43 --> Hooks Class Initialized
DEBUG - 2016-03-09 15:46:43 --> Utf8 Class Initialized
DEBUG - 2016-03-09 15:46:43 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 15:46:43 --> URI Class Initialized
DEBUG - 2016-03-09 15:46:43 --> Router Class Initialized
DEBUG - 2016-03-09 15:46:43 --> Output Class Initialized
DEBUG - 2016-03-09 15:46:43 --> Security Class Initialized
DEBUG - 2016-03-09 15:46:43 --> Input Class Initialized
DEBUG - 2016-03-09 15:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 15:46:43 --> Language Class Initialized
DEBUG - 2016-03-09 15:46:43 --> Loader Class Initialized
DEBUG - 2016-03-09 15:46:43 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 15:46:43 --> Helper loaded: url_helper
DEBUG - 2016-03-09 15:46:43 --> Helper loaded: image_helper
DEBUG - 2016-03-09 15:46:43 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 15:46:43 --> Database Driver Class Initialized
DEBUG - 2016-03-09 15:46:44 --> Session Class Initialized
DEBUG - 2016-03-09 15:46:44 --> Helper loaded: string_helper
DEBUG - 2016-03-09 15:46:44 --> Session routines successfully run
DEBUG - 2016-03-09 15:46:44 --> Controller Class Initialized
DEBUG - 2016-03-09 15:46:44 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 15:46:45 --> Model Class Initialized
DEBUG - 2016-03-09 15:46:45 --> Model Class Initialized
DEBUG - 2016-03-09 15:46:45 --> File loaded: application/views/campanhas_ativas.php
DEBUG - 2016-03-09 15:46:45 --> Final output sent to browser
DEBUG - 2016-03-09 15:46:45 --> Total execution time: 1.1550
DEBUG - 2016-03-09 15:46:45 --> Config Class Initialized
DEBUG - 2016-03-09 15:46:45 --> Hooks Class Initialized
DEBUG - 2016-03-09 15:46:45 --> Utf8 Class Initialized
DEBUG - 2016-03-09 15:46:45 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 15:46:45 --> URI Class Initialized
DEBUG - 2016-03-09 15:46:45 --> Router Class Initialized
DEBUG - 2016-03-09 15:46:45 --> Output Class Initialized
DEBUG - 2016-03-09 15:46:45 --> Security Class Initialized
DEBUG - 2016-03-09 15:46:45 --> Input Class Initialized
DEBUG - 2016-03-09 15:46:45 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 15:46:45 --> Language Class Initialized
DEBUG - 2016-03-09 15:46:45 --> Loader Class Initialized
DEBUG - 2016-03-09 15:46:45 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 15:46:45 --> Helper loaded: url_helper
DEBUG - 2016-03-09 15:46:45 --> Helper loaded: image_helper
DEBUG - 2016-03-09 15:46:45 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 15:46:45 --> Database Driver Class Initialized
DEBUG - 2016-03-09 15:46:46 --> Session Class Initialized
DEBUG - 2016-03-09 15:46:46 --> Helper loaded: string_helper
DEBUG - 2016-03-09 15:46:46 --> Session routines successfully run
DEBUG - 2016-03-09 15:46:46 --> Controller Class Initialized
DEBUG - 2016-03-09 15:46:46 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 15:46:46 --> Model Class Initialized
DEBUG - 2016-03-09 15:46:46 --> Model Class Initialized
ERROR - 2016-03-09 15:46:46 --> 404 Page Not Found --> campanha/imgs
DEBUG - 2016-03-09 15:51:36 --> Config Class Initialized
DEBUG - 2016-03-09 15:51:36 --> Hooks Class Initialized
DEBUG - 2016-03-09 15:51:36 --> Utf8 Class Initialized
DEBUG - 2016-03-09 15:51:36 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 15:51:36 --> URI Class Initialized
DEBUG - 2016-03-09 15:51:36 --> Router Class Initialized
DEBUG - 2016-03-09 15:51:36 --> Output Class Initialized
DEBUG - 2016-03-09 15:51:36 --> Security Class Initialized
DEBUG - 2016-03-09 15:51:36 --> Input Class Initialized
DEBUG - 2016-03-09 15:51:36 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 15:51:36 --> Language Class Initialized
DEBUG - 2016-03-09 15:51:36 --> Loader Class Initialized
DEBUG - 2016-03-09 15:51:36 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 15:51:36 --> Helper loaded: url_helper
DEBUG - 2016-03-09 15:51:36 --> Helper loaded: image_helper
DEBUG - 2016-03-09 15:51:36 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 15:51:36 --> Database Driver Class Initialized
DEBUG - 2016-03-09 15:51:37 --> Session Class Initialized
DEBUG - 2016-03-09 15:51:37 --> Helper loaded: string_helper
DEBUG - 2016-03-09 15:51:37 --> Session routines successfully run
DEBUG - 2016-03-09 15:51:37 --> Controller Class Initialized
DEBUG - 2016-03-09 15:51:37 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 15:51:37 --> Model Class Initialized
DEBUG - 2016-03-09 15:51:37 --> Model Class Initialized
DEBUG - 2016-03-09 15:51:37 --> File loaded: application/views/campanhas_ativas.php
DEBUG - 2016-03-09 15:51:37 --> Final output sent to browser
DEBUG - 2016-03-09 15:51:37 --> Total execution time: 1.1460
DEBUG - 2016-03-09 15:51:37 --> Config Class Initialized
DEBUG - 2016-03-09 15:51:37 --> Hooks Class Initialized
DEBUG - 2016-03-09 15:51:37 --> Utf8 Class Initialized
DEBUG - 2016-03-09 15:51:37 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 15:51:37 --> URI Class Initialized
DEBUG - 2016-03-09 15:51:37 --> Router Class Initialized
DEBUG - 2016-03-09 15:51:37 --> Output Class Initialized
DEBUG - 2016-03-09 15:51:37 --> Security Class Initialized
DEBUG - 2016-03-09 15:51:37 --> Input Class Initialized
DEBUG - 2016-03-09 15:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 15:51:37 --> Language Class Initialized
DEBUG - 2016-03-09 15:51:37 --> Loader Class Initialized
DEBUG - 2016-03-09 15:51:37 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 15:51:37 --> Helper loaded: url_helper
DEBUG - 2016-03-09 15:51:37 --> Helper loaded: image_helper
DEBUG - 2016-03-09 15:51:37 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 15:51:37 --> Database Driver Class Initialized
DEBUG - 2016-03-09 15:51:38 --> Session Class Initialized
DEBUG - 2016-03-09 15:51:38 --> Helper loaded: string_helper
DEBUG - 2016-03-09 15:51:38 --> Session routines successfully run
DEBUG - 2016-03-09 15:51:38 --> Controller Class Initialized
DEBUG - 2016-03-09 15:51:38 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 15:51:38 --> Model Class Initialized
DEBUG - 2016-03-09 15:51:38 --> Model Class Initialized
ERROR - 2016-03-09 15:51:38 --> 404 Page Not Found --> campanha/imgs
DEBUG - 2016-03-09 16:25:19 --> Config Class Initialized
DEBUG - 2016-03-09 16:25:19 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:25:19 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:25:19 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:25:19 --> URI Class Initialized
DEBUG - 2016-03-09 16:25:19 --> Router Class Initialized
DEBUG - 2016-03-09 16:25:19 --> Output Class Initialized
DEBUG - 2016-03-09 16:25:19 --> Security Class Initialized
DEBUG - 2016-03-09 16:25:19 --> Input Class Initialized
DEBUG - 2016-03-09 16:25:19 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 16:25:19 --> Language Class Initialized
DEBUG - 2016-03-09 16:25:19 --> Loader Class Initialized
DEBUG - 2016-03-09 16:25:19 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 16:25:19 --> Helper loaded: url_helper
DEBUG - 2016-03-09 16:25:19 --> Helper loaded: image_helper
DEBUG - 2016-03-09 16:25:19 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 16:25:19 --> Database Driver Class Initialized
DEBUG - 2016-03-09 16:25:20 --> Session Class Initialized
DEBUG - 2016-03-09 16:25:20 --> Helper loaded: string_helper
DEBUG - 2016-03-09 16:25:20 --> Session routines successfully run
DEBUG - 2016-03-09 16:25:20 --> Controller Class Initialized
DEBUG - 2016-03-09 16:25:20 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 16:25:20 --> Model Class Initialized
DEBUG - 2016-03-09 16:25:20 --> Model Class Initialized
DEBUG - 2016-03-09 16:25:20 --> File loaded: application/views/campanhas_ativas.php
DEBUG - 2016-03-09 16:25:20 --> Final output sent to browser
DEBUG - 2016-03-09 16:25:20 --> Total execution time: 1.1621
DEBUG - 2016-03-09 16:25:21 --> Config Class Initialized
DEBUG - 2016-03-09 16:25:21 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:25:21 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:25:21 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:25:21 --> URI Class Initialized
DEBUG - 2016-03-09 16:25:21 --> Router Class Initialized
DEBUG - 2016-03-09 16:25:21 --> Output Class Initialized
DEBUG - 2016-03-09 16:25:21 --> Security Class Initialized
DEBUG - 2016-03-09 16:25:21 --> Input Class Initialized
DEBUG - 2016-03-09 16:25:21 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 16:25:21 --> Language Class Initialized
DEBUG - 2016-03-09 16:25:21 --> Loader Class Initialized
DEBUG - 2016-03-09 16:25:21 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 16:25:21 --> Helper loaded: url_helper
DEBUG - 2016-03-09 16:25:21 --> Helper loaded: image_helper
DEBUG - 2016-03-09 16:25:21 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 16:25:21 --> Database Driver Class Initialized
DEBUG - 2016-03-09 16:25:22 --> Session Class Initialized
DEBUG - 2016-03-09 16:25:22 --> Helper loaded: string_helper
DEBUG - 2016-03-09 16:25:22 --> Session routines successfully run
DEBUG - 2016-03-09 16:25:22 --> Controller Class Initialized
DEBUG - 2016-03-09 16:25:22 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 16:25:22 --> Model Class Initialized
DEBUG - 2016-03-09 16:25:22 --> Model Class Initialized
ERROR - 2016-03-09 16:25:22 --> 404 Page Not Found --> campanha/imgs
DEBUG - 2016-03-09 16:25:26 --> Config Class Initialized
DEBUG - 2016-03-09 16:25:26 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:25:26 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:25:26 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:25:26 --> URI Class Initialized
DEBUG - 2016-03-09 16:25:26 --> Router Class Initialized
DEBUG - 2016-03-09 16:25:26 --> Output Class Initialized
DEBUG - 2016-03-09 16:25:26 --> Security Class Initialized
DEBUG - 2016-03-09 16:25:26 --> Input Class Initialized
DEBUG - 2016-03-09 16:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 16:25:26 --> Language Class Initialized
DEBUG - 2016-03-09 16:25:26 --> Loader Class Initialized
DEBUG - 2016-03-09 16:25:26 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 16:25:26 --> Helper loaded: url_helper
DEBUG - 2016-03-09 16:25:26 --> Helper loaded: image_helper
DEBUG - 2016-03-09 16:25:26 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 16:25:26 --> Database Driver Class Initialized
DEBUG - 2016-03-09 16:25:27 --> Session Class Initialized
DEBUG - 2016-03-09 16:25:27 --> Helper loaded: string_helper
DEBUG - 2016-03-09 16:25:27 --> Session routines successfully run
DEBUG - 2016-03-09 16:25:27 --> Controller Class Initialized
DEBUG - 2016-03-09 16:25:27 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 16:25:27 --> Model Class Initialized
DEBUG - 2016-03-09 16:25:27 --> Model Class Initialized
DEBUG - 2016-03-09 16:25:27 --> File loaded: application/views/campanhas_ativas.php
DEBUG - 2016-03-09 16:25:27 --> Final output sent to browser
DEBUG - 2016-03-09 16:25:27 --> Total execution time: 1.1271
DEBUG - 2016-03-09 16:25:27 --> Config Class Initialized
DEBUG - 2016-03-09 16:25:27 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:25:27 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:25:27 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:25:27 --> URI Class Initialized
DEBUG - 2016-03-09 16:25:27 --> Router Class Initialized
DEBUG - 2016-03-09 16:25:27 --> Output Class Initialized
DEBUG - 2016-03-09 16:25:27 --> Security Class Initialized
DEBUG - 2016-03-09 16:25:27 --> Input Class Initialized
DEBUG - 2016-03-09 16:25:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 16:25:27 --> Language Class Initialized
DEBUG - 2016-03-09 16:25:27 --> Loader Class Initialized
DEBUG - 2016-03-09 16:25:27 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 16:25:27 --> Helper loaded: url_helper
DEBUG - 2016-03-09 16:25:27 --> Helper loaded: image_helper
DEBUG - 2016-03-09 16:25:27 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 16:25:27 --> Database Driver Class Initialized
DEBUG - 2016-03-09 16:25:28 --> Session Class Initialized
DEBUG - 2016-03-09 16:25:28 --> Helper loaded: string_helper
DEBUG - 2016-03-09 16:25:28 --> Session routines successfully run
DEBUG - 2016-03-09 16:25:28 --> Controller Class Initialized
DEBUG - 2016-03-09 16:25:28 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 16:25:28 --> Model Class Initialized
DEBUG - 2016-03-09 16:25:28 --> Model Class Initialized
ERROR - 2016-03-09 16:25:28 --> 404 Page Not Found --> campanha/imgs
DEBUG - 2016-03-09 16:26:10 --> Config Class Initialized
DEBUG - 2016-03-09 16:26:10 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:26:10 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:26:10 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:26:10 --> URI Class Initialized
DEBUG - 2016-03-09 16:26:11 --> Router Class Initialized
DEBUG - 2016-03-09 16:26:11 --> Output Class Initialized
DEBUG - 2016-03-09 16:26:11 --> Security Class Initialized
DEBUG - 2016-03-09 16:26:11 --> Input Class Initialized
DEBUG - 2016-03-09 16:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 16:26:11 --> Language Class Initialized
DEBUG - 2016-03-09 16:26:11 --> Loader Class Initialized
DEBUG - 2016-03-09 16:26:11 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 16:26:11 --> Helper loaded: url_helper
DEBUG - 2016-03-09 16:26:11 --> Helper loaded: image_helper
DEBUG - 2016-03-09 16:26:11 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 16:26:11 --> Database Driver Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Session Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Helper loaded: string_helper
DEBUG - 2016-03-09 16:26:12 --> Session routines successfully run
DEBUG - 2016-03-09 16:26:12 --> Controller Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 16:26:12 --> Model Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Model Class Initialized
DEBUG - 2016-03-09 16:26:12 --> File loaded: application/views/campanhas_ativas.php
DEBUG - 2016-03-09 16:26:12 --> Final output sent to browser
DEBUG - 2016-03-09 16:26:12 --> Total execution time: 1.1421
DEBUG - 2016-03-09 16:26:12 --> Config Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Config Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Config Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Config Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:26:12 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:26:12 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:26:12 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:26:12 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:26:12 --> URI Class Initialized
DEBUG - 2016-03-09 16:26:12 --> URI Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Router Class Initialized
DEBUG - 2016-03-09 16:26:12 --> URI Class Initialized
ERROR - 2016-03-09 16:26:12 --> 404 Page Not Found --> estilos
DEBUG - 2016-03-09 16:26:12 --> Router Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Router Class Initialized
ERROR - 2016-03-09 16:26:12 --> 404 Page Not Found --> _cmp
DEBUG - 2016-03-09 16:26:12 --> URI Class Initialized
ERROR - 2016-03-09 16:26:12 --> 404 Page Not Found --> _cmp
DEBUG - 2016-03-09 16:26:12 --> Router Class Initialized
ERROR - 2016-03-09 16:26:12 --> 404 Page Not Found --> _cmp
DEBUG - 2016-03-09 16:26:12 --> Config Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:26:12 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:26:12 --> URI Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Router Class Initialized
ERROR - 2016-03-09 16:26:12 --> 404 Page Not Found --> estilos
DEBUG - 2016-03-09 16:26:12 --> Config Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:26:12 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:26:12 --> URI Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Router Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Output Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Security Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Input Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 16:26:12 --> Language Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Loader Class Initialized
DEBUG - 2016-03-09 16:26:12 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 16:26:12 --> Helper loaded: url_helper
DEBUG - 2016-03-09 16:26:12 --> Helper loaded: image_helper
DEBUG - 2016-03-09 16:26:12 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 16:26:12 --> Database Driver Class Initialized
DEBUG - 2016-03-09 16:26:13 --> Session Class Initialized
DEBUG - 2016-03-09 16:26:13 --> Helper loaded: string_helper
DEBUG - 2016-03-09 16:26:13 --> Session routines successfully run
DEBUG - 2016-03-09 16:26:13 --> Controller Class Initialized
DEBUG - 2016-03-09 16:26:13 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 16:26:13 --> Model Class Initialized
DEBUG - 2016-03-09 16:26:13 --> Model Class Initialized
ERROR - 2016-03-09 16:26:13 --> 404 Page Not Found --> campanha/imgs
DEBUG - 2016-03-09 16:26:35 --> Config Class Initialized
DEBUG - 2016-03-09 16:26:35 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:26:35 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:26:35 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:26:35 --> URI Class Initialized
DEBUG - 2016-03-09 16:26:35 --> Router Class Initialized
ERROR - 2016-03-09 16:26:35 --> 404 Page Not Found --> estilos
DEBUG - 2016-03-09 16:26:45 --> Config Class Initialized
DEBUG - 2016-03-09 16:26:45 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:26:45 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:26:45 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:26:45 --> URI Class Initialized
DEBUG - 2016-03-09 16:26:45 --> Router Class Initialized
ERROR - 2016-03-09 16:26:46 --> 404 Page Not Found --> _cmp
DEBUG - 2016-03-09 16:27:27 --> Config Class Initialized
DEBUG - 2016-03-09 16:27:27 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:27:27 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:27:27 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:27:27 --> URI Class Initialized
DEBUG - 2016-03-09 16:27:27 --> Router Class Initialized
DEBUG - 2016-03-09 16:27:27 --> Output Class Initialized
DEBUG - 2016-03-09 16:27:27 --> Security Class Initialized
DEBUG - 2016-03-09 16:27:27 --> Input Class Initialized
DEBUG - 2016-03-09 16:27:27 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 16:27:27 --> Language Class Initialized
DEBUG - 2016-03-09 16:27:27 --> Loader Class Initialized
DEBUG - 2016-03-09 16:27:27 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 16:27:27 --> Helper loaded: url_helper
DEBUG - 2016-03-09 16:27:27 --> Helper loaded: image_helper
DEBUG - 2016-03-09 16:27:27 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 16:27:27 --> Database Driver Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Session Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Helper loaded: string_helper
DEBUG - 2016-03-09 16:27:28 --> Session routines successfully run
DEBUG - 2016-03-09 16:27:28 --> Controller Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 16:27:28 --> Model Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Model Class Initialized
DEBUG - 2016-03-09 16:27:28 --> File loaded: application/views/campanhas_ativas.php
DEBUG - 2016-03-09 16:27:28 --> Final output sent to browser
DEBUG - 2016-03-09 16:27:28 --> Total execution time: 1.0951
DEBUG - 2016-03-09 16:27:28 --> Config Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:27:28 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:27:28 --> URI Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Router Class Initialized
ERROR - 2016-03-09 16:27:28 --> 404 Page Not Found --> _cmp
DEBUG - 2016-03-09 16:27:28 --> Config Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:27:28 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:27:28 --> URI Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Router Class Initialized
ERROR - 2016-03-09 16:27:28 --> 404 Page Not Found --> _cmp
DEBUG - 2016-03-09 16:27:28 --> Config Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:27:28 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:27:28 --> Config Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:27:28 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:27:28 --> URI Class Initialized
DEBUG - 2016-03-09 16:27:28 --> URI Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Router Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Router Class Initialized
ERROR - 2016-03-09 16:27:28 --> 404 Page Not Found --> _cmp
DEBUG - 2016-03-09 16:27:28 --> Output Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Security Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Input Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 16:27:28 --> Language Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Loader Class Initialized
DEBUG - 2016-03-09 16:27:28 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 16:27:28 --> Helper loaded: url_helper
DEBUG - 2016-03-09 16:27:28 --> Helper loaded: image_helper
DEBUG - 2016-03-09 16:27:28 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 16:27:28 --> Database Driver Class Initialized
DEBUG - 2016-03-09 16:27:29 --> Session Class Initialized
DEBUG - 2016-03-09 16:27:29 --> Helper loaded: string_helper
DEBUG - 2016-03-09 16:27:29 --> Session routines successfully run
DEBUG - 2016-03-09 16:27:29 --> Controller Class Initialized
DEBUG - 2016-03-09 16:27:29 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 16:27:29 --> Model Class Initialized
DEBUG - 2016-03-09 16:27:29 --> Model Class Initialized
ERROR - 2016-03-09 16:27:29 --> 404 Page Not Found --> campanha/imgs
DEBUG - 2016-03-09 16:28:18 --> Config Class Initialized
DEBUG - 2016-03-09 16:28:18 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:28:18 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:28:18 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:28:18 --> URI Class Initialized
DEBUG - 2016-03-09 16:28:18 --> Router Class Initialized
DEBUG - 2016-03-09 16:28:18 --> Output Class Initialized
DEBUG - 2016-03-09 16:28:18 --> Security Class Initialized
DEBUG - 2016-03-09 16:28:18 --> Input Class Initialized
DEBUG - 2016-03-09 16:28:18 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 16:28:18 --> Language Class Initialized
DEBUG - 2016-03-09 16:28:18 --> Loader Class Initialized
DEBUG - 2016-03-09 16:28:18 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 16:28:18 --> Helper loaded: url_helper
DEBUG - 2016-03-09 16:28:18 --> Helper loaded: image_helper
DEBUG - 2016-03-09 16:28:18 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 16:28:18 --> Database Driver Class Initialized
DEBUG - 2016-03-09 16:28:19 --> Session Class Initialized
DEBUG - 2016-03-09 16:28:19 --> Helper loaded: string_helper
DEBUG - 2016-03-09 16:28:19 --> Session routines successfully run
DEBUG - 2016-03-09 16:28:19 --> Controller Class Initialized
DEBUG - 2016-03-09 16:28:19 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 16:28:19 --> Model Class Initialized
DEBUG - 2016-03-09 16:28:19 --> Model Class Initialized
DEBUG - 2016-03-09 16:28:20 --> File loaded: application/views/campanhas_ativas.php
DEBUG - 2016-03-09 16:28:20 --> Final output sent to browser
DEBUG - 2016-03-09 16:28:20 --> Total execution time: 1.1551
DEBUG - 2016-03-09 16:28:20 --> Config Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:28:20 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:28:20 --> URI Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Config Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Config Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:28:20 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:28:20 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:28:20 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:28:20 --> URI Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Router Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Router Class Initialized
DEBUG - 2016-03-09 16:28:20 --> URI Class Initialized
ERROR - 2016-03-09 16:28:20 --> 404 Page Not Found --> _cmp
ERROR - 2016-03-09 16:28:20 --> 404 Page Not Found --> _cmp
DEBUG - 2016-03-09 16:28:20 --> Router Class Initialized
ERROR - 2016-03-09 16:28:20 --> 404 Page Not Found --> _cmp
DEBUG - 2016-03-09 16:28:20 --> Config Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Hooks Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Utf8 Class Initialized
DEBUG - 2016-03-09 16:28:20 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 16:28:20 --> URI Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Router Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Output Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Security Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Input Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 16:28:20 --> Language Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Loader Class Initialized
DEBUG - 2016-03-09 16:28:20 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 16:28:20 --> Helper loaded: url_helper
DEBUG - 2016-03-09 16:28:20 --> Helper loaded: image_helper
DEBUG - 2016-03-09 16:28:20 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 16:28:20 --> Database Driver Class Initialized
DEBUG - 2016-03-09 16:28:21 --> Session Class Initialized
DEBUG - 2016-03-09 16:28:21 --> Helper loaded: string_helper
DEBUG - 2016-03-09 16:28:21 --> Session routines successfully run
DEBUG - 2016-03-09 16:28:21 --> Controller Class Initialized
DEBUG - 2016-03-09 16:28:21 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 16:28:21 --> Model Class Initialized
DEBUG - 2016-03-09 16:28:21 --> Model Class Initialized
ERROR - 2016-03-09 16:28:21 --> 404 Page Not Found --> campanha/imgs
DEBUG - 2016-03-09 17:04:51 --> Config Class Initialized
DEBUG - 2016-03-09 17:04:51 --> Hooks Class Initialized
DEBUG - 2016-03-09 17:04:51 --> Utf8 Class Initialized
DEBUG - 2016-03-09 17:04:51 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 17:04:51 --> URI Class Initialized
DEBUG - 2016-03-09 17:04:51 --> Router Class Initialized
DEBUG - 2016-03-09 17:04:51 --> Output Class Initialized
DEBUG - 2016-03-09 17:04:51 --> Security Class Initialized
DEBUG - 2016-03-09 17:04:51 --> Input Class Initialized
DEBUG - 2016-03-09 17:04:51 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 17:04:51 --> Language Class Initialized
DEBUG - 2016-03-09 17:04:51 --> Loader Class Initialized
DEBUG - 2016-03-09 17:04:51 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 17:04:52 --> Helper loaded: url_helper
DEBUG - 2016-03-09 17:04:52 --> Helper loaded: image_helper
DEBUG - 2016-03-09 17:04:52 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 17:04:52 --> Database Driver Class Initialized
DEBUG - 2016-03-09 17:04:53 --> Session Class Initialized
DEBUG - 2016-03-09 17:04:53 --> Helper loaded: string_helper
DEBUG - 2016-03-09 17:04:53 --> A session cookie was not found.
DEBUG - 2016-03-09 17:04:53 --> Session routines successfully run
DEBUG - 2016-03-09 17:04:53 --> Controller Class Initialized
DEBUG - 2016-03-09 17:04:53 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 17:04:53 --> Model Class Initialized
DEBUG - 2016-03-09 17:04:53 --> Model Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Config Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Config Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Hooks Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Hooks Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Utf8 Class Initialized
DEBUG - 2016-03-09 17:04:56 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 17:04:56 --> Utf8 Class Initialized
DEBUG - 2016-03-09 17:04:56 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 17:04:56 --> URI Class Initialized
DEBUG - 2016-03-09 17:04:56 --> URI Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Router Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Output Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Security Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Config Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Hooks Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Utf8 Class Initialized
DEBUG - 2016-03-09 17:04:56 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 17:04:56 --> Router Class Initialized
DEBUG - 2016-03-09 17:04:56 --> URI Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Router Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Output Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Output Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Security Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Security Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Input Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 17:04:56 --> Input Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Language Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 17:04:56 --> Input Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 17:04:56 --> Language Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Language Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Loader Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Loader Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 17:04:56 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 17:04:56 --> Helper loaded: url_helper
DEBUG - 2016-03-09 17:04:56 --> Helper loaded: image_helper
DEBUG - 2016-03-09 17:04:56 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 17:04:56 --> Helper loaded: url_helper
DEBUG - 2016-03-09 17:04:56 --> Loader Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Helper loaded: image_helper
DEBUG - 2016-03-09 17:04:56 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 17:04:56 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 17:04:56 --> Helper loaded: url_helper
DEBUG - 2016-03-09 17:04:56 --> Helper loaded: image_helper
DEBUG - 2016-03-09 17:04:56 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 17:04:56 --> Database Driver Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Database Driver Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Config Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Hooks Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Utf8 Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Database Driver Class Initialized
DEBUG - 2016-03-09 17:04:56 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 17:04:56 --> Config Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Hooks Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Utf8 Class Initialized
DEBUG - 2016-03-09 17:04:56 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 17:04:56 --> URI Class Initialized
DEBUG - 2016-03-09 17:04:56 --> URI Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Router Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Router Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Output Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Security Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Output Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Input Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 17:04:56 --> Security Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Language Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Input Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 17:04:56 --> Language Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Loader Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 17:04:56 --> Loader Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Helper loaded: url_helper
DEBUG - 2016-03-09 17:04:56 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 17:04:56 --> Helper loaded: image_helper
DEBUG - 2016-03-09 17:04:56 --> Helper loaded: url_helper
DEBUG - 2016-03-09 17:04:56 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 17:04:56 --> Helper loaded: image_helper
DEBUG - 2016-03-09 17:04:56 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 17:04:56 --> Database Driver Class Initialized
DEBUG - 2016-03-09 17:04:56 --> Database Driver Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Session Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Helper loaded: string_helper
DEBUG - 2016-03-09 17:04:57 --> A session cookie was not found.
DEBUG - 2016-03-09 17:04:57 --> Session routines successfully run
DEBUG - 2016-03-09 17:04:57 --> Controller Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 17:04:57 --> Model Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Model Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Session Class Initialized
ERROR - 2016-03-09 17:04:57 --> 404 Page Not Found --> campanha/estilos
DEBUG - 2016-03-09 17:04:57 --> Helper loaded: string_helper
DEBUG - 2016-03-09 17:04:57 --> A session cookie was not found.
DEBUG - 2016-03-09 17:04:57 --> Session routines successfully run
DEBUG - 2016-03-09 17:04:57 --> Controller Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Session Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 17:04:57 --> Helper loaded: string_helper
DEBUG - 2016-03-09 17:04:57 --> A session cookie was not found.
DEBUG - 2016-03-09 17:04:57 --> Model Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Session routines successfully run
DEBUG - 2016-03-09 17:04:57 --> Controller Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 17:04:57 --> Model Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Model Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Model Class Initialized
ERROR - 2016-03-09 17:04:57 --> 404 Page Not Found --> campanha/js
ERROR - 2016-03-09 17:04:57 --> 404 Page Not Found --> campanha/estilos
DEBUG - 2016-03-09 17:04:57 --> Session Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Helper loaded: string_helper
DEBUG - 2016-03-09 17:04:57 --> A session cookie was not found.
DEBUG - 2016-03-09 17:04:57 --> Session routines successfully run
DEBUG - 2016-03-09 17:04:57 --> Controller Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 17:04:57 --> Model Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Model Class Initialized
ERROR - 2016-03-09 17:04:57 --> 404 Page Not Found --> campanha/js
DEBUG - 2016-03-09 17:04:57 --> Session Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Helper loaded: string_helper
DEBUG - 2016-03-09 17:04:57 --> A session cookie was not found.
DEBUG - 2016-03-09 17:04:57 --> Session routines successfully run
DEBUG - 2016-03-09 17:04:57 --> Controller Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 17:04:57 --> Model Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Model Class Initialized
ERROR - 2016-03-09 17:04:57 --> 404 Page Not Found --> campanha/js
DEBUG - 2016-03-09 17:04:57 --> Config Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Hooks Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Utf8 Class Initialized
DEBUG - 2016-03-09 17:04:57 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 17:04:57 --> URI Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Router Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Output Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Security Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Input Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 17:04:57 --> Language Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Loader Class Initialized
DEBUG - 2016-03-09 17:04:57 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 17:04:57 --> Helper loaded: url_helper
DEBUG - 2016-03-09 17:04:57 --> Helper loaded: image_helper
DEBUG - 2016-03-09 17:04:57 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 17:04:57 --> Database Driver Class Initialized
DEBUG - 2016-03-09 17:04:58 --> Config Class Initialized
DEBUG - 2016-03-09 17:04:58 --> Hooks Class Initialized
DEBUG - 2016-03-09 17:04:58 --> Utf8 Class Initialized
DEBUG - 2016-03-09 17:04:58 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 17:04:58 --> URI Class Initialized
DEBUG - 2016-03-09 17:04:58 --> Router Class Initialized
DEBUG - 2016-03-09 17:04:58 --> Output Class Initialized
DEBUG - 2016-03-09 17:04:58 --> Security Class Initialized
DEBUG - 2016-03-09 17:04:58 --> Input Class Initialized
DEBUG - 2016-03-09 17:04:58 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 17:04:58 --> Language Class Initialized
DEBUG - 2016-03-09 17:04:58 --> Loader Class Initialized
DEBUG - 2016-03-09 17:04:58 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 17:04:58 --> Helper loaded: url_helper
DEBUG - 2016-03-09 17:04:58 --> Helper loaded: image_helper
DEBUG - 2016-03-09 17:04:58 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 17:04:58 --> Session Class Initialized
DEBUG - 2016-03-09 17:04:58 --> Helper loaded: string_helper
DEBUG - 2016-03-09 17:04:58 --> A session cookie was not found.
DEBUG - 2016-03-09 17:04:58 --> Session routines successfully run
DEBUG - 2016-03-09 17:04:58 --> Database Driver Class Initialized
DEBUG - 2016-03-09 17:04:58 --> Controller Class Initialized
DEBUG - 2016-03-09 17:04:58 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 17:04:58 --> Model Class Initialized
DEBUG - 2016-03-09 17:04:58 --> Model Class Initialized
DEBUG - 2016-03-09 17:04:58 --> File loaded: application/views/campanhas_ativas.php
DEBUG - 2016-03-09 17:04:58 --> Final output sent to browser
DEBUG - 2016-03-09 17:04:58 --> Total execution time: 1.1761
DEBUG - 2016-03-09 17:04:59 --> Config Class Initialized
DEBUG - 2016-03-09 17:04:59 --> Hooks Class Initialized
DEBUG - 2016-03-09 17:04:59 --> Utf8 Class Initialized
DEBUG - 2016-03-09 17:04:59 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 17:04:59 --> URI Class Initialized
DEBUG - 2016-03-09 17:04:59 --> Router Class Initialized
DEBUG - 2016-03-09 17:04:59 --> Output Class Initialized
DEBUG - 2016-03-09 17:04:59 --> Security Class Initialized
DEBUG - 2016-03-09 17:04:59 --> Input Class Initialized
DEBUG - 2016-03-09 17:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 17:04:59 --> Language Class Initialized
DEBUG - 2016-03-09 17:04:59 --> Loader Class Initialized
DEBUG - 2016-03-09 17:04:59 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 17:04:59 --> Helper loaded: url_helper
DEBUG - 2016-03-09 17:04:59 --> Helper loaded: image_helper
DEBUG - 2016-03-09 17:04:59 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 17:04:59 --> Database Driver Class Initialized
DEBUG - 2016-03-09 17:04:59 --> Session Class Initialized
DEBUG - 2016-03-09 17:04:59 --> Helper loaded: string_helper
DEBUG - 2016-03-09 17:04:59 --> A session cookie was not found.
DEBUG - 2016-03-09 17:04:59 --> Session routines successfully run
DEBUG - 2016-03-09 17:04:59 --> Controller Class Initialized
DEBUG - 2016-03-09 17:04:59 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 17:04:59 --> Model Class Initialized
DEBUG - 2016-03-09 17:04:59 --> Model Class Initialized
ERROR - 2016-03-09 17:04:59 --> 404 Page Not Found --> campanha/estilos
DEBUG - 2016-03-09 17:05:00 --> Config Class Initialized
DEBUG - 2016-03-09 17:05:00 --> Hooks Class Initialized
DEBUG - 2016-03-09 17:05:00 --> Utf8 Class Initialized
DEBUG - 2016-03-09 17:05:00 --> UTF-8 Support Enabled
DEBUG - 2016-03-09 17:05:00 --> URI Class Initialized
DEBUG - 2016-03-09 17:05:00 --> Router Class Initialized
DEBUG - 2016-03-09 17:05:00 --> Session Class Initialized
DEBUG - 2016-03-09 17:05:00 --> Helper loaded: string_helper
DEBUG - 2016-03-09 17:05:00 --> Session routines successfully run
DEBUG - 2016-03-09 17:05:00 --> Output Class Initialized
DEBUG - 2016-03-09 17:05:00 --> Controller Class Initialized
DEBUG - 2016-03-09 17:05:00 --> Final output sent to browser
DEBUG - 2016-03-09 17:05:00 --> Total execution time: 1.1391
DEBUG - 2016-03-09 17:05:00 --> Security Class Initialized
DEBUG - 2016-03-09 17:05:00 --> Input Class Initialized
DEBUG - 2016-03-09 17:05:00 --> Global POST and COOKIE data sanitized
DEBUG - 2016-03-09 17:05:00 --> Language Class Initialized
DEBUG - 2016-03-09 17:05:00 --> Loader Class Initialized
DEBUG - 2016-03-09 17:05:00 --> Config file loaded: application/config/site_params.php
DEBUG - 2016-03-09 17:05:00 --> Helper loaded: url_helper
DEBUG - 2016-03-09 17:05:00 --> Helper loaded: image_helper
DEBUG - 2016-03-09 17:05:00 --> Language file loaded: language/pt-br/site_lang.php
DEBUG - 2016-03-09 17:05:00 --> Database Driver Class Initialized
DEBUG - 2016-03-09 17:05:01 --> Session Class Initialized
DEBUG - 2016-03-09 17:05:01 --> Helper loaded: string_helper
DEBUG - 2016-03-09 17:05:01 --> A session cookie was not found.
DEBUG - 2016-03-09 17:05:01 --> Session routines successfully run
DEBUG - 2016-03-09 17:05:01 --> Controller Class Initialized
DEBUG - 2016-03-09 17:05:01 --> Helper loaded: super_url_helper
DEBUG - 2016-03-09 17:05:01 --> Model Class Initialized
DEBUG - 2016-03-09 17:05:01 --> Model Class Initialized
ERROR - 2016-03-09 17:05:01 --> 404 Page Not Found --> campanha/imgs
