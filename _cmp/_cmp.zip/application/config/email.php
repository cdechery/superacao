<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['charset']='UTF-8';
$config['wordwrap']=TRUE;
$config['mailtype']='html';

?>